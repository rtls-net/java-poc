package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the APLCTN_PRPTY database table.
 * @author Deloitte.
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="APLCTN_PRPTY")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AplctnPrpty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PROPS_KEY_CD")
	private String propsKeyCd;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="PROPS_DESC_TXT")
	private String propsDescTxt;

	@Column(name="PROPS_PARAMETERS_TXT")
	private String propsParametersTxt;

	@Column(name="PROPS_TYPE_CD")
	private String propsTypeCd;

	@Column(name="PROPS_VAL_TXT")
	private String propsValTxt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	public AplctnPrpty() {
	}

	public String getPropsKeyCd() {
		return this.propsKeyCd;
	}

	public void setPropsKeyCd(String propsKeyCd) {
		this.propsKeyCd = propsKeyCd;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getPropsDescTxt() {
		return this.propsDescTxt;
	}

	public void setPropsDescTxt(String propsDescTxt) {
		this.propsDescTxt = propsDescTxt;
	}

	public String getPropsParametersTxt() {
		return this.propsParametersTxt;
	}

	public void setPropsParametersTxt(String propsParametersTxt) {
		this.propsParametersTxt = propsParametersTxt;
	}

	public String getPropsTypeCd() {
		return this.propsTypeCd;
	}

	public void setPropsTypeCd(String propsTypeCd) {
		this.propsTypeCd = propsTypeCd;
	}

	public String getPropsValTxt() {
		return this.propsValTxt;
	}

	public void setPropsValTxt(String propsValTxt) {
		this.propsValTxt = propsValTxt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}