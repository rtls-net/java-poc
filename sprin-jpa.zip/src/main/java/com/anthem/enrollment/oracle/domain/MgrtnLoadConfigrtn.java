package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the MGRTN_LOAD_CONFIGRTN database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="MGRTN_LOAD_CONFIGRTN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MgrtnLoadConfigrtn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SOURCE_TYPE_CD")
	private String sourceTypeCd;

	private String bypassbeidgeneration;

	private String bypasscaseidgeneration;

	private String bypasspersistence;

	private String bypassproductidgeneration;

	private String bypasspsudeobecreation;

	private String bypasswgscreationdate;

	private String bypasswgsupdatedate;

	private String bypasswgsuserid;

	private String sourceuserid;

	public MgrtnLoadConfigrtn() {
	}

	public String getSourceTypeCd() {
		return this.sourceTypeCd;
	}

	public void setSourceTypeCd(String sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getBypassbeidgeneration() {
		return this.bypassbeidgeneration;
	}

	public void setBypassbeidgeneration(String bypassbeidgeneration) {
		this.bypassbeidgeneration = bypassbeidgeneration;
	}

	public String getBypasscaseidgeneration() {
		return this.bypasscaseidgeneration;
	}

	public void setBypasscaseidgeneration(String bypasscaseidgeneration) {
		this.bypasscaseidgeneration = bypasscaseidgeneration;
	}

	public String getBypasspersistence() {
		return this.bypasspersistence;
	}

	public void setBypasspersistence(String bypasspersistence) {
		this.bypasspersistence = bypasspersistence;
	}

	public String getBypassproductidgeneration() {
		return this.bypassproductidgeneration;
	}

	public void setBypassproductidgeneration(String bypassproductidgeneration) {
		this.bypassproductidgeneration = bypassproductidgeneration;
	}

	public String getBypasspsudeobecreation() {
		return this.bypasspsudeobecreation;
	}

	public void setBypasspsudeobecreation(String bypasspsudeobecreation) {
		this.bypasspsudeobecreation = bypasspsudeobecreation;
	}

	public String getBypasswgscreationdate() {
		return this.bypasswgscreationdate;
	}

	public void setBypasswgscreationdate(String bypasswgscreationdate) {
		this.bypasswgscreationdate = bypasswgscreationdate;
	}

	public String getBypasswgsupdatedate() {
		return this.bypasswgsupdatedate;
	}

	public void setBypasswgsupdatedate(String bypasswgsupdatedate) {
		this.bypasswgsupdatedate = bypasswgsupdatedate;
	}

	public String getBypasswgsuserid() {
		return this.bypasswgsuserid;
	}

	public void setBypasswgsuserid(String bypasswgsuserid) {
		this.bypasswgsuserid = bypasswgsuserid;
	}

	public String getSourceuserid() {
		return this.sourceuserid;
	}

	public void setSourceuserid(String sourceuserid) {
		this.sourceuserid = sourceuserid;
	}

}