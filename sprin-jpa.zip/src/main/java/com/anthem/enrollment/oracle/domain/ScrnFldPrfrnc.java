package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the SCRN_FLD_PRFRNC database table.
 * 
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="SCRN_FLD_PRFRNC")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScrnFldPrfrnc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SCRN_FLD_PRFRNC_ID")
	private long scrnFldPrfrncId;

	@Column(name="AUDIT_FLG")
	private String auditFlg;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="DFLT_VAL")
	private String dfltVal;

	@Column(name="DSPLY_ONLY_IND_CD")
	private String dsplyOnlyIndCd;

	@Column(name="ENTITY_NM")
	private String entityNm;

	@Column(name="FLD_CD")
	private String fldCd;

	@Temporal(TemporalType.DATE)
	@Column(name="FLD_EFCTV_DT")
	private Date fldEfctvDt;

	@Column(name="FLD_NM")
	private String fldNm;

	@Column(name="FLD_SQNC_NBR")
	private BigDecimal fldSqncNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="FLD_TRMNTN_DT")
	private Date fldTrmntnDt;

	@Column(name="FLD_TYPE_CD")
	private String fldTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="MNDTRY_IND_CD")
	private String mndtryIndCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to ScrnPrfrnc
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SCRN_PRFRNC_ID")
	private ScrnPrfrnc scrnPrfrnc;

	//bi-directional many-to-one association to ScrnFldStLobPrfrnc
	@JsonIgnore
	@OneToMany(mappedBy="scrnFldPrfrnc")
	private List<ScrnFldStLobPrfrnc> scrnFldStLobPrfrncs;

	public ScrnFldPrfrnc() {
	}

	public long getScrnFldPrfrncId() {
		return this.scrnFldPrfrncId;
	}

	public void setScrnFldPrfrncId(long scrnFldPrfrncId) {
		this.scrnFldPrfrncId = scrnFldPrfrncId;
	}

	public String getAuditFlg() {
		return this.auditFlg;
	}

	public void setAuditFlg(String auditFlg) {
		this.auditFlg = auditFlg;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getDfltVal() {
		return this.dfltVal;
	}

	public void setDfltVal(String dfltVal) {
		this.dfltVal = dfltVal;
	}

	public String getDsplyOnlyIndCd() {
		return this.dsplyOnlyIndCd;
	}

	public void setDsplyOnlyIndCd(String dsplyOnlyIndCd) {
		this.dsplyOnlyIndCd = dsplyOnlyIndCd;
	}

	public String getEntityNm() {
		return this.entityNm;
	}

	public void setEntityNm(String entityNm) {
		this.entityNm = entityNm;
	}

	public String getFldCd() {
		return this.fldCd;
	}

	public void setFldCd(String fldCd) {
		this.fldCd = fldCd;
	}

	public Date getFldEfctvDt() {
		return this.fldEfctvDt;
	}

	public void setFldEfctvDt(Date fldEfctvDt) {
		this.fldEfctvDt = fldEfctvDt;
	}

	public String getFldNm() {
		return this.fldNm;
	}

	public void setFldNm(String fldNm) {
		this.fldNm = fldNm;
	}

	public BigDecimal getFldSqncNbr() {
		return this.fldSqncNbr;
	}

	public void setFldSqncNbr(BigDecimal fldSqncNbr) {
		this.fldSqncNbr = fldSqncNbr;
	}

	public Date getFldTrmntnDt() {
		return this.fldTrmntnDt;
	}

	public void setFldTrmntnDt(Date fldTrmntnDt) {
		this.fldTrmntnDt = fldTrmntnDt;
	}

	public String getFldTypeCd() {
		return this.fldTypeCd;
	}

	public void setFldTypeCd(String fldTypeCd) {
		this.fldTypeCd = fldTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getMndtryIndCd() {
		return this.mndtryIndCd;
	}

	public void setMndtryIndCd(String mndtryIndCd) {
		this.mndtryIndCd = mndtryIndCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public ScrnPrfrnc getScrnPrfrnc() {
		return this.scrnPrfrnc;
	}

	public void setScrnPrfrnc(ScrnPrfrnc scrnPrfrnc) {
		this.scrnPrfrnc = scrnPrfrnc;
	}

	public List<ScrnFldStLobPrfrnc> getScrnFldStLobPrfrncs() {
		return this.scrnFldStLobPrfrncs;
	}

	public void setScrnFldStLobPrfrncs(List<ScrnFldStLobPrfrnc> scrnFldStLobPrfrncs) {
		this.scrnFldStLobPrfrncs = scrnFldStLobPrfrncs;
	}

	public ScrnFldStLobPrfrnc addScrnFldStLobPrfrnc(ScrnFldStLobPrfrnc scrnFldStLobPrfrnc) {
		getScrnFldStLobPrfrncs().add(scrnFldStLobPrfrnc);
		scrnFldStLobPrfrnc.setScrnFldPrfrnc(this);

		return scrnFldStLobPrfrnc;
	}

	public ScrnFldStLobPrfrnc removeScrnFldStLobPrfrnc(ScrnFldStLobPrfrnc scrnFldStLobPrfrnc) {
		getScrnFldStLobPrfrncs().remove(scrnFldStLobPrfrnc);
		scrnFldStLobPrfrnc.setScrnFldPrfrnc(null);

		return scrnFldStLobPrfrnc;
	}

}