package com.anthem.enrollment.oracle.domain;

import com.anthem.enrollment.domain.CancelBEWrapper;
import com.anthem.enrollment.domain.Product;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * BillingInfoWrapper - This class wraps all domain objects related to Billing Information.
 * 
 * @author Deloitte
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class BillingInfoWrapper implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The billg enty. */
	private BillgEnty billgEnty;

	/** The billg enty adrs. */
	private BillgEntyAdrs billgEntyAdrs;

	/** The billg enty tlphn. */
	private BillgEntyTlphn billgEntyTlphn;

    /** The cntrct billg enty */
    private CntrctBillgEnty cntrctBillgEnty;

	/** The adrs. */
	private Adrs adrs;

	/** The bill addr same company addr. */
	private transient String billAddrSameCompanyAddr;

	/** The on flip change default value. */
	// used to decide do we need to default the value when user flip the Billg Entity Type..
	private transient String onFlipChangeDefaultValue;

	/** The is new billg enty. */
	//isNewBillgEnty will true only if data is not persisted in db. Otherwise it will be false.
	private transient boolean isNewBillgEnty;

	/** The billg enty ids list. */
	// billgEntyIdsList hold list of billing ids a case.
	private transient List<Long> billgEntyIdsList;

	/** The bill enty map. */
	// billEntyMap hold all BillgEntys a case
	private transient Map<Long,BillgEnty> billEntyMap;

	/** The is first billg enty. */
	// ISFIRSTBILLGENTY - IT SAYS IF ANY BILLGENTY IS CREATED A CASE..
	private transient boolean isFirstBillgEnty;

	/** The contrct id to be assign. */
	private transient List<String> contrctIdToBeAssign;

	/** The un assigned cntrcts exists. */
	private transient String unAssignedCntrctsExists;

	/** The b E product list. */
	private List<Product> bEProductList;

	/** The is conslidate BE required. */
	// Per Case
	private transient boolean isConslidateBERequired;

	/** The is individual BE required. */
	// Per Case
	private transient boolean isIndividualBERequired;

	/** The add new BE clicked. */
	private transient String addNewBEClicked;

	/** The address bill entity. */
	private transient String addressBillEntity;

	/** The products edited. */
	//LIT-1357: Flag to check Reactivate BE is renamed from ReactivateBE to ProductsEdited and the type changed from "boolean" to "String"
	private String productsEdited;

	/** The push to wgs stts cd. */
	//LIT-2966
	private String pushToWgsSttsCd;


	/** This attribute holds state code of case. */
	private String statecd;

	/**
	 * The list holding the  error values
	 **/
	private Map<String, Error> errorMap;
	 private  Long grpId;

	private CancelBEWrapper cancelBEWrapper;
	private transient String mrktTypeCd;
	
	private transient String restrictWgsCall;
	private transient String wgsBillEntyStts;

	public String getRestrictWgsCall() {
		return restrictWgsCall;
	}
	public void setRestrictWgsCall(String restrictWgsCall) {
		this.restrictWgsCall = restrictWgsCall;
	}
	
	/**
	 * Constructs BillingInfoWrapper with default member values.
	 */
	public BillingInfoWrapper(){
		billgEnty = new BillgEnty();
		billgEntyAdrs = new BillgEntyAdrs();
		billgEntyTlphn = new BillgEntyTlphn();
        cntrctBillgEnty = new CntrctBillgEnty();
		adrs =new Adrs();
	}

	/**
	 * Gets the bill addr same company addr.
	 *
	 * @return String
	 */
	public String getBillAddrSameCompanyAddr() {
		return billAddrSameCompanyAddr;
	}

	/**
	 * Sets the bill addr same company addr.
	 *
	 * @param billAddrSameCompanyAddr the new bill addr same company addr
	 */
	public void setBillAddrSameCompanyAddr(String billAddrSameCompanyAddr) {
		this.billAddrSameCompanyAddr = billAddrSameCompanyAddr;
	}

	/**
	 * Gets the billg enty.
	 *
	 * @return BillgEnty
	 */
	public BillgEnty getBillgEnty() {
		return billgEnty;
	}

	/**
	 * Sets the billg enty.
	 *
	 * @param billgEnty the new billg enty
	 */
	public void setBillgEnty(BillgEnty billgEnty) {
		this.billgEnty = billgEnty;
	}

	/**
	 * Gets the on flip change default value.
	 *
	 * @return String
	 */
	public String getOnFlipChangeDefaultValue() {
		return onFlipChangeDefaultValue;
	}

	/**
	 * Sets the on flip change default value.
	 *
	 * @param onFlipChangeDefaultValue the new on flip change default value
	 */
	public void setOnFlipChangeDefaultValue(String onFlipChangeDefaultValue) {
		this.onFlipChangeDefaultValue = onFlipChangeDefaultValue;
	}

	/**
	 * Checks if is new billg enty.
	 *
	 * @return boolean
	 */
	public boolean isNewBillgEnty() {
		return isNewBillgEnty;
	}

	/**
	 * Sets the new billg enty.
	 *
	 * @param isNewBillgEnty the new new billg enty
	 */
	public void setNewBillgEnty(boolean isNewBillgEnty) {
		this.isNewBillgEnty = isNewBillgEnty;
	}

	/**
	 * Gets the billg enty ids list.
	 *
	 * @return List<Long>
	 */
	public List<Long> getBillgEntyIdsList() {
		return billgEntyIdsList;
	}

	/**
	 * Sets the billg enty ids list.
	 *
	 * @param billgEntyIdsList the new billg enty ids list
	 */
	public void setBillgEntyIdsList(List<Long> billgEntyIdsList) {
		this.billgEntyIdsList = billgEntyIdsList;
	}

	/**
	 * Gets the bill enty map.
	 *
	 * @return Map<Long,BillgEnty>
	 */
	public Map<Long, BillgEnty> getBillEntyMap() {
		return billEntyMap;
	}

	/**
	 * Sets the bill enty map.
	 *
	 * @param billEntyMap the bill enty map
	 */
	public void setBillEntyMap(Map<Long, BillgEnty> billEntyMap) {
		this.billEntyMap = billEntyMap;
	}

	/**
	 * Checks if is first billg enty.
	 *
	 * @return boolean
	 */
	public boolean isFirstBillgEnty() {
		return isFirstBillgEnty;
	}

	/**
	 * Sets the first billg enty.
	 *
	 * @param isFirstBillgEnty the new first billg enty
	 */
	public void setFirstBillgEnty(boolean isFirstBillgEnty) {
		this.isFirstBillgEnty = isFirstBillgEnty;
	}

	/**
	 * Gets the contrct id to be assign.
	 *
	 * @return List<String>
	 */
	public List<String> getContrctIdToBeAssign() {
		return contrctIdToBeAssign;
	}

	/**
	 * Sets the contrct id to be assign.
	 *
	 * @param contrctIdToBeAssign the new contrct id to be assign
	 */
	public void setContrctIdToBeAssign(List<String> contrctIdToBeAssign) {
		this.contrctIdToBeAssign = contrctIdToBeAssign;
	}

	/**
	 * Gets the un assigned cntrcts exists.
	 *
	 * @return String
	 */
	public String getUnAssignedCntrctsExists() {
		return unAssignedCntrctsExists;
	}

	/**
	 * Sets the un assigned cntrcts exists.
	 *
	 * @param unAssignedCntrctsExists the new un assigned cntrcts exists
	 */
	public void setUnAssignedCntrctsExists(String unAssignedCntrctsExists) {
		this.unAssignedCntrctsExists = unAssignedCntrctsExists;
	}

	/**
	 * Gets the billg enty adrs.
	 *
	 * @return BillgEntyAdrs
	 */
	public BillgEntyAdrs getBillgEntyAdrs() {
		return billgEntyAdrs;
	}

	/**
	 * Sets the billg enty adrs.
	 *
	 * @param billgEntyAdrs the new billg enty adrs
	 */
	public void setBillgEntyAdrs(BillgEntyAdrs billgEntyAdrs) {
		this.billgEntyAdrs = billgEntyAdrs;
	}

	/**
	 * Gets the billg enty tlphn.
	 *
	 * @return BillgEntyTlphn
	 */
	public BillgEntyTlphn getBillgEntyTlphn() {
		return billgEntyTlphn;
	}

	/**
	 * Sets the billg enty tlphn.
	 *
	 * @param billgEntyTlphn the new billg enty tlphn
	 */
	public void setBillgEntyTlphn(BillgEntyTlphn billgEntyTlphn) {
		this.billgEntyTlphn = billgEntyTlphn;
	}

	/**
	 * Gets the adrs.
	 *
	 * @return Adr
	 */
	public Adrs getAdrs() {
		return adrs;
	}

	/**
	 * Sets the adrs.
	 *
	 * @param adrs the new adrs
	 */
	public void setAdrs(Adrs adrs) {
		this.adrs = adrs;
	}

	/**
	 * Gets the b E product list.
	 *
	 * @return List<Product>
	 */
	public List<Product> getbEProductList() {
		return bEProductList;
	}

	/**
	 * Sets the b E product list.
	 *
	 * @param bEProductList the new b E product list
	 */
	public void setbEProductList(List<Product> bEProductList) {
		this.bEProductList = bEProductList;
	}

	/**
	 * Checks if is conslidate BE required.
	 *
	 * @return boolean
	 */
	public boolean isConslidateBERequired() {
		return isConslidateBERequired;
	}

	/**
	 * Sets the conslidate BE required.
	 *
	 * @param isConslidateBERequired the new conslidate BE required
	 */
	public void setConslidateBERequired(boolean isConslidateBERequired) {
		this.isConslidateBERequired = isConslidateBERequired;
	}

	/**
	 * Checks if is individual BE required.
	 *
	 * @return boolean
	 */
	public boolean isIndividualBERequired() {
		return isIndividualBERequired;
	}

	/**
	 * Sets the individual BE required.
	 *
	 * @param isIndividualBERequired the new individual BE required
	 */
	public void setIndividualBERequired(boolean isIndividualBERequired) {
		this.isIndividualBERequired = isIndividualBERequired;
	}

	/**
	 * Gets the adds the new BE clicked.
	 *
	 * @return String
	 */
	public String getAddNewBEClicked() {
		return addNewBEClicked;
	}

	/**
	 * Sets the adds the new BE clicked.
	 *
	 * @param addNewBEClicked the new adds the new BE clicked
	 */
	public void setAddNewBEClicked(String addNewBEClicked) {
		this.addNewBEClicked = addNewBEClicked;
	}

	/**
	 * Gets the address bill entity.
	 *
	 * @return String
	 */
	public String getAddressBillEntity() {
		return addressBillEntity;
	}

	/**
	 * Sets the address bill entity.
	 *
	 * @param isAddressBillEntity the new address bill entity
	 */
	public void setAddressBillEntity(String isAddressBillEntity) {
		this.addressBillEntity = isAddressBillEntity;
	}

	/**
	 * Gets the statecd.
	 *
	 * @return String
	 */
	public String getStatecd() {
		return statecd;
	}

	/**
	 * Sets the statecd.
	 *
	 * @param statecd the new statecd
	 */
	public void setStatecd(String statecd) {
		this.statecd = statecd;
	}

	/**
	 * Gets the products edited.
	 *
	 * @return String
	 */
	public String getProductsEdited() {
		return productsEdited;
	}

	/**
	 * Sets the products edited.
	 *
	 * @param productsEdited the new products edited
	 */
	public void setProductsEdited(String productsEdited) {
		this.productsEdited = productsEdited;
	}

	//LIT-2966
	/**
	 * Sets the push to wgs stts cd.
	 *
	 * @param status the new push to wgs stts cd
	 */
	public void setPushToWgsSttsCd(String status) {
		this.pushToWgsSttsCd = status;
	}

	/**
	 * Gets the push to wgs stts cd.
	 *
	 * @return String
	 */
	public String getPushToWgsSttsCd() {
		return pushToWgsSttsCd;
	}

	public Map<String, Error> getErrorMap() {
		return errorMap;
	}

	public void setErrorMap(Map<String, Error> errorMap) {
		this.errorMap = errorMap;
	}

    public CntrctBillgEnty getCntrctBillgEnty() {
        return cntrctBillgEnty;
    }

    public void setCntrctBillgEnty(CntrctBillgEnty cntrctBillgEnty) {
        this.cntrctBillgEnty = cntrctBillgEnty;
    }

	public Long getGrpId() {
		return grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}
    
	public String getLgcyGrpNbr() {
		return lgcyGrpNbr;
	}
	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}
	private String lgcyGrpNbr;

	public CancelBEWrapper getCancelBEWrapper() {
		return cancelBEWrapper;
	}

	public void setCancelBEWrapper(CancelBEWrapper cancelBEWrapper) {
		this.cancelBEWrapper = cancelBEWrapper;
	}

	public String getMrktTypeCd() {
		return mrktTypeCd;
	}

	public void setMrktTypeCd(String mrktTypeCd) {
		this.mrktTypeCd = mrktTypeCd;
	}
	public String getWgsBillEntyStts() {
		return wgsBillEntyStts;
	}
	public void setWgsBillEntyStts(String wgsBillEntyStts) {
		this.wgsBillEntyStts = wgsBillEntyStts;
	}
    
	
	
}
