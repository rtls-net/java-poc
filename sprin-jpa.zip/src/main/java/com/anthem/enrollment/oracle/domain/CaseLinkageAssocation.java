package com.anthem.enrollment.oracle.domain;

import java.util.Date;

/*This pojo is careated to associate case linkage with cases
 * Author Legato
 * 
 * */

public class CaseLinkageAssocation {

	private String linkageId;
	private String linkageType;
	private String relLinkageId;
	private boolean customIdCard;
	private Date startdate;
	private Date terminationDate;
	private String affiliationName;

	/**
	 * @return the linkageId
	 */
	public String getLinkageId() {
		return linkageId;
	}

	/**
	 * @param linkageId the linkageId to set
	 */
	public void setLinkageId(String linkageId) {
		this.linkageId = linkageId;
	}

	/**
	 * @return the linkageType
	 */
	public String getLinkageType() {
		return linkageType;
	}

	/**
	 * @param linkageType the linkageType to set
	 */
	public void setLinkageType(String linkageType) {
		this.linkageType = linkageType;
	}

	/**
	 * @return the relLinkageId
	 */
	public String getRelLinkageId() {
		return relLinkageId;
	}

	/**
	 * @param relLinkageId the relLinkageId to set
	 */
	public void setRelLinkageId(String relLinkageId) {
		this.relLinkageId = relLinkageId;
	}

	/**
	 * @return the customIdCard
	 */
	public boolean isCustomIdCard() {
		return customIdCard;
	}

	/**
	 * @param customIdCard the customIdCard to set
	 */
	public void setCustomIdCard(boolean customIdCard) {
		this.customIdCard = customIdCard;
	}

	/**
	 * @return the startdate
	 */
	public Date getStartdate() {
		return startdate;
	}

	/**
	 * @param startdate the startdate to set
	 */
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	/**
	 * @return the terminationDate
	 */
	public Date getTerminationDate() {
		return terminationDate;
	}

	/**
	 * @param terminationDate the terminationDate to set
	 */
	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	/**
	 * @return the affiliationName
	 */
	public String getAffiliationName() {
		return affiliationName;
	}

	/**
	 * @param affiliationName the affiliationName to set
	 */
	public void setAffiliationName(String affiliationName) {
		this.affiliationName = affiliationName;
	}

}
