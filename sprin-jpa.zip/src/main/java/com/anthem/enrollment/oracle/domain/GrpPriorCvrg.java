package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the GRP_PRIOR_CVRG database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_PRIOR_CVRG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpPriorCvrg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_PRIOR_CVRG_ID")
	private long grpPriorCvrgId;

	@Column(name="CARR_NM")
	private String carrNm;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="CVRG_REPLCD_CD")
	private String cvrgReplcdCd;

	@Column(name="CVRG_TYPE_CD")
	private String cvrgTypeCd;

	@Temporal(TemporalType.DATE)
	@Column(name="CVRG_TYPE_CD_TRMNTN_DT")
	private Date cvrgTypeCdTrmntnDt;

	@Column(name="DELETE_IND")
	private String deleteInd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpPriorCvrg() {
	}

	public long getGrpPriorCvrgId() {
		return this.grpPriorCvrgId;
	}

	public void setGrpPriorCvrgId(long grpPriorCvrgId) {
		this.grpPriorCvrgId = grpPriorCvrgId;
	}

	public String getCarrNm() {
		return this.carrNm;
	}

	public void setCarrNm(String carrNm) {
		this.carrNm = carrNm;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgReplcdCd() {
		return this.cvrgReplcdCd;
	}

	public void setCvrgReplcdCd(String cvrgReplcdCd) {
		this.cvrgReplcdCd = cvrgReplcdCd;
	}

	public String getCvrgTypeCd() {
		return this.cvrgTypeCd;
	}

	public void setCvrgTypeCd(String cvrgTypeCd) {
		this.cvrgTypeCd = cvrgTypeCd;
	}

	public Date getCvrgTypeCdTrmntnDt() {
		return this.cvrgTypeCdTrmntnDt;
	}

	public void setCvrgTypeCdTrmntnDt(Date cvrgTypeCdTrmntnDt) {
		this.cvrgTypeCdTrmntnDt = cvrgTypeCdTrmntnDt;
	}

	public String getDeleteInd() {
		return this.deleteInd;
	}

	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}