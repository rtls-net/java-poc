package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the ADRS database table.
 * @author Deloitte.
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="ADRS")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class Adrs implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ADRS_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long adrsId;

	@Column(name="ADRS_LINE_1_TXT")
	private String adrsLine1Txt;

	@Column(name="ADRS_LINE_2_TXT")
	private String adrsLine2Txt;

	@Column(name="ADRS_LINE_3_TXT")
	private String adrsLine3Txt;

	@Column(name="ADRS_LINE_4_TXT")
	private String adrsLine4Txt;

	@Column(name="CITY_NM")
	private String cityNm;

	@Column(name="CNTRY_CD")
	private String cntryCd;

	@Column(name="CNTY_CD")
	private String cntyCd;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="FRGN_POSTL_CD")
	private String frgnPostlCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="ST_CD")
	private String stCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name="ZIP_CD")
	private String zipCd;

	@Column(name="ZIP_PLUS_FOUR_CD")
	private String zipPlusFourCd;

	@Column(name="ZIP_TWO_CD")
	private String zipTwoCd;

	//bi-directional many-to-one association to BillgEntyAdr
	@JsonIgnore
	@OneToMany(mappedBy="adrs")
	private List<BillgEntyAdrs> billgEntyAdrs;

	//bi-directional many-to-one association to GrpAdr
	@JsonIgnore
	@OneToMany(mappedBy="adrs")
	private List<GrpAdr> grpAdrs;

	//bi-directional many-to-one association to GrpCntctPrsnAdr
	@JsonIgnore
	@OneToMany(mappedBy="adrs")
	private List<GrpCntctPrsnAdr> grpCntctPrsnAdrs;
	
	/*@JsonIgnore
	@OneToMany(mappedBy="adrs", cascade = CascadeType.ALL)
	private Cntrct cntrct;*/

	public Adrs() {
		//Default Implementation ignored.
	}

	public Long getAdrsId() {
		return this.adrsId;
	}

	public void setAdrsId(Long adrsId) {
		this.adrsId = adrsId;
	}

	public String getAdrsLine1Txt() {
		
		return this.adrsLine1Txt;
	}

	public void setAdrsLine1Txt(String adrsLine1Txt) {
		this.adrsLine1Txt = adrsLine1Txt;
	}

	public String getAdrsLine2Txt() {
		
		return this.adrsLine2Txt;
	}

	public void setAdrsLine2Txt(String adrsLine2Txt) {
		this.adrsLine2Txt = adrsLine2Txt;
	}

	public String getAdrsLine3Txt() {
		
		return this.adrsLine3Txt;
	}

	public void setAdrsLine3Txt(String adrsLine3Txt) {
		this.adrsLine3Txt = adrsLine3Txt;
	}

	public String getAdrsLine4Txt() {
		
		return this.adrsLine4Txt;
	}

	public void setAdrsLine4Txt(String adrsLine4Txt) {
		this.adrsLine4Txt = adrsLine4Txt;
	}

	public String getCityNm() {
		return this.cityNm;
	}

	public void setCityNm(String cityNm) {
		this.cityNm = cityNm;
	}

	public String getCntryCd() {
		return this.cntryCd;
	}

	public void setCntryCd(String cntryCd) {
		this.cntryCd = cntryCd;
	}

	public String getCntyCd() {
		return this.cntyCd;
	}

	public void setCntyCd(String cntyCd) {
		this.cntyCd = cntyCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getFrgnPostlCd() {
		return this.frgnPostlCd;
	}

	public void setFrgnPostlCd(String frgnPostlCd) {
		this.frgnPostlCd = frgnPostlCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getStCd() {
		return this.stCd;
	}

	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getZipCd() {
		return this.zipCd;
	}

	public void setZipCd(String zipCd) {
		this.zipCd = zipCd;
	}

	public String getZipPlusFourCd() {
		return this.zipPlusFourCd;
	}

	public void setZipPlusFourCd(String zipPlusFourCd) {
		this.zipPlusFourCd = zipPlusFourCd;
	}

	public String getZipTwoCd() {
		return this.zipTwoCd;
	}

	public void setZipTwoCd(String zipTwoCd) {
		this.zipTwoCd = zipTwoCd;
	}

	public List<BillgEntyAdrs> getBillgEntyAdrs() {
		return this.billgEntyAdrs;
	}

	public void setBillgEntyAdrs(List<BillgEntyAdrs> billgEntyAdrs) {
		this.billgEntyAdrs = billgEntyAdrs;
	}

	public BillgEntyAdrs addBillgEntyAdrs(BillgEntyAdrs billgEntyAdrs) {
		getBillgEntyAdrs().add(billgEntyAdrs);
		billgEntyAdrs.setAdrs(this);

		return billgEntyAdrs;
	}

	public BillgEntyAdrs removeBillgEntyAdrs(BillgEntyAdrs billgEntyAdrs) {
		getBillgEntyAdrs().remove(billgEntyAdrs);
		billgEntyAdrs.setAdrs(null);

		return billgEntyAdrs;
	}

	public List<GrpAdr> getGrpAdrs() {
		return this.grpAdrs;
	}

	public void setGrpAdrs(List<GrpAdr> grpAdrs) {
		this.grpAdrs = grpAdrs;
	}

	public GrpAdr addGrpAdr(GrpAdr grpAdr) {
		getGrpAdrs().add(grpAdr);
		grpAdr.setAdrs(this);

		return grpAdr;
	}

	public GrpAdr removeGrpAdr(GrpAdr grpAdr) {
		getGrpAdrs().remove(grpAdr);
		grpAdr.setAdrs(null);

		return grpAdr;
	}

	public List<GrpCntctPrsnAdr> getGrpCntctPrsnAdrs() {
		return this.grpCntctPrsnAdrs;
	}

	public void setGrpCntctPrsnAdrs(List<GrpCntctPrsnAdr> grpCntctPrsnAdrs) {
		this.grpCntctPrsnAdrs = grpCntctPrsnAdrs;
	}

	public GrpCntctPrsnAdr addGrpCntctPrsnAdr(GrpCntctPrsnAdr grpCntctPrsnAdr) {
		getGrpCntctPrsnAdrs().add(grpCntctPrsnAdr);
		grpCntctPrsnAdr.setAdrs(this);

		return grpCntctPrsnAdr;
	}

	public GrpCntctPrsnAdr removeGrpCntctPrsnAdr(GrpCntctPrsnAdr grpCntctPrsnAdr) {
		getGrpCntctPrsnAdrs().remove(grpCntctPrsnAdr);
		grpCntctPrsnAdr.setAdrs(null);

		return grpCntctPrsnAdr;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "Adrs [adrsId=" + adrsId + ", adrsLine1Txt=" + adrsLine1Txt + ", adrsLine2Txt=" + adrsLine2Txt
				+ ", adrsLine3Txt=" + adrsLine3Txt + ", adrsLine4Txt=" + adrsLine4Txt + ", cityNm=" + cityNm
				+ ", cntryCd=" + cntryCd + ", cntyCd=" + cntyCd + ", creatdByUserId=" + creatdByUserId + ", creatdDtm="
				+ creatdDtm + ", lastUpdtdDtm="+(lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null)+", frgnPostlCd=" + frgnPostlCd + ", stCd=" + stCd + ", vrsnNbr=" + vrsnNbr + ", zipCd="
				+ zipCd + ", zipPlusFourCd=" + zipPlusFourCd + ", zipTwoCd=" + zipTwoCd + "]";
	}

	/*public Cntrct getCntrct() {
		return cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}*/
	
	
	

}
