package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the RFRNC_DATA_ITEM database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="RFRNC_DATA_ITEM")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RfrncDataItem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="RFRNC_DATA_ITEM_ID")
	private long rfrncDataItemId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="DESC_TXT")
	private String descTxt;

	@Column(name="ITEM_NM")
	private String itemNm;

	@Column(name="ITEM_TYPE_CD")
	private String itemTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LFCYCL_STTS_CD")
	private String lfcyclSttsCd;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_EFCTV_DT")
	private Date lfcyclSttsEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_TRMNTN_DT")
	private Date lfcyclSttsTrmntnDt;

	@Column(name="SYS_ID")
	private BigDecimal sysId;

	@Column(name="UPDT_IND")
	private String updtInd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to CdVal
	@OneToMany(mappedBy="rfrncDataItem")
	private List<CdVal> cdVals;

	//bi-directional many-to-one association to RfrncDataItemAddnlAtrb
	@OneToMany(mappedBy="rfrncDataItem")
	private List<RfrncDataItemAddnlAtrb> rfrncDataItemAddnlAtrbs;

	public RfrncDataItem() {
	}

	public long getRfrncDataItemId() {
		return this.rfrncDataItemId;
	}

	public void setRfrncDataItemId(long rfrncDataItemId) {
		this.rfrncDataItemId = rfrncDataItemId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getDescTxt() {
		return this.descTxt;
	}

	public void setDescTxt(String descTxt) {
		this.descTxt = descTxt;
	}

	public String getItemNm() {
		return this.itemNm;
	}

	public void setItemNm(String itemNm) {
		this.itemNm = itemNm;
	}

	public String getItemTypeCd() {
		return this.itemTypeCd;
	}

	public void setItemTypeCd(String itemTypeCd) {
		this.itemTypeCd = itemTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLfcyclSttsCd() {
		return this.lfcyclSttsCd;
	}

	public void setLfcyclSttsCd(String lfcyclSttsCd) {
		this.lfcyclSttsCd = lfcyclSttsCd;
	}

	public Date getLfcyclSttsEfctvDt() {
		return this.lfcyclSttsEfctvDt;
	}

	public void setLfcyclSttsEfctvDt(Date lfcyclSttsEfctvDt) {
		this.lfcyclSttsEfctvDt = lfcyclSttsEfctvDt;
	}

	public Date getLfcyclSttsTrmntnDt() {
		return this.lfcyclSttsTrmntnDt;
	}

	public void setLfcyclSttsTrmntnDt(Date lfcyclSttsTrmntnDt) {
		this.lfcyclSttsTrmntnDt = lfcyclSttsTrmntnDt;
	}

	public BigDecimal getSysId() {
		return this.sysId;
	}

	public void setSysId(BigDecimal sysId) {
		this.sysId = sysId;
	}

	public String getUpdtInd() {
		return this.updtInd;
	}

	public void setUpdtInd(String updtInd) {
		this.updtInd = updtInd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public List<CdVal> getCdVals() {
		return this.cdVals;
	}

	public void setCdVals(List<CdVal> cdVals) {
		this.cdVals = cdVals;
	}

	public CdVal addCdVal(CdVal cdVal) {
		getCdVals().add(cdVal);
		cdVal.setRfrncDataItem(this);

		return cdVal;
	}

	public CdVal removeCdVal(CdVal cdVal) {
		getCdVals().remove(cdVal);
		cdVal.setRfrncDataItem(null);

		return cdVal;
	}

	public List<RfrncDataItemAddnlAtrb> getRfrncDataItemAddnlAtrbs() {
		return this.rfrncDataItemAddnlAtrbs;
	}

	public void setRfrncDataItemAddnlAtrbs(List<RfrncDataItemAddnlAtrb> rfrncDataItemAddnlAtrbs) {
		this.rfrncDataItemAddnlAtrbs = rfrncDataItemAddnlAtrbs;
	}

	public RfrncDataItemAddnlAtrb addRfrncDataItemAddnlAtrb(RfrncDataItemAddnlAtrb rfrncDataItemAddnlAtrb) {
		getRfrncDataItemAddnlAtrbs().add(rfrncDataItemAddnlAtrb);
		rfrncDataItemAddnlAtrb.setRfrncDataItem(this);

		return rfrncDataItemAddnlAtrb;
	}

	public RfrncDataItemAddnlAtrb removeRfrncDataItemAddnlAtrb(RfrncDataItemAddnlAtrb rfrncDataItemAddnlAtrb) {
		getRfrncDataItemAddnlAtrbs().remove(rfrncDataItemAddnlAtrb);
		rfrncDataItemAddnlAtrb.setRfrncDataItem(null);

		return rfrncDataItemAddnlAtrb;
	}

}