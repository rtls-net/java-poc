package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the CNTRCT_PLAN_SPCLTY_VOL_MLTPLR database table.
 * 
 */
@Entity
@Table(name = "CNTRCT_PLAN_SPCLTY_VOL_MLTPLR")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class CntrctPlanSpcltyVolMltplr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "CNTRCT_PLAN_SPCLTY_VOL_MLT_ID")
	private Long cntrctPlanSpcltyVolMltId;
	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;
	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "FMLY_MBR_TYPE_CD")
	private String fmlyMbrTypeCd;
	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	private BigDecimal val;

	@Column(name = "VOL_MLTPLR_TYPE_CD")
	private String volMltplrTypeCd;
	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	// bi-directional many-to-one association to CntrctPlanSpclty
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_PLAN_SPCLTY_ID")
	private CntrctPlanSpclty cntrctPlanSpclty;

	public CntrctPlanSpcltyVolMltplr() {
	}

	public Long getCntrctPlanSpcltyVolMltId() {
		return this.cntrctPlanSpcltyVolMltId;
	}

	public void setCntrctPlanSpcltyVolMltId(Long cntrctPlanSpcltyVolMltId) {
		this.cntrctPlanSpcltyVolMltId = cntrctPlanSpcltyVolMltId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getFmlyMbrTypeCd() {
		return this.fmlyMbrTypeCd;
	}

	public void setFmlyMbrTypeCd(String fmlyMbrTypeCd) {
		this.fmlyMbrTypeCd = fmlyMbrTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public BigDecimal getVal() {
		return this.val;
	}

	public void setVal(BigDecimal val) {
		this.val = val;
	}

	public String getVolMltplrTypeCd() {
		return this.volMltplrTypeCd;
	}

	public void setVolMltplrTypeCd(String volMltplrTypeCd) {
		this.volMltplrTypeCd = volMltplrTypeCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public CntrctPlanSpclty getCntrctPlanSpclty() {
		return this.cntrctPlanSpclty;
	}

	public void setCntrctPlanSpclty(CntrctPlanSpclty cntrctPlanSpclty) {
		this.cntrctPlanSpclty = cntrctPlanSpclty;
	}

}