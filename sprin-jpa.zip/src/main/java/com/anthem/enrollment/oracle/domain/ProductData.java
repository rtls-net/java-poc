package com.anthem.enrollment.oracle.domain;

import java.util.List;

public class ProductData {

    public GrpHc grpHc;

    public GrpHc getGrpHc() {
        return grpHc;
    }

    public void setGrpHc(GrpHc grpHc) {
        this.grpHc = grpHc;
    }
    /**
     * The cntrct.
     */
    private Cntrct cntrct;
    /**
     * The cntrct plan.
     */
    private CntrctPlan cntrctPlan;
    /**
     * The cntrct plan rt.
     */
    private CntrctPlanRt cntrctPlanRt;
    /**
     * The grp cntrct prvsn.
     */
    private GrpCntrctPrvsn grpCntrctPrvsn;
    
    private CntrctPlanProvNtwk cntrctPlanProvNtwk;
    
    private GrpMnthlyCntrbtn grpMnthlyCntrbtn;
    
    private List<GrpPrbtnPrd> grpPrbtnPrdList;
    
    private CntrctAdrs cntrctAdrs;
    
    private CntrctTlphn cntrctTlphn;
    
    private Adrs adrs;

    /**
     * Gets the cntrct.
     *
     * @return Cntrct
     */
    public Cntrct getCntrct() {
        return cntrct;
    }

    /**
     * Sets the cntrct.
     *
     * @param cntrct the new cntrct
     */
    public void setCntrct(Cntrct cntrct) {
        this.cntrct = cntrct;
    }

    /**
     * Gets the cntrct plan.
     *
     * @return CntrctPlan
     */
    public CntrctPlan getCntrctPlan() {
        return cntrctPlan;
    }

    /**
     * Sets the cntrct plan.
     *
     * @param cntrctPlan the new cntrct plan
     */
    public void setCntrctPlan(CntrctPlan cntrctPlan) {
        this.cntrctPlan = cntrctPlan;
    }

    /**
     * Gets the cntrct plan rt.
     *
     * @return CntrctPlanRt
     */
    public CntrctPlanRt getCntrctPlanRt() {
        return cntrctPlanRt;
    }

    /**
     * Sets the cntrct plan rt.
     *
     * @param cntrctPlanRt the new cntrct plan rt
     */
    public void setCntrctPlanRt(CntrctPlanRt cntrctPlanRt) {
        this.cntrctPlanRt = cntrctPlanRt;
    }

    /**
     * Gets the group cntrct prvsn.
     *
     * @return GrpCntrctPrvsn
     */
    public GrpCntrctPrvsn getGrpCntrctPrvsn() {
        return grpCntrctPrvsn;
    }

    /**
     * Sets the group cntrct prvsn.
     *
     * @param grpCntrctPrvsn the new group cntrct prvsn
     */
    public void setGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
        this.grpCntrctPrvsn = grpCntrctPrvsn;
    }

    /** The cntrct billg enty. */
    public CntrctBillgEnty cntrctBillgEnty;

    /**
     * Gets the cntrct billg enty.
     *
     * @return CntrctBillgEnty
     */
    public CntrctBillgEnty getCntrctBillgEnty() {
        return cntrctBillgEnty;
    }

    /**
     * Sets the cntrct billg enty.
     *
     * @param cntrctBillgEnty the new cntrct billg enty
     */
    public void setCntrctBillgEnty(CntrctBillgEnty cntrctBillgEnty) {
        this.cntrctBillgEnty = cntrctBillgEnty;
    }

	public CntrctPlanProvNtwk getCntrctPlanProvNtwk() {
		return cntrctPlanProvNtwk;
	}

	public void setCntrctPlanProvNtwk(CntrctPlanProvNtwk cntrctPlanProvNtwk) {
		this.cntrctPlanProvNtwk = cntrctPlanProvNtwk;
	}

	public GrpMnthlyCntrbtn getGrpMnthlyCntrbtn() {
		return grpMnthlyCntrbtn;
	}
	
	public List<GrpPrbtnPrd> getGrpPrbtnPrdList() {
		return grpPrbtnPrdList;
	}

	public void setGrpPrbtnPrdList(List<GrpPrbtnPrd> grpPrbtnPrdList) {
		this.grpPrbtnPrdList = grpPrbtnPrdList;
	}

	public void setGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		this.grpMnthlyCntrbtn = grpMnthlyCntrbtn;
	}

	public CntrctAdrs getCntrctAdrs() {
		return cntrctAdrs;
	}

	public void setCntrctAdrs(CntrctAdrs cntrctAdrs) {
		this.cntrctAdrs = cntrctAdrs;
	}

	public CntrctTlphn getCntrctTlphn() {
		return cntrctTlphn;
	}

	public void setCntrctTlphn(CntrctTlphn cntrctTlphn) {
		this.cntrctTlphn = cntrctTlphn;
	}

	public Adrs getAdrs() {
		return adrs;
	}

	public void setAdrs(Adrs adrs) {
		this.adrs = adrs;
	}

}
