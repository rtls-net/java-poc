package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the GRP_TLPHN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_TLPHN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpTlphn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_TLPHN_ID")
	private Long grpTlphnId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_DNC_EFCTV_DT")
	private Date grpDncEfctvDt;

	@Column(name="GRP_DNC_IND_CD")
	private String grpDncIndCd;

	@Column(name="GRP_TLPHN_CNTRY_CD")
	private String grpTlphnCntryCd;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_TLPHN_EFCTV_DT")
	private Date grpTlphnEfctvDt;

	@Column(name="GRP_TLPHN_NBR")
	private String grpTlphnNbr;

	@Column(name="GRP_TLPHN_EXT_NBR")
	private String gprTlphnExtNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_TLPHN_TRMNTN_DT")
	private Date grpTlphnTrmntnDt;

	@Column(name="GRP_TLPHN_TYPE_CD")
	private String grpTlphnTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
//	@JsonIgnore
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpTlphn() {
	}

	public Long getGrpTlphnId() {
		return this.grpTlphnId;
	}

	public void setGrpTlphnId(Long grpTlphnId) {
		this.grpTlphnId = grpTlphnId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpDncEfctvDt() {
		return this.grpDncEfctvDt;
	}

	public void setGrpDncEfctvDt(Date grpDncEfctvDt) {
		this.grpDncEfctvDt = grpDncEfctvDt;
	}

	public String getGrpDncIndCd() {
		return this.grpDncIndCd;
	}

	public void setGrpDncIndCd(String grpDncIndCd) {
		this.grpDncIndCd = grpDncIndCd;
	}

	public String getGrpTlphnCntryCd() {
		return this.grpTlphnCntryCd;
	}

	public void setGrpTlphnCntryCd(String grpTlphnCntryCd) {
		this.grpTlphnCntryCd = grpTlphnCntryCd;
	}

	public Date getGrpTlphnEfctvDt() {
		return this.grpTlphnEfctvDt;
	}

	public void setGrpTlphnEfctvDt(Date grpTlphnEfctvDt) {
		this.grpTlphnEfctvDt = grpTlphnEfctvDt;
	}

	public String getGrpTlphnNbr() {
		return this.grpTlphnNbr;
	}

	public void setGrpTlphnNbr(String grpTlphnNbr) {
		this.grpTlphnNbr = grpTlphnNbr;
	}

	public Date getGrpTlphnTrmntnDt() {
		return this.grpTlphnTrmntnDt;
	}

	public void setGrpTlphnTrmntnDt(Date grpTlphnTrmntnDt) {
		this.grpTlphnTrmntnDt = grpTlphnTrmntnDt;
	}

	public String getGrpTlphnTypeCd() {
		return this.grpTlphnTypeCd;
	}

	public void setGrpTlphnTypeCd(String grpTlphnTypeCd) {
		this.grpTlphnTypeCd = grpTlphnTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public String getGprTlphnExtNbr() {
		return gprTlphnExtNbr;
	}

	public void setGprTlphnExtNbr(String gprTlphnExtNbr) {
		this.gprTlphnExtNbr = gprTlphnExtNbr;
	}
}