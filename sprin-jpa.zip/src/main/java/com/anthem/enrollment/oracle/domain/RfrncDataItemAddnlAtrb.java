package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the RFRNC_DATA_ITEM_ADDNL_ATRB database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="RFRNC_DATA_ITEM_ADDNL_ATRB")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RfrncDataItemAddnlAtrb implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="RFRNC_DATA_ITEM_ADDNL_ATRB_ID")
	private long rfrncDataItemAddnlAtrbId;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDNL_ATRB_EFCTV_DT")
	private Date addnlAtrbEfctvDt;

	@Column(name="ADDNL_ATRB_NM_CD")
	private String addnlAtrbNmCd;

	@Column(name="ADDNL_ATRB_NM_DESC_TXT")
	private String addnlAtrbNmDescTxt;

	@Column(name="ADDNL_ATRB_SQNC_NBR")
	private BigDecimal addnlAtrbSqncNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDNL_ATRB_TRMNTN_DT")
	private Date addnlAtrbTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="UPDT_IND")
	private String updtInd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to RfrncDataItem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RFRNC_DATA_ITEM_ID")
	private RfrncDataItem rfrncDataItem;

	//bi-directional many-to-one association to RfrncDataItemAddnlAtrbVal
	@OneToMany(mappedBy="rfrncDataItemAddnlAtrb")
	private List<RfrncDataItemAddnlAtrbVal> rfrncDataItemAddnlAtrbVals;

	public RfrncDataItemAddnlAtrb() {
	}

	public long getRfrncDataItemAddnlAtrbId() {
		return this.rfrncDataItemAddnlAtrbId;
	}

	public void setRfrncDataItemAddnlAtrbId(long rfrncDataItemAddnlAtrbId) {
		this.rfrncDataItemAddnlAtrbId = rfrncDataItemAddnlAtrbId;
	}

	public Date getAddnlAtrbEfctvDt() {
		return this.addnlAtrbEfctvDt;
	}

	public void setAddnlAtrbEfctvDt(Date addnlAtrbEfctvDt) {
		this.addnlAtrbEfctvDt = addnlAtrbEfctvDt;
	}

	public String getAddnlAtrbNmCd() {
		return this.addnlAtrbNmCd;
	}

	public void setAddnlAtrbNmCd(String addnlAtrbNmCd) {
		this.addnlAtrbNmCd = addnlAtrbNmCd;
	}

	public String getAddnlAtrbNmDescTxt() {
		return this.addnlAtrbNmDescTxt;
	}

	public void setAddnlAtrbNmDescTxt(String addnlAtrbNmDescTxt) {
		this.addnlAtrbNmDescTxt = addnlAtrbNmDescTxt;
	}

	public BigDecimal getAddnlAtrbSqncNbr() {
		return this.addnlAtrbSqncNbr;
	}

	public void setAddnlAtrbSqncNbr(BigDecimal addnlAtrbSqncNbr) {
		this.addnlAtrbSqncNbr = addnlAtrbSqncNbr;
	}

	public Date getAddnlAtrbTrmntnDt() {
		return this.addnlAtrbTrmntnDt;
	}

	public void setAddnlAtrbTrmntnDt(Date addnlAtrbTrmntnDt) {
		this.addnlAtrbTrmntnDt = addnlAtrbTrmntnDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getUpdtInd() {
		return this.updtInd;
	}

	public void setUpdtInd(String updtInd) {
		this.updtInd = updtInd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public RfrncDataItem getRfrncDataItem() {
		return this.rfrncDataItem;
	}

	public void setRfrncDataItem(RfrncDataItem rfrncDataItem) {
		this.rfrncDataItem = rfrncDataItem;
	}

	public List<RfrncDataItemAddnlAtrbVal> getRfrncDataItemAddnlAtrbVals() {
		return this.rfrncDataItemAddnlAtrbVals;
	}

	public void setRfrncDataItemAddnlAtrbVals(List<RfrncDataItemAddnlAtrbVal> rfrncDataItemAddnlAtrbVals) {
		this.rfrncDataItemAddnlAtrbVals = rfrncDataItemAddnlAtrbVals;
	}

	public RfrncDataItemAddnlAtrbVal addRfrncDataItemAddnlAtrbVal(RfrncDataItemAddnlAtrbVal rfrncDataItemAddnlAtrbVal) {
		getRfrncDataItemAddnlAtrbVals().add(rfrncDataItemAddnlAtrbVal);
		rfrncDataItemAddnlAtrbVal.setRfrncDataItemAddnlAtrb(this);

		return rfrncDataItemAddnlAtrbVal;
	}

	public RfrncDataItemAddnlAtrbVal removeRfrncDataItemAddnlAtrbVal(RfrncDataItemAddnlAtrbVal rfrncDataItemAddnlAtrbVal) {
		getRfrncDataItemAddnlAtrbVals().remove(rfrncDataItemAddnlAtrbVal);
		rfrncDataItemAddnlAtrbVal.setRfrncDataItemAddnlAtrb(null);

		return rfrncDataItemAddnlAtrbVal;
	}

}