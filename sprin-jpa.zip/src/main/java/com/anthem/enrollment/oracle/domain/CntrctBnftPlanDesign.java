package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CNTRCT_BNFT_PLAN_DESIGN database table.
 * 
 */
@Entity
@Table(name="CNTRCT_BNFT_PLAN_DESIGN")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctBnftPlanDesign implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CNTRCT_PLAN_ID")
	private Long cntrctPlanId;

	@Column(name="BEN_DUR_CD")
	private String benDurCd;

	@Column(name="DEF_OF_DISABLTY")
	private String defOfDisablty;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_END_DT")
	private Date effEndDt;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_START_DT")
	private Date effStartDt;

	@Column(name="ELM_PERIOD")
	private BigDecimal elmPeriod;

	@Column(name="ELM_PERIOD_ACC")
	private String elmPeriodAcc;

	@Column(name="ELM_PERIOD_ILL")
	private String elmPeriodIll;

	@Column(name="GROSS_IND")
	private String grossInd;

	@Column(name="MAX_BNFT")
	private BigDecimal maxBnft;

	@Column(name="PRE_EXSTG_COND")
	private String preExstgCond;

	@Column(name="PRE_EXSTG_COND_OTHRS")
	private String preExstgCondOthrs;

	@Column(name="STATUS_CD")
	private String statusCd;

	public CntrctBnftPlanDesign() {
	}

	public Long getCntrctPlanId() {
		return this.cntrctPlanId;
	}

	public void setCntrctPlanId(Long cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}

	public String getBenDurCd() {
		return this.benDurCd;
	}

	public void setBenDurCd(String benDurCd) {
		this.benDurCd = benDurCd;
	}

	public String getDefOfDisablty() {
		return this.defOfDisablty;
	}

	public void setDefOfDisablty(String defOfDisablty) {
		this.defOfDisablty = defOfDisablty;
	}

	public Date getEffEndDt() {
		return this.effEndDt;
	}

	public void setEffEndDt(Date effEndDt) {
		this.effEndDt = effEndDt;
	}

	public Date getEffStartDt() {
		return this.effStartDt;
	}

	public void setEffStartDt(Date effStartDt) {
		this.effStartDt = effStartDt;
	}

	public BigDecimal getElmPeriod() {
		return this.elmPeriod;
	}

	public void setElmPeriod(BigDecimal elmPeriod) {
		this.elmPeriod = elmPeriod;
	}

	public String getElmPeriodAcc() {
		return this.elmPeriodAcc;
	}

	public void setElmPeriodAcc(String elmPeriodAcc) {
		this.elmPeriodAcc = elmPeriodAcc;
	}

	public String getElmPeriodIll() {
		return this.elmPeriodIll;
	}

	public void setElmPeriodIll(String elmPeriodIll) {
		this.elmPeriodIll = elmPeriodIll;
	}

	public String getGrossInd() {
		return this.grossInd;
	}

	public void setGrossInd(String grossInd) {
		this.grossInd = grossInd;
	}

	public BigDecimal getMaxBnft() {
		return this.maxBnft;
	}

	public void setMaxBnft(BigDecimal maxBnft) {
		this.maxBnft = maxBnft;
	}

	public String getPreExstgCond() {
		return this.preExstgCond;
	}

	public void setPreExstgCond(String preExstgCond) {
		this.preExstgCond = preExstgCond;
	}

	public String getPreExstgCondOthrs() {
		return this.preExstgCondOthrs;
	}

	public void setPreExstgCondOthrs(String preExstgCondOthrs) {
		this.preExstgCondOthrs = preExstgCondOthrs;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}