package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the GRP_INDCTV database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_INDCTV")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class GrpIndctv implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_INDCTV_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private long grpIndctvId;

	@Column(name="ADMNSTRTV_NATL_CARE_NTWK_CD")
	private String admnstrtvNatlCareNtwkCd;

	@Column(name="ALT_CORDNTN_OF_BNFT_CD")
	private String altCordntnOfBnftCd;

	@Column(name="ANL_RPT_MNTH_NBR")
	private BigDecimal anlRptMnthNbr;

	@Column(name="BNDLG_IND_CD")
	private String bndlgIndCd;

	@Column(name="CLM_CTGRY_CD")
	private String clmCtgryCd;

	@Column(name="CLM_FUNDG_OFF_CD")
	private String clmFundgOffCd;

	@Column(name="CMPLNC_IND_CD")
	private String cmplncIndCd;

	@Column(name="COB_ADMIN_IND_CD")
	private String cobAdminIndCd;

	@Column(name="COB_BIRTHDATE_RULE_CD")
	private String cobBirthdateRuleCd;

	@Column(name="COBRA_ADMNSTRN_SRVCS_CD")
	private String cobraAdmnstrnSrvcsCd;

	@Column(name="COBRA_BNFTS_CD")
	private String cobraBnftsCd;

	@Column(name="CORDNTN_OF_BNFT_MNTH_NBR")
	private BigDecimal cordntnOfBnftMnthNbr;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="CSTM_KEY_ACS_CD")
	private String cstmKeyAcsCd;

	@Column(name="EAP_IND_CD")
	private String eapIndCd;

	@Column(name="ENROLMENT_TYPE_CD")
	private String enrolmentTypeCd;

	@Column(name="ERISA_CD")
	private String erisaCd;

	@Column(name="EXCHNG_GRP_IND_CD")
	private String exchngGrpIndCd;

	@Column(name="FULL_DPNDNT_ELGBLTY_CD")
	private String fullDpndntElgbltyCd;

	//@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="GRP_IND_EFCTV_DT")
	private Date grpIndEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_IND_TRMNTN_DT")
	private Date grpIndTrmntnDt;

	@Column(name="HIPAA_LTR_EXCLSN_CD")
	private String hipaaLtrExclsnCd;

	@Column(name="HLTH_SVNG_ACCT_BANK_OPT_IND_CD")
	private String hlthSvngAcctBankOptIndCd;

	//@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="LAST_ANIV_DT")
	private Date lastAnivDt;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="MDCL_LOCK_DNTL_IND_CD")
	private String mdclLockDntlIndCd;

	@Column(name="MDCL_LOCK_VSN_IND_CD")
	private String mdclLockVsnIndCd;

	@Column(name="MEDCR_PRMRY_AND_SCNDRY_CD")
	private String medcrPrmryAndScndryCd;

	@Column(name="MNTHLY_HLTH_STMNT_IND_CD")
	private String mnthlyHlthStmntIndCd;

	@Column(name="MPP_INSRNC_RNOUT_CD")
	private String mppInsrncRnoutCd;

	@Column(name="NATL_PAID_CLMS_CD")
	private String natlPaidClmsCd;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="NEXT_ANIV_DT")
	private Date nextAnivDt;

	@Column(name="OTHR_ST_IND_CD")
	private String othrStIndCd;

	@Column(name="OVRPYMT_SRVC_CD")
	private String ovrpymtSrvcCd;

	@Column(name="PAPRLS_EOB_EXCLD_CD")
	private String paprlsEobExcldCd;

	@Column(name="PART_TM_IND_CD")
	private String partTmIndCd;

	@Column(name="PFOL_IND_CD")
	private String pfolIndCd;

	@Column(name="PRIOR_DNTL_CVRG_IND_CD")
	private String priorDntlCvrgIndCd;

	@Column(name="PRIOR_VSN_CVRG_CD")
	private String priorVsnCvrgCd;

	@Column(name="RUN_IN_CLMS_CD")
	private String runInClmsCd;

	@Column(name="RUN_OUT_OF_CLMS_CD")
	private String runOutOfClmsCd;

	@Column(name="SESSIONAL_IND_CD")
	private String sessionalIndCd;

	@Column(name="SPECIALITY_COV_ALLOW_IND")
	private String specialityCovAllowInd;

	@Column(name="VNDR_RFRL_CD")
	private String vndrRfrlCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name="NON_PAR_PROV_PRCG_CD")
	private String ncnReferalInd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="NON_PAR_PROV_PRCG_EFCTV_DT")
	private Date ncnEfctvDt;

	@Column(name="NON_PAR_PROV_PRCG_SYS_CD")
	private String clmsVendor1;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="NON_PAR_PROV_PRCG_SYS_EFCTV_DT")
	private Date vendor1EffDt;
	
	@Column(name = "CONV_CD")
	private String convCd;

	//LIT-4643 - Domestic Partner Ind
	@Column(name="OAD_RDR_CD")
	private String oadInd;

	/**The Domestic Partner Indicator**/
	@Column(name="DMSTC_PRTNR_IND_CD")
	private String dmstcPrtnrInd;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpIndctv() {
	}

	public long getGrpIndctvId() {
		return this.grpIndctvId;
	}

	public void setGrpIndctvId(long grpIndctvId) {
		this.grpIndctvId = grpIndctvId;
	}

	public String getAdmnstrtvNatlCareNtwkCd() {
		return this.admnstrtvNatlCareNtwkCd;
	}

	public void setAdmnstrtvNatlCareNtwkCd(String admnstrtvNatlCareNtwkCd) {
		this.admnstrtvNatlCareNtwkCd = admnstrtvNatlCareNtwkCd;
	}

	public String getAltCordntnOfBnftCd() {
		return this.altCordntnOfBnftCd;
	}

	public void setAltCordntnOfBnftCd(String altCordntnOfBnftCd) {
		this.altCordntnOfBnftCd = altCordntnOfBnftCd;
	}

	public BigDecimal getAnlRptMnthNbr() {
		return this.anlRptMnthNbr;
	}

	public void setAnlRptMnthNbr(BigDecimal anlRptMnthNbr) {
		this.anlRptMnthNbr = anlRptMnthNbr;
	}

	public String getBndlgIndCd() {
		return this.bndlgIndCd;
	}

	public void setBndlgIndCd(String bndlgIndCd) {
		this.bndlgIndCd = bndlgIndCd;
	}

	public String getClmCtgryCd() {
		return this.clmCtgryCd;
	}

	public void setClmCtgryCd(String clmCtgryCd) {
		this.clmCtgryCd = clmCtgryCd;
	}

	public String getClmFundgOffCd() {
		return this.clmFundgOffCd;
	}

	public void setClmFundgOffCd(String clmFundgOffCd) {
		this.clmFundgOffCd = clmFundgOffCd;
	}

	public String getCmplncIndCd() {
		return this.cmplncIndCd;
	}

	public void setCmplncIndCd(String cmplncIndCd) {
		this.cmplncIndCd = cmplncIndCd;
	}

	public String getCobAdminIndCd() {
		return this.cobAdminIndCd;
	}

	public void setCobAdminIndCd(String cobAdminIndCd) {
		this.cobAdminIndCd = cobAdminIndCd;
	}

	public String getCobBirthdateRuleCd() {
		return this.cobBirthdateRuleCd;
	}

	public void setCobBirthdateRuleCd(String cobBirthdateRuleCd) {
		this.cobBirthdateRuleCd = cobBirthdateRuleCd;
	}

	public String getCobraAdmnstrnSrvcsCd() {
		return this.cobraAdmnstrnSrvcsCd;
	}

	public void setCobraAdmnstrnSrvcsCd(String cobraAdmnstrnSrvcsCd) {
		this.cobraAdmnstrnSrvcsCd = cobraAdmnstrnSrvcsCd;
	}

	public String getCobraBnftsCd() {
		return this.cobraBnftsCd;
	}

	public void setCobraBnftsCd(String cobraBnftsCd) {
		this.cobraBnftsCd = cobraBnftsCd;
	}

	public BigDecimal getCordntnOfBnftMnthNbr() {
		return this.cordntnOfBnftMnthNbr;
	}

	public void setCordntnOfBnftMnthNbr(BigDecimal cordntnOfBnftMnthNbr) {
		this.cordntnOfBnftMnthNbr = cordntnOfBnftMnthNbr;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCstmKeyAcsCd() {
		return this.cstmKeyAcsCd;
	}

	public void setCstmKeyAcsCd(String cstmKeyAcsCd) {
		this.cstmKeyAcsCd = cstmKeyAcsCd;
	}

	public String getEapIndCd() {
		return this.eapIndCd;
	}

	public void setEapIndCd(String eapIndCd) {
		this.eapIndCd = eapIndCd;
	}

	public String getEnrolmentTypeCd() {
		return this.enrolmentTypeCd;
	}

	public void setEnrolmentTypeCd(String enrolmentTypeCd) {
		this.enrolmentTypeCd = enrolmentTypeCd;
	}

	public String getErisaCd() {
		return this.erisaCd;
	}

	public void setErisaCd(String erisaCd) {
		this.erisaCd = erisaCd;
	}

	public String getExchngGrpIndCd() {
		return this.exchngGrpIndCd;
	}

	public void setExchngGrpIndCd(String exchngGrpIndCd) {
		this.exchngGrpIndCd = exchngGrpIndCd;
	}

	public String getFullDpndntElgbltyCd() {
		return this.fullDpndntElgbltyCd;
	}

	public void setFullDpndntElgbltyCd(String fullDpndntElgbltyCd) {
		this.fullDpndntElgbltyCd = fullDpndntElgbltyCd;
	}

	public Date getGrpIndEfctvDt() {
		return this.grpIndEfctvDt;
	}

	public void setGrpIndEfctvDt(Date grpIndEfctvDt) {
		this.grpIndEfctvDt = grpIndEfctvDt;
	}

	public Date getGrpIndTrmntnDt() {
		return this.grpIndTrmntnDt;
	}

	public void setGrpIndTrmntnDt(Date grpIndTrmntnDt) {
		this.grpIndTrmntnDt = grpIndTrmntnDt;
	}

	public String getHipaaLtrExclsnCd() {
		return this.hipaaLtrExclsnCd;
	}

	public void setHipaaLtrExclsnCd(String hipaaLtrExclsnCd) {
		this.hipaaLtrExclsnCd = hipaaLtrExclsnCd;
	}

	public String getHlthSvngAcctBankOptIndCd() {
		
		return this.hlthSvngAcctBankOptIndCd;
	}

	public void setHlthSvngAcctBankOptIndCd(String hlthSvngAcctBankOptIndCd) {
		this.hlthSvngAcctBankOptIndCd = hlthSvngAcctBankOptIndCd;
	}

	public Date getLastAnivDt() {
		return this.lastAnivDt;
	}

	public void setLastAnivDt(Date lastAnivDt) {
		this.lastAnivDt = lastAnivDt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getMdclLockDntlIndCd() {
		return this.mdclLockDntlIndCd;
	}

	public void setMdclLockDntlIndCd(String mdclLockDntlIndCd) {
		this.mdclLockDntlIndCd = mdclLockDntlIndCd;
	}

	public String getMdclLockVsnIndCd() {
		return this.mdclLockVsnIndCd;
	}

	public void setMdclLockVsnIndCd(String mdclLockVsnIndCd) {
		this.mdclLockVsnIndCd = mdclLockVsnIndCd;
	}

	public String getMedcrPrmryAndScndryCd() {
		return this.medcrPrmryAndScndryCd;
	}

	public void setMedcrPrmryAndScndryCd(String medcrPrmryAndScndryCd) {
		this.medcrPrmryAndScndryCd = medcrPrmryAndScndryCd;
	}

	public String getMnthlyHlthStmntIndCd() {
		return this.mnthlyHlthStmntIndCd;
	}

	public void setMnthlyHlthStmntIndCd(String mnthlyHlthStmntIndCd) {
		this.mnthlyHlthStmntIndCd = mnthlyHlthStmntIndCd;
	}

	public String getMppInsrncRnoutCd() {
		return this.mppInsrncRnoutCd;
	}

	public void setMppInsrncRnoutCd(String mppInsrncRnoutCd) {
		this.mppInsrncRnoutCd = mppInsrncRnoutCd;
	}

	public String getNatlPaidClmsCd() {
		return this.natlPaidClmsCd;
	}

	public void setNatlPaidClmsCd(String natlPaidClmsCd) {
		this.natlPaidClmsCd = natlPaidClmsCd;
	}

	public Date getNextAnivDt() {
		return this.nextAnivDt;
	}

	public void setNextAnivDt(Date nextAnivDt) {
		this.nextAnivDt = nextAnivDt;
	}

	public String getOthrStIndCd() {
		return this.othrStIndCd;
	}

	public void setOthrStIndCd(String othrStIndCd) {
		this.othrStIndCd = othrStIndCd;
	}

	public String getOvrpymtSrvcCd() {
		return this.ovrpymtSrvcCd;
	}

	public void setOvrpymtSrvcCd(String ovrpymtSrvcCd) {
		this.ovrpymtSrvcCd = ovrpymtSrvcCd;
	}

	public String getPaprlsEobExcldCd() {
		return this.paprlsEobExcldCd;
	}

	public void setPaprlsEobExcldCd(String paprlsEobExcldCd) {
		this.paprlsEobExcldCd = paprlsEobExcldCd;
	}

	public String getPartTmIndCd() {
		return this.partTmIndCd;
	}

	public void setPartTmIndCd(String partTmIndCd) {
		this.partTmIndCd = partTmIndCd;
	}

	public String getPfolIndCd() {
		return this.pfolIndCd;
	}

	public void setPfolIndCd(String pfolIndCd) {
		this.pfolIndCd = pfolIndCd;
	}

	public String getPriorDntlCvrgIndCd() {
		return this.priorDntlCvrgIndCd;
	}

	public void setPriorDntlCvrgIndCd(String priorDntlCvrgIndCd) {
		this.priorDntlCvrgIndCd = priorDntlCvrgIndCd;
	}

	public String getPriorVsnCvrgCd() {
		return this.priorVsnCvrgCd;
	}

	public void setPriorVsnCvrgCd(String priorVsnCvrgCd) {
		this.priorVsnCvrgCd = priorVsnCvrgCd;
	}

	public String getRunInClmsCd() {
		return this.runInClmsCd;
	}

	public void setRunInClmsCd(String runInClmsCd) {
		this.runInClmsCd = runInClmsCd;
	}

	public String getRunOutOfClmsCd() {
		return this.runOutOfClmsCd;
	}

	public void setRunOutOfClmsCd(String runOutOfClmsCd) {
		this.runOutOfClmsCd = runOutOfClmsCd;
	}

	public String getSessionalIndCd() {
		return this.sessionalIndCd;
	}

	public void setSessionalIndCd(String sessionalIndCd) {
		this.sessionalIndCd = sessionalIndCd;
	}

	public String getSpecialityCovAllowInd() {
		return this.specialityCovAllowInd;
	}

	public void setSpecialityCovAllowInd(String specialityCovAllowInd) {
		this.specialityCovAllowInd = specialityCovAllowInd;
	}

	public String getVndrRfrlCd() {
		return this.vndrRfrlCd;
	}

	public void setVndrRfrlCd(String vndrRfrlCd) {
		this.vndrRfrlCd = vndrRfrlCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public String getNcnReferalInd() {
		return ncnReferalInd;
	}

	public void setNcnReferalInd(String ncnReferalInd) {
		this.ncnReferalInd = ncnReferalInd;
	}

	public Date getNcnEfctvDt() {
		return ncnEfctvDt;
	}

	public void setNcnEfctvDt(Date ncnEfctvDt) {
		this.ncnEfctvDt = ncnEfctvDt;
	}

	public String getClmsVendor1() {
		return clmsVendor1;
	}

	public void setClmsVendor1(String clmsVendor1) {
		this.clmsVendor1 = clmsVendor1;
	}

	public Date getVendor1EffDt() {
		return vendor1EffDt;
	}

	public void setVendor1EffDt(Date vendor1EffDt) {
		this.vendor1EffDt = vendor1EffDt;
	}

	public String getOadInd() {
		
		return oadInd;
	}

	public void setOadInd(String oadInd) {
		this.oadInd = oadInd;
	}

	/**
	 * @return the dmstcPrtnrInd
	 */
	public String getDmstcPrtnrInd() {
		return dmstcPrtnrInd;
	}

	/**
	 * @param dmstcPrtnrInd the dmstcPrtnrInd to set
	 */
	public void setDmstcPrtnrInd(String dmstcPrtnrInd) {
		this.dmstcPrtnrInd = dmstcPrtnrInd;
	}
	
	/**
	 * @return
	 */
	public String getConvCd() {
		return convCd;
	}

	/**
	 * @param conv_cd
	 */
	public void setConvCd(String convCd) {
		this.convCd = convCd;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpIndctv [grpIndctvId=" + grpIndctvId + ", admnstrtvNatlCareNtwkCd=" + admnstrtvNatlCareNtwkCd
				+ ", altCordntnOfBnftCd=" + altCordntnOfBnftCd + ", anlRptMnthNbr=" + anlRptMnthNbr + ", bndlgIndCd="
				+ bndlgIndCd + ", clmCtgryCd=" + clmCtgryCd + ", clmFundgOffCd=" + clmFundgOffCd + ", cmplncIndCd="
				+ cmplncIndCd + ", cobAdminIndCd=" + cobAdminIndCd + ", cobBirthdateRuleCd=" + cobBirthdateRuleCd
				+ ", cobraAdmnstrnSrvcsCd=" + cobraAdmnstrnSrvcsCd + ", cobraBnftsCd=" + cobraBnftsCd
				+ ", cordntnOfBnftMnthNbr=" + cordntnOfBnftMnthNbr + ", cstmKeyAcsCd=" + cstmKeyAcsCd + ", eapIndCd="
				+ eapIndCd + ", enrolmentTypeCd=" + enrolmentTypeCd + ", erisaCd=" + erisaCd + ", exchngGrpIndCd="
				+ exchngGrpIndCd + ", fullDpndntElgbltyCd=" + fullDpndntElgbltyCd + ", grpIndEfctvDt=" + (grpIndEfctvDt!=null?formatter.format(grpIndEfctvDt):null)
				+ ", grpIndTrmntnDt=" + (grpIndTrmntnDt!=null?formatter.format(grpIndTrmntnDt):null) + ", hipaaLtrExclsnCd=" + hipaaLtrExclsnCd
				+ ", hlthSvngAcctBankOptIndCd=" + hlthSvngAcctBankOptIndCd + ", lastAnivDt=" + (lastAnivDt!=null?formatter.format(lastAnivDt):null)
				+ ", lastUpdtdByUserId=" + lastUpdtdByUserId + ", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null) + ", mdclLockDntlIndCd="
				+ mdclLockDntlIndCd + ", mdclLockVsnIndCd=" + mdclLockVsnIndCd + ", medcrPrmryAndScndryCd="
				+ medcrPrmryAndScndryCd + ", mnthlyHlthStmntIndCd=" + mnthlyHlthStmntIndCd + ", mppInsrncRnoutCd="
				+ mppInsrncRnoutCd + ", natlPaidClmsCd=" + natlPaidClmsCd + ", nextAnivDt=" + (nextAnivDt!=null?formatter.format(nextAnivDt):null)
				+ ", othrStIndCd=" + othrStIndCd + ", ovrpymtSrvcCd=" + ovrpymtSrvcCd + ", paprlsEobExcldCd="
				+ paprlsEobExcldCd + ", partTmIndCd=" + partTmIndCd + ", pfolIndCd=" + pfolIndCd
				+ ", priorDntlCvrgIndCd=" + priorDntlCvrgIndCd + ", priorVsnCvrgCd=" + priorVsnCvrgCd + ", runInClmsCd="
				+ runInClmsCd + ", runOutOfClmsCd=" + runOutOfClmsCd + ", sessionalIndCd=" + sessionalIndCd
				+ ", specialityCovAllowInd=" + specialityCovAllowInd + ", vndrRfrlCd=" + vndrRfrlCd + ", vrsnNbr="
				+ vrsnNbr + ", ncnReferalInd=" + ncnReferalInd + ", ncnEfctvDt=" + (ncnEfctvDt!=null?formatter.format(ncnEfctvDt):null) + ", clmsVendor1="
				+ clmsVendor1 + ", vendor1EffDt=" + (vendor1EffDt!=null?formatter.format(vendor1EffDt):null) + ", convCd=" + convCd + ", oadInd=" + oadInd
				+ ", dmstcPrtnrInd=" + dmstcPrtnrInd + "]";
	}
	
	
}