package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the GRP_LANG database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_LANG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpLang implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_LANG_ID")
	private long grpLangId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="GRP_LANG_CD")
	private String grpLangCd;

	//@Temporal(TemporalType.DATE)
	@Column(name="GRP_LANG_EFCTV_DT")
	private Date grpLangEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_LANG_TRMNTN_DT")
	private Date grpLangTrmntnDt;

	@Column(name="GRP_LANG_TYPE_CD")
	private String grpLangTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to Grp
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpLang() {
	}

	public long getGrpLangId() {
		return this.grpLangId;
	}

	public void setGrpLangId(long grpLangId) {
		this.grpLangId = grpLangId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getGrpLangCd() {
		return this.grpLangCd;
	}

	public void setGrpLangCd(String grpLangCd) {
		this.grpLangCd = grpLangCd;
	}

	public Date getGrpLangEfctvDt() {
		return this.grpLangEfctvDt;
	}

	public void setGrpLangEfctvDt(Date grpLangEfctvDt) {
		this.grpLangEfctvDt = grpLangEfctvDt;
	}

	public Date getGrpLangTrmntnDt() {
		return this.grpLangTrmntnDt;
	}

	public void setGrpLangTrmntnDt(Date grpLangTrmntnDt) {
		this.grpLangTrmntnDt = grpLangTrmntnDt;
	}

	public String getGrpLangTypeCd() {
		return this.grpLangTypeCd;
	}

	public void setGrpLangTypeCd(String grpLangTypeCd) {
		this.grpLangTypeCd = grpLangTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}