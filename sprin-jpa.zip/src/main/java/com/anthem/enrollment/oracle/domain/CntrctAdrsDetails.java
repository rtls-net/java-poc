package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTRCT_ADRS")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctAdrsDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CNTRCT_ADRS_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctAdrsId;

	@Column(name="ADRS_ID")
	private long adrsId;
	
	@Column(name="CNTRCT_ID")
	private long cntrctId;
	
	@Column(name="ADRS_TYPE_CD")
	private String adrsTypeCd;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_ADRS_EFCTV_DT")
	private java.util.Date cntrctAdrsEfctvDt;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_ADRS_TRMNTN_DT")
	private java.util.Date cntrctAdrsTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	/*//bi-directional many-to-one association to Cntrct
	 @JsonIgnore
	 @OneToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	 @JoinColumn(name="CNTRCT_ID") 
	 private Cntrct cntrct;*/
	 
	/* @JsonIgnore
	 @OneToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	 @JoinColumn(name="ADRS_ID")
	 private Adrs adrs;*/
	 
	 

	public Long getCntrctAdrsId() {
		return cntrctAdrsId;
	}

	public void setCntrctAdrsId(Long cntrctAdrsId) {
		this.cntrctAdrsId = cntrctAdrsId;
	}

	public String getAdrsTypeCd() {
		return adrsTypeCd;
	}

	public void setAdrsTypeCd(String adrsTypeCd) {
		this.adrsTypeCd = adrsTypeCd;
	}

	public java.util.Date getCntrctAdrsEfctvDt() {
		return cntrctAdrsEfctvDt;
	}

	public void setCntrctAdrsEfctvDt(java.util.Date cntrctAdrsEfctvDt) {
		this.cntrctAdrsEfctvDt = cntrctAdrsEfctvDt;
	}

	public java.util.Date getCntrctAdrsTrmntnDt() {
		return cntrctAdrsTrmntnDt;
	}

	public void setCntrctAdrsTrmntnDt(java.util.Date cntrctAdrsTrmntnDt) {
		this.cntrctAdrsTrmntnDt = cntrctAdrsTrmntnDt;
	}

	public String getCreatdByUserId() {
		return creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public long getAdrsId() {
		return adrsId;
	}

	public void setAdrsId(long adrsId) {
		this.adrsId = adrsId;
	}

	public long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(long cntrctId) {
		this.cntrctId = cntrctId;
	}

	/*public Cntrct getCntrct() {
		return cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}*/

	/*public Adrs getAdrs() {
		return adrs;
	}

	public void setAdrs(Adrs adrs) {
		this.adrs = adrs;
	}*/
	
	

}