package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the CNTRCT_PLAN_SPCLTY database table.
 * 
 */
@Entity
@Table(name = "CNTRCT_PLAN_SPCLTY")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class CntrctPlanSpclty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "CNTRCT_PLAN_SPCLTY_ID")
	private Long cntrctPlanSpcltyId;

	@Column(name = "A_CB_MAX_VOL_AMT")
	private BigDecimal aCbMaxVolAmt;

	@Column(name = "A_CB_MIN_VOL_AMT")
	private BigDecimal aCbMinVolAmt;

	@Column(name = "ACCELERATED_DTH_BNFT_MAX_AMT")
	private BigDecimal acceleratedDthBnftMaxAmt;

	@Column(name = "ACCELERATED_DTH_BNFT_PCT")
	private BigDecimal acceleratedDthBnftPct;

	@Column(name = "ADB_MAX_AMT")
	private BigDecimal adbMaxAmt;

	@Column(name = "ADB_PCT_NBR")
	private BigDecimal adbPctNbr;

	@Column(name = "ADDNL_CVRG_CHLD_AMT")
	private BigDecimal addnlCvrgChldAmt;

	@Column(name = "ADDNL_CVRG_SBSCRBR_AMT")
	private BigDecimal addnlCvrgSbscrbrAmt;

	@Column(name = "ADDNL_CVRG_SPOUS_AMT")
	private BigDecimal addnlCvrgSpousAmt;

	@Column(name = "BNDLG_IND_CD")
	private String bndlgIndCd;

	@Column(name = "CHLD_CVRG_CALCN_TYPE_CD")
	private String chldCvrgCalcnTypeCd;

	@Column(name = "CHLD_DFRNTL_AMT")
	private BigDecimal chldDfrntlAmt;

	@Column(name = "CHLD_FLAT_RT")
	private String chldFlatRt;

	@Column(name = "CLS_LOC_ID")
	private String clsLocId;

	@Column(name = "CNTRCT_ID")
	private Long cntrctId;

	@Column(name = "CNTRCT_PLAN_CD")
	private String cntrctPlanCd;

	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_PLAN_EFCTV_DT")
	private Date cntrctPlanEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_PLAN_SPCLTY_EFCTV_DT")
	private Date cntrctPlanSpcltyEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_PLAN_SPCLTY_TRMNTN_DT")
	private Date cntrctPlanSpcltyTrmntnDt;
	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;
	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "CUTBK_FIXED_AGE")
	private BigDecimal cutbkFixedAge;

	@Column(name = "CUTBK_FIXED_PCT")
	private BigDecimal cutbkFixedPct;

	@Column(name = "CUTBK_FIXED_VOL")
	private BigDecimal cutbkFixedVol;

	@Column(name = "CUTBK_FRQNCY_CD")
	private String cutbkFrqncyCd;

	@Column(name = "CUTBK_I_MAX_VOL_AMT")
	private BigDecimal cutbkIMaxVolAmt;

	@Column(name = "CUTBK_I_MIN_VOL_AMT")
	private BigDecimal cutbkIMinVolAmt;

	@Column(name = "CUTBK_INCRMNT_NBR")
	private BigDecimal cutbkIncrmntNbr;

	@Column(name = "CUTBK_MAX_OCRNC_NBR")
	private BigDecimal cutbkMaxOcrncNbr;

	@Column(name = "CUTBK_O_MAX_VOL_AMT")
	private BigDecimal cutbkOMaxVolAmt;

	@Column(name = "CUTBK_O_MIN_VOL_AMT")
	private BigDecimal cutbkOMinVolAmt;

	@Column(name = "CUTBK_PCT")
	private BigDecimal cutbkPct;

	@Column(name = "CUTBK_VOL_AMT")
	private BigDecimal cutbkVolAmt;

	@Column(name = "CVRG_REPLCD_CD")
	private String cvrgReplcdCd;

	@Column(name = "EARNG_DEFN")
	private String earngDefn;

	@Column(name = "FLAT_PER_CHLD_VOL_NBR")
	private BigDecimal flatPerChldVolNbr;

	@Column(name = "FLAT_PER_SBSCRBR_VOL_NBR")
	private BigDecimal flatPerSbscrbrVolNbr;

	@Column(name = "FLAT_PER_SPOUS_VOL_NBR")
	private BigDecimal flatPerSpousVolNbr;

	@Temporal(TemporalType.DATE)
	@Column(name = "GI_EFCTV_DT")
	private Date giEfctvDt;

	@Column(name = "GI_OVER_CD")
	private String giOverInd;

	@Column(name = "GRNT_ISU_AMT")
	private BigDecimal grntIsuAmt;

	@Column(name = "GRP_EMP_VAL")
	private BigDecimal grpEmpVal;

	@Column(name = "GUARTE_ISSU_AMT")
	private BigDecimal guarteIssuAmt;

	@Column(name = "INCRMNTL_CVRG_CHLD_AMT")
	private BigDecimal incrmntlCvrgChldAmt;

	@Column(name = "INCRMNTL_CVRG_SBSCRBR_AMT")
	private BigDecimal incrmntlCvrgSbscrbrAmt;

	@Column(name = "INCRMNTL_CVRG_SPOUS_AMT")
	private BigDecimal incrmntlCvrgSpousAmt;
	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "MAX_AGE_NBR")
	private BigDecimal maxAgeNbr;

	@Column(name = "MAX_CHLD_PCT")
	private BigDecimal maxChldPct;

	@Column(name = "MAX_SPOUS_PCT")
	private BigDecimal maxSpousPct;

	@Column(name = "MAX_VOL_CHLD_AMT")
	private BigDecimal maxVolChldAmt;

	@Column(name = "MAX_VOL_SBSCRBR_AMT")
	private BigDecimal maxVolSbscrbrAmt;

	@Column(name = "MAX_VOL_SPOUS_AMT")
	private BigDecimal maxVolSpousAmt;

	@Column(name = "MIN_HOURS")
	private BigDecimal minHours;

	@Column(name = "MIN_VOL_CHLD_AMT")
	private BigDecimal minVolChldAmt;

	@Column(name = "MIN_VOL_SBSCRBR_AMT")
	private BigDecimal minVolSbscrbrAmt;

	@Column(name = "MIN_VOL_SPOUS_AMT")
	private BigDecimal minVolSpousAmt;

	@Column(name = "MJR_CVRG_CD")
	private String mjrCvrgCd;

	@Column(name = "MM_CD")
	private String mmCd;

	@Column(name = "NEW_BRN_CVRG_AMT")
	private BigDecimal newBrnCvrgAmt;

	@Column(name = "NWBRN_CVRG_AMT")
	private BigDecimal nwbrnCvrgAmt;

	@Column(name = "ON_LV_PRD_NBR")
	private BigDecimal onLvPrdNbr;

	@Column(name = "OPT_UPSEL_DISC")
	private String optUpselDisc;

	@Column(name = "POOL_CD")
	private String poolCd;

	@Column(name = "PRC_SIZE")
	private String prcSize;

	@Column(name = "PROD_FMLY_CD")
	private String prodFmlyCd;

	@Column(name = "PROD_NM")
	private String prodNm;

	@Column(name = "RDCTN_MIN_AMT")
	private BigDecimal rdctnMinAmt;

	@Column(name = "RDCTN_OCRNC_CD")
	private String rdctnOcrncCd;

	@Column(name = "RNDG_CD")
	private String rndgCd;

	@Column(name = "RNDG_MLTPL_CD")
	private String rndgMltplCd;

	@Column(name = "RNDG_MLTPL_NBR")
	private BigDecimal rndgMltplNbr;

	@Column(name = "ROUND_CD")
	private String roundCd;

	@Column(name = "ROUNDED_AFTR_CUTBK_NBR")
	private BigDecimal roundedAftrCutbkNbr;

	@Column(name = "RT_BANK_DSCNT")
	private BigDecimal rtBankDscnt;

	@Column(name = "SBSCRBR_CVRG_CALCN_TYPE_CD")
	private String sbscrbrCvrgCalcnTypeCd;

	@Column(name = "SBSCRBR_DFRNTL_AMT")
	private BigDecimal sbscrbrDfrntlAmt;

	@Column(name = "SBSCRBR_GUARTE_ISSU_AMT")
	private BigDecimal sbscrbrGuarteIssuAmt;

	@Column(name = "SLRY_FRQNCY_CD")
	private String slryFrqncyCd;

	@Column(name = "SPCLTY_CLS_CD")
	private String spcltyClsCd;

	@Column(name = "SPOUS_CUT_BK")
	private String spousCutBk;

	@Column(name = "SPOUS_CUTBK_CD")
	private String spousCutbkCd;

	@Column(name = "SPOUS_CVRG_CALCN_TYPE_CD")
	private String spousCvrgCalcnTypeCd;

	@Column(name = "SPOUS_DFRNTL_AMT")
	private BigDecimal spousDfrntlAmt;

	@Column(name = "SPOUS_FLAT_RT")
	private String spousFlatRt;
	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name = "WOP_TPD_CD")
	private String wopTpdCd;

	@Column(name = "WOP_WAITG_PRD_NBR")
	private BigDecimal wopWaitgPrdNbr;

	@Column(name = "WOP_WVR_AGE")
	private BigDecimal wopWvrAge;

	@Column(name = "WOP_WVR_TRMNTN_AGE")
	private BigDecimal wopWvrTrmntnAge;

	@Column(name = "WVR_MNTH")
	private BigDecimal wvrMnth;

	@Column(name = "WVR_TRMNTN_AGE")
	private BigDecimal wvrTrmntnAge;

	//@Column(name = "MAX_CHLD_PCT")
	//private BigDecimal maxDependentPercentage;

	@Column(name = "SPOUS_GUARTE_ISSU_AMT")
    //@Transient
	private BigDecimal spouseGuaranteeIssueAmount;

	@Column(name = "CHLD_GUARTE_ISSU_AMT")
    //@Transient
	private BigDecimal childGuaranteeIssueAmount;

	// bi-directional many-to-one association to CntrctPlan
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_PLAN_ID")
	private CntrctPlan cntrctPlan;

	// bi-directional many-to-one association to CntrctBnftPlanAgeReduction
	@JsonIgnore
	@OneToMany(mappedBy = "cntrctPlanSpclty")
	private List<CntrctBnftPlanAgeReduction> cntrctBnftPlanAgeReductions;

	// bi-directional many-to-one association to CntrctPlanSpcltyVolMltplr
	@JsonIgnore
	@OneToMany(mappedBy = "cntrctPlanSpclty")
	private List<CntrctPlanSpcltyVolMltplr> cntrctPlanSpcltyVolMltplrs;

	public CntrctPlanSpclty() {
	}

	public Long getCntrctPlanSpcltyId() {
		return this.cntrctPlanSpcltyId;
	}

	public void setCntrctPlanSpcltyId(Long cntrctPlanSpcltyId) {
		this.cntrctPlanSpcltyId = cntrctPlanSpcltyId;
	}

	public BigDecimal getACbMaxVolAmt() {
		return this.aCbMaxVolAmt;
	}

	public void setACbMaxVolAmt(BigDecimal aCbMaxVolAmt) {
		this.aCbMaxVolAmt = aCbMaxVolAmt;
	}

	public BigDecimal getACbMinVolAmt() {
		return this.aCbMinVolAmt;
	}

	public void setACbMinVolAmt(BigDecimal aCbMinVolAmt) {
		this.aCbMinVolAmt = aCbMinVolAmt;
	}

	public BigDecimal getAcceleratedDthBnftMaxAmt() {
		return this.acceleratedDthBnftMaxAmt;
	}

	public void setAcceleratedDthBnftMaxAmt(BigDecimal acceleratedDthBnftMaxAmt) {
		this.acceleratedDthBnftMaxAmt = acceleratedDthBnftMaxAmt;
	}

	public BigDecimal getAcceleratedDthBnftPct() {
		return this.acceleratedDthBnftPct;
	}

	public void setAcceleratedDthBnftPct(BigDecimal acceleratedDthBnftPct) {
		this.acceleratedDthBnftPct = acceleratedDthBnftPct;
	}

	public BigDecimal getAdbMaxAmt() {
		return this.adbMaxAmt;
	}

	public void setAdbMaxAmt(BigDecimal adbMaxAmt) {
		this.adbMaxAmt = adbMaxAmt;
	}

	public BigDecimal getAdbPctNbr() {
		return this.adbPctNbr;
	}

	public void setAdbPctNbr(BigDecimal adbPctNbr) {
		this.adbPctNbr = adbPctNbr;
	}

	public BigDecimal getAddnlCvrgChldAmt() {
		return this.addnlCvrgChldAmt;
	}

	public void setAddnlCvrgChldAmt(BigDecimal addnlCvrgChldAmt) {
		this.addnlCvrgChldAmt = addnlCvrgChldAmt;
	}

	public BigDecimal getAddnlCvrgSbscrbrAmt() {
		return this.addnlCvrgSbscrbrAmt;
	}

	public void setAddnlCvrgSbscrbrAmt(BigDecimal addnlCvrgSbscrbrAmt) {
		this.addnlCvrgSbscrbrAmt = addnlCvrgSbscrbrAmt;
	}

	public BigDecimal getAddnlCvrgSpousAmt() {
		return this.addnlCvrgSpousAmt;
	}

	public void setAddnlCvrgSpousAmt(BigDecimal addnlCvrgSpousAmt) {
		this.addnlCvrgSpousAmt = addnlCvrgSpousAmt;
	}

	public String getBndlgIndCd() {
		return this.bndlgIndCd;
	}

	public void setBndlgIndCd(String bndlgIndCd) {
		this.bndlgIndCd = bndlgIndCd;
	}

	public String getChldCvrgCalcnTypeCd() {
		return this.chldCvrgCalcnTypeCd;
	}

	public void setChldCvrgCalcnTypeCd(String chldCvrgCalcnTypeCd) {
		this.chldCvrgCalcnTypeCd = chldCvrgCalcnTypeCd;
	}

	public BigDecimal getChldDfrntlAmt() {
		return this.chldDfrntlAmt;
	}

	public void setChldDfrntlAmt(BigDecimal chldDfrntlAmt) {
		this.chldDfrntlAmt = chldDfrntlAmt;
	}

	public String getChldFlatRt() {
		return this.chldFlatRt;
	}

	public void setChldFlatRt(String chldFlatRt) {
		this.chldFlatRt = chldFlatRt;
	}

	public String getClsLocId() {
		return this.clsLocId;
	}

	public void setClsLocId(String clsLocId) {
		this.clsLocId = clsLocId;
	}

	public Long getCntrctId() {
		return this.cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	public String getCntrctPlanCd() {
		return this.cntrctPlanCd;
	}

	public void setCntrctPlanCd(String cntrctPlanCd) {
		this.cntrctPlanCd = cntrctPlanCd;
	}

	public Date getCntrctPlanEfctvDt() {
		return this.cntrctPlanEfctvDt;
	}

	public void setCntrctPlanEfctvDt(Date cntrctPlanEfctvDt) {
		this.cntrctPlanEfctvDt = cntrctPlanEfctvDt;
	}

	public Date getCntrctPlanSpcltyEfctvDt() {
		return this.cntrctPlanSpcltyEfctvDt;
	}

	public void setCntrctPlanSpcltyEfctvDt(Date cntrctPlanSpcltyEfctvDt) {
		this.cntrctPlanSpcltyEfctvDt = cntrctPlanSpcltyEfctvDt;
	}

	public Date getCntrctPlanSpcltyTrmntnDt() {
		return this.cntrctPlanSpcltyTrmntnDt;
	}

	public void setCntrctPlanSpcltyTrmntnDt(Date cntrctPlanSpcltyTrmntnDt) {
		this.cntrctPlanSpcltyTrmntnDt = cntrctPlanSpcltyTrmntnDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getCutbkFixedAge() {
		return this.cutbkFixedAge;
	}

	public void setCutbkFixedAge(BigDecimal cutbkFixedAge) {
		this.cutbkFixedAge = cutbkFixedAge;
	}

	public BigDecimal getCutbkFixedPct() {
		return this.cutbkFixedPct;
	}

	public void setCutbkFixedPct(BigDecimal cutbkFixedPct) {
		this.cutbkFixedPct = cutbkFixedPct;
	}

	public BigDecimal getCutbkFixedVol() {
		return this.cutbkFixedVol;
	}

	public void setCutbkFixedVol(BigDecimal cutbkFixedVol) {
		this.cutbkFixedVol = cutbkFixedVol;
	}

	public String getCutbkFrqncyCd() {
		return this.cutbkFrqncyCd;
	}

	public void setCutbkFrqncyCd(String cutbkFrqncyCd) {
		this.cutbkFrqncyCd = cutbkFrqncyCd;
	}

	public BigDecimal getCutbkIMaxVolAmt() {
		return this.cutbkIMaxVolAmt;
	}

	public void setCutbkIMaxVolAmt(BigDecimal cutbkIMaxVolAmt) {
		this.cutbkIMaxVolAmt = cutbkIMaxVolAmt;
	}

	public BigDecimal getCutbkIMinVolAmt() {
		return this.cutbkIMinVolAmt;
	}

	public void setCutbkIMinVolAmt(BigDecimal cutbkIMinVolAmt) {
		this.cutbkIMinVolAmt = cutbkIMinVolAmt;
	}

	public BigDecimal getCutbkIncrmntNbr() {
		return this.cutbkIncrmntNbr;
	}

	public void setCutbkIncrmntNbr(BigDecimal cutbkIncrmntNbr) {
		this.cutbkIncrmntNbr = cutbkIncrmntNbr;
	}

	public BigDecimal getCutbkMaxOcrncNbr() {
		return this.cutbkMaxOcrncNbr;
	}

	public void setCutbkMaxOcrncNbr(BigDecimal cutbkMaxOcrncNbr) {
		this.cutbkMaxOcrncNbr = cutbkMaxOcrncNbr;
	}

	public BigDecimal getCutbkOMaxVolAmt() {
		return this.cutbkOMaxVolAmt;
	}

	public void setCutbkOMaxVolAmt(BigDecimal cutbkOMaxVolAmt) {
		this.cutbkOMaxVolAmt = cutbkOMaxVolAmt;
	}

	public BigDecimal getCutbkOMinVolAmt() {
		return this.cutbkOMinVolAmt;
	}

	public void setCutbkOMinVolAmt(BigDecimal cutbkOMinVolAmt) {
		this.cutbkOMinVolAmt = cutbkOMinVolAmt;
	}

	public BigDecimal getCutbkPct() {
		return this.cutbkPct;
	}

	public void setCutbkPct(BigDecimal cutbkPct) {
		this.cutbkPct = cutbkPct;
	}

	public BigDecimal getCutbkVolAmt() {
		return this.cutbkVolAmt;
	}

	public void setCutbkVolAmt(BigDecimal cutbkVolAmt) {
		this.cutbkVolAmt = cutbkVolAmt;
	}

	public String getCvrgReplcdCd() {
		return this.cvrgReplcdCd;
	}

	public void setCvrgReplcdCd(String cvrgReplcdCd) {
		this.cvrgReplcdCd = cvrgReplcdCd;
	}

	public String getEarngDefn() {
		return this.earngDefn;
	}

	public void setEarngDefn(String earngDefn) {
		this.earngDefn = earngDefn;
	}

	public BigDecimal getFlatPerChldVolNbr() {
		return this.flatPerChldVolNbr;
	}

	public void setFlatPerChldVolNbr(BigDecimal flatPerChldVolNbr) {
		this.flatPerChldVolNbr = flatPerChldVolNbr;
	}

	public BigDecimal getFlatPerSbscrbrVolNbr() {
		return this.flatPerSbscrbrVolNbr;
	}

	public void setFlatPerSbscrbrVolNbr(BigDecimal flatPerSbscrbrVolNbr) {
		this.flatPerSbscrbrVolNbr = flatPerSbscrbrVolNbr;
	}

	public BigDecimal getFlatPerSpousVolNbr() {
		return this.flatPerSpousVolNbr;
	}

	public void setFlatPerSpousVolNbr(BigDecimal flatPerSpousVolNbr) {
		this.flatPerSpousVolNbr = flatPerSpousVolNbr;
	}

	public Date getGiEfctvDt() {
		return this.giEfctvDt;
	}

	public void setGiEfctvDt(Date giEfctvDt) {
		this.giEfctvDt = giEfctvDt;
	}

	public String getGiOverInd() {
		return this.giOverInd;
	}

	public void setGiOverInd(String giOverInd) {
		this.giOverInd = giOverInd;
	}

	public BigDecimal getGrntIsuAmt() {
		return this.grntIsuAmt;
	}

	public void setGrntIsuAmt(BigDecimal grntIsuAmt) {
		this.grntIsuAmt = grntIsuAmt;
	}

	public BigDecimal getGrpEmpVal() {
		return this.grpEmpVal;
	}

	public void setGrpEmpVal(BigDecimal grpEmpVal) {
		this.grpEmpVal = grpEmpVal;
	}

	public BigDecimal getGuarteIssuAmt() {
		return this.guarteIssuAmt;
	}

	public void setGuarteIssuAmt(BigDecimal guarteIssuAmt) {
		this.guarteIssuAmt = guarteIssuAmt;
	}

	public BigDecimal getIncrmntlCvrgChldAmt() {
		return this.incrmntlCvrgChldAmt;
	}

	public void setIncrmntlCvrgChldAmt(BigDecimal incrmntlCvrgChldAmt) {
		this.incrmntlCvrgChldAmt = incrmntlCvrgChldAmt;
	}

	public BigDecimal getIncrmntlCvrgSbscrbrAmt() {
		return this.incrmntlCvrgSbscrbrAmt;
	}

	public void setIncrmntlCvrgSbscrbrAmt(BigDecimal incrmntlCvrgSbscrbrAmt) {
		this.incrmntlCvrgSbscrbrAmt = incrmntlCvrgSbscrbrAmt;
	}

	public BigDecimal getIncrmntlCvrgSpousAmt() {
		return this.incrmntlCvrgSpousAmt;
	}

	public void setIncrmntlCvrgSpousAmt(BigDecimal incrmntlCvrgSpousAmt) {
		this.incrmntlCvrgSpousAmt = incrmntlCvrgSpousAmt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public BigDecimal getMaxAgeNbr() {
		return this.maxAgeNbr;
	}

	public void setMaxAgeNbr(BigDecimal maxAgeNbr) {
		this.maxAgeNbr = maxAgeNbr;
	}

	public BigDecimal getMaxChldPct() {
		return this.maxChldPct;
	}

	public void setMaxChldPct(BigDecimal maxChldPct) {
		this.maxChldPct = maxChldPct;
	}

	public BigDecimal getMaxSpousPct() {
		return this.maxSpousPct;
	}

	public void setMaxSpousPct(BigDecimal maxSpousPct) {
		this.maxSpousPct = maxSpousPct;
	}

	public BigDecimal getMaxVolChldAmt() {
		return this.maxVolChldAmt;
	}

	public void setMaxVolChldAmt(BigDecimal maxVolChldAmt) {
		this.maxVolChldAmt = maxVolChldAmt;
	}

	public BigDecimal getMaxVolSbscrbrAmt() {
		return this.maxVolSbscrbrAmt;
	}

	public void setMaxVolSbscrbrAmt(BigDecimal maxVolSbscrbrAmt) {
		this.maxVolSbscrbrAmt = maxVolSbscrbrAmt;
	}

	public BigDecimal getMaxVolSpousAmt() {
		return this.maxVolSpousAmt;
	}

	public void setMaxVolSpousAmt(BigDecimal maxVolSpousAmt) {
		this.maxVolSpousAmt = maxVolSpousAmt;
	}

	public BigDecimal getMinHours() {
		return this.minHours;
	}

	public void setMinHours(BigDecimal minHours) {
		this.minHours = minHours;
	}

	public BigDecimal getMinVolChldAmt() {
		return this.minVolChldAmt;
	}

	public void setMinVolChldAmt(BigDecimal minVolChldAmt) {
		this.minVolChldAmt = minVolChldAmt;
	}

	public BigDecimal getMinVolSbscrbrAmt() {
		return this.minVolSbscrbrAmt;
	}

	public void setMinVolSbscrbrAmt(BigDecimal minVolSbscrbrAmt) {
		this.minVolSbscrbrAmt = minVolSbscrbrAmt;
	}

	public BigDecimal getMinVolSpousAmt() {
		return this.minVolSpousAmt;
	}

	public void setMinVolSpousAmt(BigDecimal minVolSpousAmt) {
		this.minVolSpousAmt = minVolSpousAmt;
	}

	public String getMjrCvrgCd() {
		return this.mjrCvrgCd;
	}

	public void setMjrCvrgCd(String mjrCvrgCd) {
		this.mjrCvrgCd = mjrCvrgCd;
	}

	public String getMmCd() {
		return this.mmCd;
	}

	public void setMmCd(String mmCd) {
		this.mmCd = mmCd;
	}

	public BigDecimal getNewBrnCvrgAmt() {
		return this.newBrnCvrgAmt;
	}

	public void setNewBrnCvrgAmt(BigDecimal newBrnCvrgAmt) {
		this.newBrnCvrgAmt = newBrnCvrgAmt;
	}

	public BigDecimal getNwbrnCvrgAmt() {
		return this.nwbrnCvrgAmt;
	}

	public void setNwbrnCvrgAmt(BigDecimal nwbrnCvrgAmt) {
		this.nwbrnCvrgAmt = nwbrnCvrgAmt;
	}

	public BigDecimal getOnLvPrdNbr() {
		return this.onLvPrdNbr;
	}

	public void setOnLvPrdNbr(BigDecimal onLvPrdNbr) {
		this.onLvPrdNbr = onLvPrdNbr;
	}

	public String getOptUpselDisc() {
		return this.optUpselDisc;
	}

	public void setOptUpselDisc(String optUpselDisc) {
		this.optUpselDisc = optUpselDisc;
	}

	public String getPoolCd() {
		return this.poolCd;
	}

	public void setPoolCd(String poolCd) {
		this.poolCd = poolCd;
	}

	public String getPrcSize() {
		return this.prcSize;
	}

	public void setPrcSize(String prcSize) {
		this.prcSize = prcSize;
	}

	public String getProdFmlyCd() {
		return this.prodFmlyCd;
	}

	public void setProdFmlyCd(String prodFmlyCd) {
		this.prodFmlyCd = prodFmlyCd;
	}

	public String getProdNm() {
		return this.prodNm;
	}

	public void setProdNm(String prodNm) {
		this.prodNm = prodNm;
	}

	public BigDecimal getRdctnMinAmt() {
		return this.rdctnMinAmt;
	}

	public void setRdctnMinAmt(BigDecimal rdctnMinAmt) {
		this.rdctnMinAmt = rdctnMinAmt;
	}

	public String getRdctnOcrncCd() {
		return this.rdctnOcrncCd;
	}

	public void setRdctnOcrncCd(String rdctnOcrncCd) {
		this.rdctnOcrncCd = rdctnOcrncCd;
	}

	public String getRndgCd() {
		return this.rndgCd;
	}

	public void setRndgCd(String rndgCd) {
		this.rndgCd = rndgCd;
	}

	public String getRndgMltplCd() {
		return this.rndgMltplCd;
	}

	public void setRndgMltplCd(String rndgMltplCd) {
		this.rndgMltplCd = rndgMltplCd;
	}

	public BigDecimal getRndgMltplNbr() {
		return this.rndgMltplNbr;
	}

	public void setRndgMltplNbr(BigDecimal rndgMltplNbr) {
		this.rndgMltplNbr = rndgMltplNbr;
	}

	public String getRoundCd() {
		return this.roundCd;
	}

	public void setRoundCd(String roundCd) {
		this.roundCd = roundCd;
	}

	public BigDecimal getRoundedAftrCutbkNbr() {
		return this.roundedAftrCutbkNbr;
	}

	public void setRoundedAftrCutbkNbr(BigDecimal roundedAftrCutbkNbr) {
		this.roundedAftrCutbkNbr = roundedAftrCutbkNbr;
	}

	public BigDecimal getRtBankDscnt() {
		return this.rtBankDscnt;
	}

	public void setRtBankDscnt(BigDecimal rtBankDscnt) {
		this.rtBankDscnt = rtBankDscnt;
	}

	public String getSbscrbrCvrgCalcnTypeCd() {
		return this.sbscrbrCvrgCalcnTypeCd;
	}

	public void setSbscrbrCvrgCalcnTypeCd(String sbscrbrCvrgCalcnTypeCd) {
		this.sbscrbrCvrgCalcnTypeCd = sbscrbrCvrgCalcnTypeCd;
	}

	public BigDecimal getSbscrbrDfrntlAmt() {
		return this.sbscrbrDfrntlAmt;
	}

	public void setSbscrbrDfrntlAmt(BigDecimal sbscrbrDfrntlAmt) {
		this.sbscrbrDfrntlAmt = sbscrbrDfrntlAmt;
	}

	public BigDecimal getSbscrbrGuarteIssuAmt() {
		return this.sbscrbrGuarteIssuAmt;
	}

	public void setSbscrbrGuarteIssuAmt(BigDecimal sbscrbrGuarteIssuAmt) {
		this.sbscrbrGuarteIssuAmt = sbscrbrGuarteIssuAmt;
	}

	public String getSlryFrqncyCd() {
		return this.slryFrqncyCd;
	}

	public void setSlryFrqncyCd(String slryFrqncyCd) {
		this.slryFrqncyCd = slryFrqncyCd;
	}

	public String getSpcltyClsCd() {
		return this.spcltyClsCd;
	}

	public void setSpcltyClsCd(String spcltyClsCd) {
		this.spcltyClsCd = spcltyClsCd;
	}

	public String getSpousCutBk() {
		return this.spousCutBk;
	}

	public void setSpousCutBk(String spousCutBk) {
		this.spousCutBk = spousCutBk;
	}

	public String getSpousCutbkCd() {
		return this.spousCutbkCd;
	}

	public void setSpousCutbkCd(String spousCutbkCd) {
		this.spousCutbkCd = spousCutbkCd;
	}

	public String getSpousCvrgCalcnTypeCd() {
		return this.spousCvrgCalcnTypeCd;
	}

	public void setSpousCvrgCalcnTypeCd(String spousCvrgCalcnTypeCd) {
		this.spousCvrgCalcnTypeCd = spousCvrgCalcnTypeCd;
	}

	public BigDecimal getSpousDfrntlAmt() {
		return this.spousDfrntlAmt;
	}

	public void setSpousDfrntlAmt(BigDecimal spousDfrntlAmt) {
		this.spousDfrntlAmt = spousDfrntlAmt;
	}

	public String getSpousFlatRt() {
		return this.spousFlatRt;
	}

	public void setSpousFlatRt(String spousFlatRt) {
		this.spousFlatRt = spousFlatRt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getWopTpdCd() {
		return this.wopTpdCd;
	}

	public void setWopTpdCd(String wopTpdCd) {
		this.wopTpdCd = wopTpdCd;
	}

	public BigDecimal getWopWaitgPrdNbr() {
		return this.wopWaitgPrdNbr;
	}

	public void setWopWaitgPrdNbr(BigDecimal wopWaitgPrdNbr) {
		this.wopWaitgPrdNbr = wopWaitgPrdNbr;
	}

	public BigDecimal getWopWvrAge() {
		return this.wopWvrAge;
	}

	public void setWopWvrAge(BigDecimal wopWvrAge) {
		this.wopWvrAge = wopWvrAge;
	}

	public BigDecimal getWopWvrTrmntnAge() {
		return this.wopWvrTrmntnAge;
	}

	public void setWopWvrTrmntnAge(BigDecimal wopWvrTrmntnAge) {
		this.wopWvrTrmntnAge = wopWvrTrmntnAge;
	}

	public BigDecimal getWvrMnth() {
		return this.wvrMnth;
	}

	public void setWvrMnth(BigDecimal wvrMnth) {
		this.wvrMnth = wvrMnth;
	}

	public BigDecimal getWvrTrmntnAge() {
		return this.wvrTrmntnAge;
	}

	public void setWvrTrmntnAge(BigDecimal wvrTrmntnAge) {
		this.wvrTrmntnAge = wvrTrmntnAge;
	}

	public CntrctPlan getCntrctPlan() {
		return this.cntrctPlan;
	}

	public void setCntrctPlan(CntrctPlan cntrctPlan) {
		this.cntrctPlan = cntrctPlan;
	}

	public List<CntrctBnftPlanAgeReduction> getCntrctBnftPlanAgeReductions() {
		return this.cntrctBnftPlanAgeReductions;
	}

	public void setCntrctBnftPlanAgeReductions(List<CntrctBnftPlanAgeReduction> cntrctBnftPlanAgeReductions) {
		this.cntrctBnftPlanAgeReductions = cntrctBnftPlanAgeReductions;
	}

	public CntrctBnftPlanAgeReduction addCntrctBnftPlanAgeReduction(
			CntrctBnftPlanAgeReduction cntrctBnftPlanAgeReduction) {
		getCntrctBnftPlanAgeReductions().add(cntrctBnftPlanAgeReduction);
		cntrctBnftPlanAgeReduction.setCntrctPlanSpclty(this);

		return cntrctBnftPlanAgeReduction;
	}

	public CntrctBnftPlanAgeReduction removeCntrctBnftPlanAgeReduction(
			CntrctBnftPlanAgeReduction cntrctBnftPlanAgeReduction) {
		getCntrctBnftPlanAgeReductions().remove(cntrctBnftPlanAgeReduction);
		cntrctBnftPlanAgeReduction.setCntrctPlanSpclty(null);

		return cntrctBnftPlanAgeReduction;
	}

	public List<CntrctPlanSpcltyVolMltplr> getCntrctPlanSpcltyVolMltplrs() {
		return this.cntrctPlanSpcltyVolMltplrs;
	}

	public void setCntrctPlanSpcltyVolMltplrs(List<CntrctPlanSpcltyVolMltplr> cntrctPlanSpcltyVolMltplrs) {
		this.cntrctPlanSpcltyVolMltplrs = cntrctPlanSpcltyVolMltplrs;
	}

	public CntrctPlanSpcltyVolMltplr addCntrctPlanSpcltyVolMltplr(CntrctPlanSpcltyVolMltplr cntrctPlanSpcltyVolMltplr) {
		getCntrctPlanSpcltyVolMltplrs().add(cntrctPlanSpcltyVolMltplr);
		cntrctPlanSpcltyVolMltplr.setCntrctPlanSpclty(this);

		return cntrctPlanSpcltyVolMltplr;
	}

	public CntrctPlanSpcltyVolMltplr removeCntrctPlanSpcltyVolMltplr(CntrctPlanSpcltyVolMltplr cntrctPlanSpcltyVolMltplr) {
		getCntrctPlanSpcltyVolMltplrs().remove(cntrctPlanSpcltyVolMltplr);
		cntrctPlanSpcltyVolMltplr.setCntrctPlanSpclty(null);

		return cntrctPlanSpcltyVolMltplr;
	}


	/*public BigDecimal getMaxDependentPercentage() {
		return maxDependentPercentage;
	}

	public void setMaxDependentPercentage(BigDecimal maxDependentPercentage) {
		this.maxDependentPercentage = maxDependentPercentage;
	}*/

	/*public BigDecimal getSpouseGuaranteeIssueAmount() {
		return spouseGuaranteeIssueAmount;
	}

	public void setSpouseGuaranteeIssueAmount(BigDecimal spouseGuaranteeIssueAmount) {
		this.spouseGuaranteeIssueAmount = spouseGuaranteeIssueAmount;
	}

	public BigDecimal getChildGuaranteeIssueAmount() {
		return childGuaranteeIssueAmount;
	}

	public void setChildGuaranteeIssueAmount(BigDecimal childGuaranteeIssueAmount) {
		this.childGuaranteeIssueAmount = childGuaranteeIssueAmount;
	}*/


}