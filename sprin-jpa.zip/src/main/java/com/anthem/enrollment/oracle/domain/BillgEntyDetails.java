package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the BILLG_ENTY database table.
 * @author Deloitte
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="BILLG_ENTY")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class BillgEntyDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	@Column(name="BILLG_ENTY_ID")
	private long billgEntyId;

	@Column(name="ADMNSTRTV_DAYS_NBR")
	private BigDecimal admnstrtvDaysNbr;

	@Column(name="AUTO_CNCL_CD")
	private String autoCnclCd;

	@Column(name="BILL_COPIES_NBR")
	private BigDecimal billCopiesNbr;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="BILL_DT")
	private Date billDt;

	@Column(name="BILL_ENTY_CD")
	private String billEntyCd;

	//@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Column(name="BILL_ENTY_EFCTV_DT")
	private Date billEntyEfctvDt;

	@Column(name="BILL_ENTY_NM")
	private String billEntyNm;

	@Column(name="BILL_ENTY_STTS_CD")
	private String billEntySttsCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="BILL_ENTY_TRMNTN_DT")
	private Date billEntyTrmntnDt;

	@Column(name="BILL_ENTY_TYPE_CD")
	private String billEntyTypeCd;

	@Column(name="BILL_ERR_IND_CD")
	private String billErrIndCd;

	@Column(name="BILL_FRQNCY_CD")
	private String billFrqncyCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="BILL_HOLD_END_DT")
	private Date billHoldEndDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Column(name="BILL_HOLD_STRT_DT")
	private Date billHoldStrtDt;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_MDL_EFCTV_DT")
	private Date billMdlEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_MDL_TRMNTN_DT")
	private Date billMdlTrmntnDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	//@Temporal(TemporalType.DATE)
	@Column(name="BILL_TO_DT")
	private Date billToDt;

	@Temporal(TemporalType.DATE)
	@Column(name="BILL_TRNSFR_DT")
	private Date billTrnsfrDt;

	@Column(name="BILL_TYPE_CD")
	private String billTypeCd;

	@Column(name="BILLG_ENTY_TRMNTN_RSN_CD")
	private String billgEntyTrmntnRsnCd;

	@Column(name="BYPS_DLNQNCY_IND_CD")
	private String bypsDlnqncyIndCd;

	@Column(name="CHRG_AFTR_CNCL_IND_CD")
	private String chrgAftrCnclIndCd;

	@Column(name="CLM_GRAC_DAYS")
	private BigDecimal clmGracDays;

	@Column(name="CNCL_LTR_CD")
	private String cnclLtrCd;

	@Column(name="CNSLDTD_BILLG_IND_CD")
	private String cnsldtdBillgIndCd;

	@Column(name="CREAT_ACCTG_IND_CD")
	private String creatAcctgIndCd;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="DLNQNCY_LTR_CD")
	private String dlnqncyLtrCd;

	@Column(name="GRAC_DAYS")
	private BigDecimal gracDays;

	@Column(name="HOLD_BILL_CD")
	private String holdBillCd;

	@Column(name="HOLD_BILL_RRT_IND_CD")
	private String holdBillRrtIndCd;

	@Temporal(TemporalType.DATE)
	@Column(name="INVC_FROM_DT")
	private Date invcFromDt;

	@Temporal(TemporalType.DATE)
	@Column(name="INVC_TO_DT")
	private Date invcToDt;

	@Column(name="INVC_TYPE_CD")
	private String invcTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="NO_BILL_IND_CD")
	private String noBillIndCd;

	@Column(name="RFND_IND_CD")
	private String rfndIndCd;

	@Column(name="RMDR_LTR_CD")
	private String rmdrLtrCd;

	@Column(name="RT_ACS_CD")
	private String rtAcsCd;

	@Temporal(TemporalType.DATE)
	@Column(name="RT_ACS_EFCTV_DT")
	private Date rtAcsEfctvDt;

	@Column(name="RT_ACS_LVL_CD")
	private String rtAcsLvlCd;

	@Column(name="SELF_BILL_LIST_PRNT_IND_CD")
	private String selfBillListPrntIndCd;

	@Column(name="SPRS_LIFE_VOL_AMT")
	private BigDecimal sprsLifeVolAmt;

	@Column(name="SRC_REINSRNC_CD")
	private String srcReinsrncCd;

	@Column(name="UNEARN_AMT")
	private BigDecimal unearnAmt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name="WASHOUT_CD")
	private String washoutCd;
	
	@Column(name="PAID_TO_DT")
	private Date paidToDt;



	/*//bi-directional many-to-one association to BillgEntyAdr
	@JsonIgnore
	@OneToOne(mappedBy="billgEnty", cascade = CascadeType.ALL)
	private BillgEntyAdrs billgEntyAdrs;

	//bi-directional many-to-one association to BillgEntyTlphn
	@JsonIgnore
	@OneToOne(mappedBy="billgEnty", cascade = CascadeType.ALL)
	private BillgEntyTlphn billgEntyTlphn;

	//bi-directional many-to-one association to CntrctBillgEnty
    @JsonBackReference
	@OneToMany(mappedBy="billgEnty", cascade = CascadeType.ALL)
	private List<CntrctBillgEnty> cntrctBillgEnties;*/

    
    
    		
    @Column(name="LGCY_LCTN_LOB_CD")
    private String workLocation;
    @Column(name="DLQ_MEM_LTR_IND")
	private String dlqMemLetter;
    @Column(name="CNC_MEM_LTR_IND")
	private String cncMemLetter;
    @Column(name="DEMAND_LTR_IND")
	private String demandLetterInd;
    
    @Column(name="BILL_SEQ_CD")
	private String billseq;
    @Column(name="BILL_SUMMARY_IND")
	private String billsummaryind;
    @Column(name="BILL_FREQ")
	private String billfreq;
    @Column(name="QTRLY_CYCLE_CD")
	private String qtrlycycle;
    @Column(name="CYCLE_BILL_SUPPMNTL_CD")
	private String cyclebillSuplmntl;
    @Column(name="FUNDS_APPL_CD")
	private String fundsapplcd;
    @Column(name="HCID_BILL_PRNT_CD")
	private String hcidbillprint;
    @Column(name="TOLERANCE_PRCT")
	private String tolrncePrctge;
    @Column(name="TOLERANCE_AMT")
	private String tolrnceAmt;
    
	

	public long getBillgEntyId() {
		return this.billgEntyId;
	}

	public void setBillgEntyId(long billgEntyId) {
		this.billgEntyId = billgEntyId;
	}

	public BigDecimal getAdmnstrtvDaysNbr() {
		return this.admnstrtvDaysNbr;
	}

	public void setAdmnstrtvDaysNbr(BigDecimal admnstrtvDaysNbr) {
		this.admnstrtvDaysNbr = admnstrtvDaysNbr;
	}

	public String getAutoCnclCd() {
		return this.autoCnclCd;
	}

	public void setAutoCnclCd(String autoCnclCd) {
		this.autoCnclCd = autoCnclCd;
	}

	public BigDecimal getBillCopiesNbr() {
		return this.billCopiesNbr;
	}

	public void setBillCopiesNbr(BigDecimal billCopiesNbr) {
		this.billCopiesNbr = billCopiesNbr;
	}

	public Date getBillDt() {
		return this.billDt;
	}

	public void setBillDt(Date billDt) {
		this.billDt = billDt;
	}

	public String getBillEntyCd() {
		return this.billEntyCd;
	}

	public void setBillEntyCd(String billEntyCd) {
		this.billEntyCd = billEntyCd;
	}

	public Date getBillEntyEfctvDt() {
		return this.billEntyEfctvDt;
	}

	public void setBillEntyEfctvDt(Date billEntyEfctvDt) {
		this.billEntyEfctvDt = billEntyEfctvDt;
	}

	public String getBillEntyNm() {
		return this.billEntyNm;
	}

	public void setBillEntyNm(String billEntyNm) {
		this.billEntyNm = billEntyNm;
	}

	public String getBillEntySttsCd() {
		return this.billEntySttsCd;
	}

	public void setBillEntySttsCd(String billEntySttsCd) {
		this.billEntySttsCd = billEntySttsCd;
	}

	public Date getBillEntyTrmntnDt() {
		return this.billEntyTrmntnDt;
	}

	public void setBillEntyTrmntnDt(Date billEntyTrmntnDt) {
		this.billEntyTrmntnDt = billEntyTrmntnDt;
	}

	public String getBillEntyTypeCd() {
		return this.billEntyTypeCd;
	}

	public void setBillEntyTypeCd(String billEntyTypeCd) {
		this.billEntyTypeCd = billEntyTypeCd;
	}

	public String getBillErrIndCd() {
		return this.billErrIndCd;
	}

	public void setBillErrIndCd(String billErrIndCd) {
		this.billErrIndCd = billErrIndCd;
	}

	public String getBillFrqncyCd() {
		return this.billFrqncyCd;
	}

	public void setBillFrqncyCd(String billFrqncyCd) {
		this.billFrqncyCd = billFrqncyCd;
	}

	public Date getBillHoldEndDt() {
		return this.billHoldEndDt;
	}

	public void setBillHoldEndDt(Date billHoldEndDt) {
		this.billHoldEndDt = billHoldEndDt;
	}

	public Date getBillHoldStrtDt() {
		return this.billHoldStrtDt;
	}

	public void setBillHoldStrtDt(Date billHoldStrtDt) {
		this.billHoldStrtDt = billHoldStrtDt;
	}

	public Date getBillMdlEfctvDt() {
		return this.billMdlEfctvDt;
	}

	public void setBillMdlEfctvDt(Date billMdlEfctvDt) {
		this.billMdlEfctvDt = billMdlEfctvDt;
	}

	public Date getBillMdlTrmntnDt() {
		return this.billMdlTrmntnDt;
	}

	public void setBillMdlTrmntnDt(Date billMdlTrmntnDt) {
		this.billMdlTrmntnDt = billMdlTrmntnDt;
	}

	public Date getBillToDt() {
		return this.billToDt;
	}

	public void setBillToDt(Date billToDt) {
		this.billToDt = billToDt;
	}

	public Date getBillTrnsfrDt() {
		return this.billTrnsfrDt;
	}

	public void setBillTrnsfrDt(Date billTrnsfrDt) {
		this.billTrnsfrDt = billTrnsfrDt;
	}

	public String getBillTypeCd() {
		return this.billTypeCd;
	}

	public void setBillTypeCd(String billTypeCd) {
		this.billTypeCd = billTypeCd;
	}

	public String getBillgEntyTrmntnRsnCd() {
		return this.billgEntyTrmntnRsnCd;
	}

	public void setBillgEntyTrmntnRsnCd(String billgEntyTrmntnRsnCd) {
		this.billgEntyTrmntnRsnCd = billgEntyTrmntnRsnCd;
	}

	public String getBypsDlnqncyIndCd() {
		return this.bypsDlnqncyIndCd;
	}

	public void setBypsDlnqncyIndCd(String bypsDlnqncyIndCd) {
		this.bypsDlnqncyIndCd = bypsDlnqncyIndCd;
	}

	public String getChrgAftrCnclIndCd() {
		return this.chrgAftrCnclIndCd;
	}

	public void setChrgAftrCnclIndCd(String chrgAftrCnclIndCd) {
		this.chrgAftrCnclIndCd = chrgAftrCnclIndCd;
	}

	public BigDecimal getClmGracDays() {
		return this.clmGracDays;
	}

	public void setClmGracDays(BigDecimal clmGracDays) {
		this.clmGracDays = clmGracDays;
	}

	public String getCnclLtrCd() {
		return this.cnclLtrCd;
	}

	public void setCnclLtrCd(String cnclLtrCd) {
		this.cnclLtrCd = cnclLtrCd;
	}

	public String getCnsldtdBillgIndCd() {
		return this.cnsldtdBillgIndCd;
	}

	public void setCnsldtdBillgIndCd(String cnsldtdBillgIndCd) {
		this.cnsldtdBillgIndCd = cnsldtdBillgIndCd;
	}

	public String getCreatAcctgIndCd() {
		return this.creatAcctgIndCd;
	}

	public void setCreatAcctgIndCd(String creatAcctgIndCd) {
		this.creatAcctgIndCd = creatAcctgIndCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getDlnqncyLtrCd() {
		return this.dlnqncyLtrCd;
	}

	public void setDlnqncyLtrCd(String dlnqncyLtrCd) {
		this.dlnqncyLtrCd = dlnqncyLtrCd;
	}

	public BigDecimal getGracDays() {
		return this.gracDays;
	}

	public void setGracDays(BigDecimal gracDays) {
		this.gracDays = gracDays;
	}

	public String getHoldBillCd() {
		
		return this.holdBillCd;
	}

	public void setHoldBillCd(String holdBillCd) {
		this.holdBillCd = holdBillCd;
	}

	public String getHoldBillRrtIndCd() {
		return this.holdBillRrtIndCd;
	}

	public void setHoldBillRrtIndCd(String holdBillRrtIndCd) {
		this.holdBillRrtIndCd = holdBillRrtIndCd;
	}

	public Date getInvcFromDt() {
		return this.invcFromDt;
	}

	public void setInvcFromDt(Date invcFromDt) {
		this.invcFromDt = invcFromDt;
	}

	public Date getInvcToDt() {
		return this.invcToDt;
	}

	public void setInvcToDt(Date invcToDt) {
		this.invcToDt = invcToDt;
	}

	public String getInvcTypeCd() {
		return this.invcTypeCd;
	}

	public void setInvcTypeCd(String invcTypeCd) {
		this.invcTypeCd = invcTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getNoBillIndCd() {
		return this.noBillIndCd;
	}

	public void setNoBillIndCd(String noBillIndCd) {
		this.noBillIndCd = noBillIndCd;
	}

	public String getRfndIndCd() {
		return this.rfndIndCd;
	}

	public void setRfndIndCd(String rfndIndCd) {
		this.rfndIndCd = rfndIndCd;
	}

	public String getRmdrLtrCd() {
		return this.rmdrLtrCd;
	}

	public void setRmdrLtrCd(String rmdrLtrCd) {
		this.rmdrLtrCd = rmdrLtrCd;
	}

	public String getRtAcsCd() {
		return this.rtAcsCd;
	}

	public void setRtAcsCd(String rtAcsCd) {
		this.rtAcsCd = rtAcsCd;
	}

	public Date getRtAcsEfctvDt() {
		return this.rtAcsEfctvDt;
	}

	public void setRtAcsEfctvDt(Date rtAcsEfctvDt) {
		this.rtAcsEfctvDt = rtAcsEfctvDt;
	}

	public String getRtAcsLvlCd() {
		return this.rtAcsLvlCd;
	}

	public void setRtAcsLvlCd(String rtAcsLvlCd) {
		this.rtAcsLvlCd = rtAcsLvlCd;
	}

	public String getSelfBillListPrntIndCd() {
		return this.selfBillListPrntIndCd;
	}

	public void setSelfBillListPrntIndCd(String selfBillListPrntIndCd) {
		this.selfBillListPrntIndCd = selfBillListPrntIndCd;
	}

	public BigDecimal getSprsLifeVolAmt() {
		return this.sprsLifeVolAmt;
	}

	public void setSprsLifeVolAmt(BigDecimal sprsLifeVolAmt) {
		this.sprsLifeVolAmt = sprsLifeVolAmt;
	}

	public String getSrcReinsrncCd() {
		return this.srcReinsrncCd;
	}

	public void setSrcReinsrncCd(String srcReinsrncCd) {
		this.srcReinsrncCd = srcReinsrncCd;
	}

	public BigDecimal getUnearnAmt() {
		return this.unearnAmt;
	}

	public void setUnearnAmt(BigDecimal unearnAmt) {
		this.unearnAmt = unearnAmt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getWashoutCd() {
		return this.washoutCd;
	}

	public void setWashoutCd(String washoutCd) {
		this.washoutCd = washoutCd;
	}

	/*public BillgEntyAdrs getBillgEntyAdrs() {
		return this.billgEntyAdrs;
	}

	public void setBillgEntyAdrs(BillgEntyAdrs billgEntyAdrs) {
		this.billgEntyAdrs = billgEntyAdrs;
	}

	public BillgEntyTlphn getBillgEntyTlphn() {
		return this.billgEntyTlphn;
	}

	public void setBillgEntyTlphns(BillgEntyTlphn billgEntyTlphn) {
		this.billgEntyTlphn = billgEntyTlphn;
	}

	public List<CntrctBillgEnty> getCntrctBillgEnties() {
		return this.cntrctBillgEnties;
	}

	public void setCntrctBillgEnties(List<CntrctBillgEnty> cntrctBillgEnties) {
		this.cntrctBillgEnties = cntrctBillgEnties;
	}*/

	

	public String getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}

	public String getDlqMemLetter() {
		return dlqMemLetter;
	}

	public void setDlqMemLetter(String dlqMemLetter) {
		this.dlqMemLetter = dlqMemLetter;
	}

	public String getCncMemLetter() {
		return cncMemLetter;
	}

	public void setCncMemLetter(String cncMemLetter) {
		this.cncMemLetter = cncMemLetter;
	}

	public String getDemandLetterInd() {
		return demandLetterInd;
	}

	public void setDemandLetterInd(String demandLetterInd) {
		this.demandLetterInd = demandLetterInd;
	}

	public String getBillseq() {
		return billseq;
	}

	public void setBillseq(String billseq) {
		this.billseq = billseq;
	}

	public String getBillsummaryind() {
		return billsummaryind;
	}

	public void setBillsummaryind(String billsummaryind) {
		this.billsummaryind = billsummaryind;
	}

	public String getBillfreq() {
		return billfreq;
	}

	public void setBillfreq(String billfreq) {
		this.billfreq = billfreq;
	}

	public String getQtrlycycle() {
		return qtrlycycle;
	}

	public void setQtrlycycle(String qtrlycycle) {
		this.qtrlycycle = qtrlycycle;
	}

	public String getCyclebillSuplmntl() {
		return cyclebillSuplmntl;
	}

	public void setCyclebillSuplmntl(String cyclebillSuplmntl) {
		this.cyclebillSuplmntl = cyclebillSuplmntl;
	}

	public String getFundsapplcd() {
		return fundsapplcd;
	}

	public void setFundsapplcd(String fundsapplcd) {
		this.fundsapplcd = fundsapplcd;
	}

	public String getHcidbillprint() {
		return hcidbillprint;
	}

	public void setHcidbillprint(String hcidbillprint) {
		this.hcidbillprint = hcidbillprint;
	}

	public String getTolrncePrctge() {
		return tolrncePrctge;
	}

	public void setTolrncePrctge(String tolrncePrctge) {
		this.tolrncePrctge = tolrncePrctge;
	}

	public String getTolrnceAmt() {
		return tolrnceAmt;
	}

	public void setTolrnceAmt(String tolrnceAmt) {
		this.tolrnceAmt = tolrnceAmt;
	}
	
	public Date getPaidToDt() {
		return paidToDt;
	}

	public void setPaidToDt(Date paidToDt) {
		this.paidToDt = paidToDt;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "BillgEnty [billgEntyId=" + billgEntyId + ", admnstrtvDaysNbr=" + admnstrtvDaysNbr + ", autoCnclCd="
				+ autoCnclCd + ", billCopiesNbr=" + billCopiesNbr + ", billDt=" + billDt + ", billEntyCd=" + billEntyCd
				+ ", billEntyEfctvDt=" +(billEntyEfctvDt!=null? formatter.format(billEntyEfctvDt):null) + ", billEntyNm=" + billEntyNm + ", billEntySttsCd="
				+ billEntySttsCd + ", billEntyTrmntnDt=" + (billEntyTrmntnDt!=null?formatter.format(billEntyTrmntnDt):null) + ", billEntyTypeCd=" + billEntyTypeCd
				+ ", billErrIndCd=" + billErrIndCd + ", billFrqncyCd=" + billFrqncyCd + ", billHoldEndDt="
				+ (billHoldEndDt!=null?formatter.format(billHoldEndDt):null) + ", billHoldStrtDt=" + (billHoldStrtDt!=null?formatter.format(billHoldStrtDt):null) + ", billMdlEfctvDt=" + (billMdlEfctvDt!=null?formatter.format(billMdlEfctvDt):null)
				+ ", billMdlTrmntnDt=" + (billMdlTrmntnDt!=null?formatter.format(billMdlTrmntnDt):null) + ", billToDt=" + (billToDt!=null?formatter.format(billToDt):null) + ", billTrnsfrDt=" + (billTrnsfrDt!=null?formatter.format(billTrnsfrDt):null)
				+ ", billTypeCd=" + billTypeCd + ", billgEntyTrmntnRsnCd=" + billgEntyTrmntnRsnCd
				+ ", bypsDlnqncyIndCd=" + bypsDlnqncyIndCd + ", chrgAftrCnclIndCd=" + chrgAftrCnclIndCd
				+ ", clmGracDays=" + clmGracDays + ", cnclLtrCd=" + cnclLtrCd + ", cnsldtdBillgIndCd="
				+ cnsldtdBillgIndCd + ", creatAcctgIndCd=" + creatAcctgIndCd + ", creatdByUserId=" + creatdByUserId
				+ ", creatdDtm=" + creatdDtm + ", dlnqncyLtrCd=" + dlnqncyLtrCd + ", gracDays=" + gracDays
				+ ", holdBillCd=" + holdBillCd + ", holdBillRrtIndCd=" + holdBillRrtIndCd + ", invcFromDt=" + invcFromDt
				+ ", invcToDt=" + invcToDt + ", invcTypeCd=" + invcTypeCd + ", lastUpdtdByUserId=" + lastUpdtdByUserId
				+ ", lastUpdtdDtm=" + lastUpdtdDtm + ", noBillIndCd=" + noBillIndCd + ", rfndIndCd=" + rfndIndCd
				+ ", rmdrLtrCd=" + rmdrLtrCd + ", rtAcsCd=" + rtAcsCd + ", rtAcsEfctvDt=" + rtAcsEfctvDt
				+ ", rtAcsLvlCd=" + rtAcsLvlCd + ", selfBillListPrntIndCd=" + selfBillListPrntIndCd
				+ ", sprsLifeVolAmt=" + sprsLifeVolAmt + ", srcReinsrncCd=" + srcReinsrncCd + ", unearnAmt=" + unearnAmt
				+ ", vrsnNbr=" + vrsnNbr + ", washoutCd=" + washoutCd + ", paidToDt=" + (paidToDt!=null?formatter.format(paidToDt) :null)
				+ ", workLocation=" + workLocation + ", dlqMemLetter=" + dlqMemLetter + ", cncMemLetter=" + cncMemLetter
				+ ", demandLetterInd=" + demandLetterInd + ", billseq=" + billseq + ", billsummaryind=" + billsummaryind
				+ ", billfreq=" + billfreq + ", qtrlycycle=" + qtrlycycle + ", cyclebillSuplmntl=" + cyclebillSuplmntl
				+ ", fundsapplcd=" + fundsapplcd + ", hcidbillprint=" + hcidbillprint + ", tolrncePrctge="
				+ tolrncePrctge + ", tolrnceAmt=" + tolrnceAmt + "]";
	}

	
}