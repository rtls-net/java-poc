package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the GRP_SPRT_ASGNMNT database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "GRP_SPRT_ASGNMNT")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpSprtAsgnmnt implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "GRP_SPRT_ASGNMNT_ID")
	private long grpSprtAsgnmntId;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
//	@Temporal(TemporalType.DATE)
	@Column(name = "INTRNL_ASGNMNT_EFCTV_DT")
	private Date intrnlAsgnmntEfctvDt;

	@Column(name = "INTRNL_ASGNMNT_ID")
	private String intrnlAsgnmntId;

	@Column(name = "INTRNL_ASGNMNT_TLPHN_NBR")
	private String intrnlAsgnmntTlphnNbr;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "INTRNL_ASGNMNT_TRMNTN_DT")
	private Date intrnlAsgnmntTrmntnDt;

	@Column(name = "INTRNL_ASGNMNT_TYPE_CD")
	private String intrnlAsgnmntTypeCd;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 0L;

	// bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GRP_ID")
	private Grp grp;

	public GrpSprtAsgnmnt() {
	}

	public long getGrpSprtAsgnmntId() {
		return this.grpSprtAsgnmntId;
	}

	public void setGrpSprtAsgnmntId(long grpSprtAsgnmntId) {
		this.grpSprtAsgnmntId = grpSprtAsgnmntId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getIntrnlAsgnmntEfctvDt() {
		return this.intrnlAsgnmntEfctvDt;
	}

	public void setIntrnlAsgnmntEfctvDt(Date intrnlAsgnmntEfctvDt) {
		this.intrnlAsgnmntEfctvDt = intrnlAsgnmntEfctvDt;
	}

	public String getIntrnlAsgnmntId() {
		return this.intrnlAsgnmntId;
	}

	public void setIntrnlAsgnmntId(String intrnlAsgnmntId) {
		this.intrnlAsgnmntId = intrnlAsgnmntId;
	}

	public String getIntrnlAsgnmntTlphnNbr() {
		return this.intrnlAsgnmntTlphnNbr;
	}

	public void setIntrnlAsgnmntTlphnNbr(String intrnlAsgnmntTlphnNbr) {
		this.intrnlAsgnmntTlphnNbr = intrnlAsgnmntTlphnNbr;
	}

	public Date getIntrnlAsgnmntTrmntnDt() {
		return this.intrnlAsgnmntTrmntnDt;
	}

	public void setIntrnlAsgnmntTrmntnDt(Date intrnlAsgnmntTrmntnDt) {
		this.intrnlAsgnmntTrmntnDt = intrnlAsgnmntTrmntnDt;
	}

	public String getIntrnlAsgnmntTypeCd() {
		return this.intrnlAsgnmntTypeCd;
	}

	public void setIntrnlAsgnmntTypeCd(String intrnlAsgnmntTypeCd) {
		this.intrnlAsgnmntTypeCd = intrnlAsgnmntTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}