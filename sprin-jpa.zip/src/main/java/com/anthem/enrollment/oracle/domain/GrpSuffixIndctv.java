package com.anthem.enrollment.oracle.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_SUFFIX_INDCTV")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class GrpSuffixIndctv {

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_SUFFIX_INDCTV_ID")
	private Long grpSuffixIndId;
	/*
	@Column(name="CNTRCT_ID")
	private Long contractId; */
	@Column(name="GRP_IND_TYPE")
	private String grpIndTyp;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="GRP_SUFFIX_IND_EFCTV_DT")
	private Date grpSuffixIndEffecDate;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="GRP_SUFFIX_IND_TRMNTN_DT")
	private Date grpSuffixIndEndDate;
	@Column(name="NOT_SUB_TO_COB_IND")
	private String notSubToCobInd;
	@Column(name="NOT_SUB_TO_COB_REASON_CODE")
	private String notSubToCobRsnCd;
	@Column(name="CONT_TYPE_CHG_CD")
	private String contTypeChgCd;
	@Column(name="TERM_RULE_CODE")
	private String termRuleCode;
	@Column(name="EXCHANGE_TYPE")
	private String exchangeType;
	@Column(name="COB_SURVEY")
	private String cobSurvey;
	@Column(name="BLUE_RETENTION")
	private String blueRetention;
	@Column(name="COBRA_LETTER")
	private String cobraLtr;
	@Column(name="ACIP_LETTER")
	private String acipLtr;
	@Column(name="AGE_STUDY_LETTER")
	private String ageStudyLtr;
	@Column(name="ADDR_CHANGE_LETTER")
	private String addrChngLtr;
	@Column(name="PCP_LETTER")
	private String pcpLtr;
	@Column(name="WCRE_LETTERS")
	private String wcreLtr;
	@Column(name="CMS_LETTER")
	private String cmsLtr;
	@Column(name="DLIQ_CAN_LETTER_SUPPRSN")
	private String dliqLtrSupprsn;
	@Column(name="COCC_LETTER_SUPPRSN")
	private String coccLtrSupprsn;
	@Column(name="CONVERSION_LETTER_SUPPRSN")
	private String conversionLtrSupprsn;
	@Column(name="TRMNTN_LETTER_SUPPRSN")
	private String trmntnLtrSupprsn;
	@Column(name="PCP_CHANGES")
	private String pcpChngs;
	@Column(name="PCP_ADDRESS_CHANGES")
	private String pcpcAdrChngs;
	@Column(name="AID_CATEGORY_CHANGES")
	private String aidCatgryChngs;
	@Column(name="CONTRACT_CD_CHANGES")
	private String contractCdChngs;
	@Column(name="GRP_TO_GRP_TRANSFER")
	private String grpToGrpChngs;
	@Column(name="COUNTY_CD_CHANGES")
	private String countyCdChngs;
	@Column(name="REENROLLED")
	private String reenrolled;
	@Column(name="REINSTATED")
	private String reinstated;
	@Column(name="GAP_IN_COV_FOR_NMK")
	private String gapInCovForNmk;
	@Column(name="JK_CONTRACT_SUBSCRIBER")
	private String jkContrctSubs;
	@Column(name="OTHER_IND")
	private String otherInd;
	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;
	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;
	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;
	@Column(name="GRP_IND_TYPE_VAL")
	private String grpIndTypVal;
	@Column(name="EXCHANGE_IND")
	private String exchangeInd;
	@Column(name="EXEMPT_TYPE")
	private String exemptTyp;
	/*
	@Column(name="GRP_SUFFIX_IND_TRMNTN_DT")
	private String lastUid;*/
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CNTRCT_ID")
    private Cntrct cntrctId;
	
	public GrpSuffixIndctv() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Cntrct getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Cntrct cntrctId) {
		this.cntrctId = cntrctId;
	}



	public Long getGrpSuffixIndId() {
		return grpSuffixIndId;
	}
	public void setGrpSuffixIndId(Long grpSuffixIndId) {
		this.grpSuffixIndId = grpSuffixIndId;
	}/*
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}*/
	public String getGrpIndTyp() {
		return grpIndTyp;
	}
	public void setGrpIndTyp(String grpIndTyp) {
		this.grpIndTyp = grpIndTyp;
	}
	public Date getGrpSuffixIndEffecDate() {
		return grpSuffixIndEffecDate;
	}
	public void setGrpSuffixIndEffecDate(Date grpSuffixIndEffecDate) {
		this.grpSuffixIndEffecDate = grpSuffixIndEffecDate;
	}
	public Date getGrpSuffixIndEndDate() {
		return grpSuffixIndEndDate;
	}
	public void setGrpSuffixIndEndDate(Date grpSuffixIndEndDate) {
		this.grpSuffixIndEndDate = grpSuffixIndEndDate;
	}
	public String getNotSubToCobInd() {
		return notSubToCobInd;
	}
	public void setNotSubToCobInd(String notSubToCobInd) {
		this.notSubToCobInd = notSubToCobInd;
	}
	public String getNotSubToCobRsnCd() {
		return notSubToCobRsnCd;
	}
	public void setNotSubToCobRsnCd(String notSubToCobRsnCd) {
		this.notSubToCobRsnCd = notSubToCobRsnCd;
	}
	public String getContTypeChgCd() {
		return contTypeChgCd;
	}
	public void setContTypeChgCd(String contTypeChgCd) {
		this.contTypeChgCd = contTypeChgCd;
	}
	public String getTermRuleCode() {
		return termRuleCode;
	}
	public void setTermRuleCode(String termRuleCode) {
		this.termRuleCode = termRuleCode;
	}
	public String getExchangeType() {
		return exchangeType;
	}
	public void setExchangeType(String exchangeType) {
		this.exchangeType = exchangeType;
	}
	public String getCobSurvey() {
		return cobSurvey;
	}
	public void setCobSurvey(String cobSurvey) {
		this.cobSurvey = cobSurvey;
	}
	public String getBlueRetention() {
		return blueRetention;
	}
	public void setBlueRetention(String blueRetention) {
		this.blueRetention = blueRetention;
	}
	public String getCobraLtr() {
		return cobraLtr;
	}
	public void setCobraLtr(String cobraLtr) {
		this.cobraLtr = cobraLtr;
	}
	public String getAcipLtr() {
		return acipLtr;
	}
	public void setAcipLtr(String acipLtr) {
		this.acipLtr = acipLtr;
	}
	public String getAgeStudyLtr() {
		return ageStudyLtr;
	}
	public void setAgeStudyLtr(String ageStudyLtr) {
		this.ageStudyLtr = ageStudyLtr;
	}
	public String getAddrChngLtr() {
		return addrChngLtr;
	}
	public void setAddrChngLtr(String addrChngLtr) {
		this.addrChngLtr = addrChngLtr;
	}
	public String getPcpLtr() {
		return pcpLtr;
	}
	public void setPcpLtr(String pcpLtr) {
		this.pcpLtr = pcpLtr;
	}
	public String getWcreLtr() {
		return wcreLtr;
	}
	public void setWcreLtr(String wcreLtr) {
		this.wcreLtr = wcreLtr;
	}
	public String getCmsLtr() {
		return cmsLtr;
	}
	public void setCmsLtr(String cmsLtr) {
		this.cmsLtr = cmsLtr;
	}
	public String getDliqLtrSupprsn() {
		return dliqLtrSupprsn;
	}
	public void setDliqLtrSupprsn(String dliqLtrSupprsn) {
		this.dliqLtrSupprsn = dliqLtrSupprsn;
	}
	public String getCoccLtrSupprsn() {
		return coccLtrSupprsn;
	}
	public void setCoccLtrSupprsn(String coccLtrSupprsn) {
		this.coccLtrSupprsn = coccLtrSupprsn;
	}
	public String getConversionLtrSupprsn() {
		return conversionLtrSupprsn;
	}
	public void setConversionLtrSupprsn(String conversionLtrSupprsn) {
		this.conversionLtrSupprsn = conversionLtrSupprsn;
	}
	public String getTrmntnLtrSupprsn() {
		return trmntnLtrSupprsn;
	}
	public void setTrmntnLtrSupprsn(String trmntnLtrSupprsn) {
		this.trmntnLtrSupprsn = trmntnLtrSupprsn;
	}
	public String getPcpChngs() {
		return pcpChngs;
	}
	public void setPcpChngs(String pcpChngs) {
		this.pcpChngs = pcpChngs;
	}
	public String getPcpcAdrChngs() {
		return pcpcAdrChngs;
	}
	public void setPcpcAdrChngs(String pcpcAdrChngs) {
		this.pcpcAdrChngs = pcpcAdrChngs;
	}
	public String getAidCatgryChngs() {
		return aidCatgryChngs;
	}
	public void setAidCatgryChngs(String aidCatgryChngs) {
		this.aidCatgryChngs = aidCatgryChngs;
	}
	public String getContractCdChngs() {
		return contractCdChngs;
	}
	public void setContractCdChngs(String contractCdChngs) {
		this.contractCdChngs = contractCdChngs;
	}
	public String getGrpToGrpChngs() {
		return grpToGrpChngs;
	}
	public void setGrpToGrpChngs(String grpToGrpChngs) {
		this.grpToGrpChngs = grpToGrpChngs;
	}
	public String getCountyCdChngs() {
		return countyCdChngs;
	}
	public void setCountyCdChngs(String countyCdChngs) {
		this.countyCdChngs = countyCdChngs;
	}
	public String getReenrolled() {
		return reenrolled;
	}
	public void setReenrolled(String reenrolled) {
		this.reenrolled = reenrolled;
	}
	public String getReinstated() {
		return reinstated;
	}
	public void setReinstated(String reinstated) {
		this.reinstated = reinstated;
	}
	public String getGapInCovForNmk() {
		return gapInCovForNmk;
	}
	public void setGapInCovForNmk(String gapInCovForNmk) {
		this.gapInCovForNmk = gapInCovForNmk;
	}
	public String getJkContrctSubs() {
		return jkContrctSubs;
	}
	public void setJkContrctSubs(String jkContrctSubs) {
		this.jkContrctSubs = jkContrctSubs;
	}
	public String getOtherInd() {
		return otherInd;
	}
	public void setOtherInd(String otherInd) {
		this.otherInd = otherInd;
	}
	public String getCreatdByUserId() {
		return creatdByUserId;
	}
	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}
	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}
	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}
	public Date getCreatdDtm() {
		return creatdDtm;
	}
	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}
	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}
	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}
	public String getGrpIndTypVal() {
		return grpIndTypVal;
	}
	public void setGrpIndTypVal(String grpIndTypVal) {
		this.grpIndTypVal = grpIndTypVal;
	}
	public String getExchangeInd() {
		return exchangeInd;
	}
	public void setExchangeInd(String exchangeInd) {
		this.exchangeInd = exchangeInd;
	}
	public String getExemptTyp() {
		return exemptTyp;
	}
	public void setExemptTyp(String exemptTyp) {
		this.exemptTyp = exemptTyp;
	}
	
	

}
