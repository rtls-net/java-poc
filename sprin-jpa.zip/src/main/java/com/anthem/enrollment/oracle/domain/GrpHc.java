package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the GRP_HC database table.
 *
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_HC")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class GrpHc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_HC_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private long grpHcId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	//@Temporal(TemporalType.DATE)
	@Column(name="GRP_HC_EFCTV_DT")
	private Date grpHcEfctvDt;

	@Column(name="GRP_HC_INIT_DSTRBTN_CD")
	private String grpHcInitDstrbtnCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_HC_ISSU_DT")
	private Date grpHcIssuDt;

	@Column(name="GRP_HC_KEY")
	private BigDecimal grpHcKey;

	@Column(name="GRP_HC_ONGOG_DSTRBTN_CD")
	private String grpHcOngogDstrbtnCd;

	@Column(name="GRP_HC_PRINTING_SQNC_CD")
	private String grpHcPrintingSqncCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_HC_TRMNTN_DT")
	private Date grpHcTrmntnDt;

	@Column(name="HC_CTGRY_CD")
	private String hcCtgryCd;

	@Column(name="GEN_ID_CARD_SW")
	private String genIdCard;

	@Column(name="HC_DSGN_NM")
	private String hcDsgnNm;

	@Column(name="HC_LOGO_NM")
	private String hcLogoNm;

	@Column(name="HC_STOK_CD")
	private String hcStokCd;

	@Column(name="ID_CARD_CMPNY_LOGO")
	private String idCardCmpnyLogo;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="NON_HMO_HC_PRCS_TYPE_CD")
	private String nonHmoHcPrcsTypeCd;

	@Column(name="STDALN_ID_CD")
	private String stdalnIdCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name="GRP_ID", insertable = false, updatable = false)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long grpId;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;
	@JsonIgnore
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CNTRCT_PLAN_ID")
	private CntrctPlan cntrctPlan;
	
	@Transient
	private Long cntrctPlanId;
	
	

	public Long getCntrctPlanId() {
		return cntrctPlanId;
	}

	public void setCntrctPlanId(Long cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}

	public CntrctPlan getCntrctPlan() {
		return cntrctPlan;
	}

	public void setCntrctPlan(CntrctPlan cntrctPlan) {
		this.cntrctPlan = cntrctPlan;
	}

	public GrpHc() {
	}

	public long getGrpHcId() {
		return this.grpHcId;
	}

	public void setGrpHcId(long grpHcId) {
		this.grpHcId = grpHcId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpHcEfctvDt() {
		return this.grpHcEfctvDt;
	}

	public void setGrpHcEfctvDt(Date grpHcEfctvDt) {
		this.grpHcEfctvDt = grpHcEfctvDt;
	}

	public String getGrpHcInitDstrbtnCd() {
		return this.grpHcInitDstrbtnCd;
	}

	public void setGrpHcInitDstrbtnCd(String grpHcInitDstrbtnCd) {
		this.grpHcInitDstrbtnCd = grpHcInitDstrbtnCd;
	}

	public Date getGrpHcIssuDt() {
		return this.grpHcIssuDt;
	}

	public void setGrpHcIssuDt(Date grpHcIssuDt) {
		this.grpHcIssuDt = grpHcIssuDt;
	}

	public BigDecimal getGrpHcKey() {
		return this.grpHcKey;
	}

	public void setGrpHcKey(BigDecimal grpHcKey) {
		this.grpHcKey = grpHcKey;
	}

	public String getGrpHcOngogDstrbtnCd() {
		
		return this.grpHcOngogDstrbtnCd;
	}

	public void setGrpHcOngogDstrbtnCd(String grpHcOngogDstrbtnCd) {
		this.grpHcOngogDstrbtnCd = grpHcOngogDstrbtnCd;
	}

	public String getGrpHcPrintingSqncCd() {
		return this.grpHcPrintingSqncCd;
	}

	public void setGrpHcPrintingSqncCd(String grpHcPrintingSqncCd) {
		this.grpHcPrintingSqncCd = grpHcPrintingSqncCd;
	}

	public Date getGrpHcTrmntnDt() {
		return this.grpHcTrmntnDt;
	}

	public void setGrpHcTrmntnDt(Date grpHcTrmntnDt) {
		this.grpHcTrmntnDt = grpHcTrmntnDt;
	}

	public String getHcCtgryCd() {
		return this.hcCtgryCd;
	}

	public void setHcCtgryCd(String hcCtgryCd) {
		this.hcCtgryCd = hcCtgryCd;
	}

	public String getHcDsgnNm() {
		
		return this.hcDsgnNm;
	}

	public void setHcDsgnNm(String hcDsgnNm) {
		this.hcDsgnNm = hcDsgnNm;
	}

	public String getHcLogoNm() {
		
		return this.hcLogoNm;
	}

	public void setHcLogoNm(String hcLogoNm) {
		this.hcLogoNm = hcLogoNm;
	}

	public String getHcStokCd() {
		return this.hcStokCd;
	}

	public void setHcStokCd(String hcStokCd) {
		this.hcStokCd = hcStokCd;
	}

	public String getIdCardCmpnyLogo() {
		return this.idCardCmpnyLogo;
	}

	public void setIdCardCmpnyLogo(String idCardCmpnyLogo) {
		this.idCardCmpnyLogo = idCardCmpnyLogo;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getNonHmoHcPrcsTypeCd() {
		return this.nonHmoHcPrcsTypeCd;
	}

	public void setNonHmoHcPrcsTypeCd(String nonHmoHcPrcsTypeCd) {
		this.nonHmoHcPrcsTypeCd = nonHmoHcPrcsTypeCd;
	}

	public String getStdalnIdCd() {
		return this.stdalnIdCd;
	}

	public void setStdalnIdCd(String stdalnIdCd) {
		this.stdalnIdCd = stdalnIdCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public Long getGrpId() {
		return grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}

	public String getGenIdCard() {
		return genIdCard;
	}

	public void setGenIdCard(String genIdCard) {
		this.genIdCard = genIdCard;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpHc [grpHcEfctvDt=" +(grpHcEfctvDt!=null?formatter.format(grpHcEfctvDt):null) + ", grpHcInitDstrbtnCd=" + grpHcInitDstrbtnCd + ", grpHcIssuDt="
				+ (grpHcIssuDt!=null?formatter.format(grpHcIssuDt):null) + ", grpHcKey=" + grpHcKey + ", grpHcOngogDstrbtnCd=" + grpHcOngogDstrbtnCd
				+ ", grpHcPrintingSqncCd=" + grpHcPrintingSqncCd + ", grpHcTrmntnDt=" + (grpHcTrmntnDt!=null?formatter.format(grpHcTrmntnDt):null) + ", hcCtgryCd="
				+ hcCtgryCd + ", genIdCard=" + genIdCard + ", hcDsgnNm=" + hcDsgnNm + ", hcLogoNm=" + hcLogoNm
				+ ", hcStokCd=" + hcStokCd + ", idCardCmpnyLogo=" + idCardCmpnyLogo 
				+ ", nonHmoHcPrcsTypeCd=" + nonHmoHcPrcsTypeCd+", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null)
				+ ", stdalnIdCd=" + stdalnIdCd  + "]";
	}
	
	
}