package com.anthem.enrollment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.enrollment.exception.EnrollmentServiceException;
import com.anthem.enrollment.oracle.domain.Cntrct;
import com.anthem.enrollment.oracle.domain.ProductInfo;
import com.anthem.enrollment.service.PrdctService;


@RestController
public class PrdctController{


    @Autowired
    private PrdctService prdctService;
  
    @RequestMapping(value = "/getCntrctDetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Cntrct>  getCntrctsDetail(@RequestParam Long grpId) throws EnrollmentServiceException{
    	String cvrgTypCd ="MEDICAL";
        	List<Cntrct> cntrctDetails = prdctService.getCntrctdetails(grpId,cvrgTypCd);
            return cntrctDetails;
    }
}
