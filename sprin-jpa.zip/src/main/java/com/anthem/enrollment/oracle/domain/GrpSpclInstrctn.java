package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * The persistent class for the GRP_SPCL_INSTRCTN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_SPCL_INSTRCTN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpSpclInstrctn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_SPCL_INSTRCTN_ID")
	private long grpSpclInstrctnId;

	//@Temporal(TemporalType.DATE)
	@Column(name="BIRTHDATE_RULE_EFCTV_DT")
	private Date birthdateRuleEfctvDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="ELCTRNC_EXPLNTN_COPY")
	private String elctrncExplntnCopy;

	@Column(name="EXPCTD_RTRMNT_BRKT_CD")
	private String expctdRtrmntBrktCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="FED_DSCLSR_DT")
	private Date fedDsclsrDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="FLEX_BNFT_EFCTV_DT")
	private Date flexBnftEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="FOCAL_RNWL_DT")
	private Date focalRnwlDt;

	@Column(name="GRP_BUS_TYPE_CD")
	private String grpBusTypeCd;

	@Column(name="GRP_PRCS_CD")
	private String grpPrcsCd;

	//@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="GRP_SPCL_INSTRCTN_EFCTV_DT")
	private Date grpSpclInstrctnEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_SPCL_INSTRCTN_TRMNTN_DT")
	private Date grpSpclInstrctnTrmntnDt;

	@Column(name="GRP_SPCL_INSTRCTN_TXT")
	private String grpSpclInstrctnTxt;

	@Column(name="GRP_SPCL_INSTRCTN_TYPE_CD")
	private String grpSpclInstrctnTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LGL_ENTY_CD")
	private String lglEntyCd;

	@Column(name="MBRSHP_LCTN_CD")
	private String mbrshpLctnCd;

	@Column(name="MEDCR_PRC_RULES_CD")
	private String medcrPrcRulesCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="NATL_CARE_NTWK_RFRL_EFCTV_DT")
	private Date natlCareNtwkRfrlEfctvDt;

	@Column(name="PRIOR_ID_CD")
	private String priorIdCd;

	@Column(name="RETROA_DAYS_ONLN_NBR")
	private BigDecimal retroaDaysOnlnNbr;

	@Column(name="RETROA_DAYS_TAPE_NBR")
	private BigDecimal retroaDaysTapeNbr;

	@Column(name="RLTD_GRP_ID")
	private BigDecimal rltdGrpId;

	@Column(name="RT_EVALN_MNTH_NBR")
	private BigDecimal rtEvalnMnthNbr;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="STOK_SBSDRY_DT")
	private Date stokSbsdryDt;

	@Column(name="TERM_RVRS_LESS_MNGMNT_PRSN_PGM")
	private BigDecimal termRvrsLessMngmntPrsnPgm;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="UNDRWRTR_RQRMNT_SENT_DT")
	private Date undrwrtrRqrmntSentDt;

	@Column(name="UNDRWRTR_WORK_MNTH_NBR")
	private BigDecimal undrwrtrWorkMnthNbr;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpSpclInstrctn() {
	}

	public long getGrpSpclInstrctnId() {
		return this.grpSpclInstrctnId;
	}

	public void setGrpSpclInstrctnId(long grpSpclInstrctnId) {
		this.grpSpclInstrctnId = grpSpclInstrctnId;
	}

	public Date getBirthdateRuleEfctvDt() {
		return this.birthdateRuleEfctvDt;
	}

	public void setBirthdateRuleEfctvDt(Date birthdateRuleEfctvDt) {
		this.birthdateRuleEfctvDt = birthdateRuleEfctvDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getElctrncExplntnCopy() {
		return this.elctrncExplntnCopy;
	}

	public void setElctrncExplntnCopy(String elctrncExplntnCopy) {
		this.elctrncExplntnCopy = elctrncExplntnCopy;
	}

	public String getExpctdRtrmntBrktCd() {
		return this.expctdRtrmntBrktCd;
	}

	public void setExpctdRtrmntBrktCd(String expctdRtrmntBrktCd) {
		this.expctdRtrmntBrktCd = expctdRtrmntBrktCd;
	}

	public Date getFedDsclsrDt() {
		return this.fedDsclsrDt;
	}

	public void setFedDsclsrDt(Date fedDsclsrDt) {
		this.fedDsclsrDt = fedDsclsrDt;
	}

	public Date getFlexBnftEfctvDt() {
		return this.flexBnftEfctvDt;
	}

	public void setFlexBnftEfctvDt(Date flexBnftEfctvDt) {
		this.flexBnftEfctvDt = flexBnftEfctvDt;
	}

	public Date getFocalRnwlDt() {
		return this.focalRnwlDt;
	}

	public void setFocalRnwlDt(Date focalRnwlDt) {
		this.focalRnwlDt = focalRnwlDt;
	}

	public String getGrpBusTypeCd() {
		return this.grpBusTypeCd;
	}

	public void setGrpBusTypeCd(String grpBusTypeCd) {
		this.grpBusTypeCd = grpBusTypeCd;
	}

	public String getGrpPrcsCd() {
		return this.grpPrcsCd;
	}

	public void setGrpPrcsCd(String grpPrcsCd) {
		this.grpPrcsCd = grpPrcsCd;
	}

	public Date getGrpSpclInstrctnEfctvDt() {
		return this.grpSpclInstrctnEfctvDt;
	}

	public void setGrpSpclInstrctnEfctvDt(Date grpSpclInstrctnEfctvDt) {
		this.grpSpclInstrctnEfctvDt = grpSpclInstrctnEfctvDt;
	}

	public Date getGrpSpclInstrctnTrmntnDt() {
		return this.grpSpclInstrctnTrmntnDt;
	}

	public void setGrpSpclInstrctnTrmntnDt(Date grpSpclInstrctnTrmntnDt) {
		this.grpSpclInstrctnTrmntnDt = grpSpclInstrctnTrmntnDt;
	}

	public String getGrpSpclInstrctnTxt() {
		return this.grpSpclInstrctnTxt;
	}

	public void setGrpSpclInstrctnTxt(String grpSpclInstrctnTxt) {
		this.grpSpclInstrctnTxt = grpSpclInstrctnTxt;
	}

	public String getGrpSpclInstrctnTypeCd() {
		return this.grpSpclInstrctnTypeCd;
	}

	public void setGrpSpclInstrctnTypeCd(String grpSpclInstrctnTypeCd) {
		this.grpSpclInstrctnTypeCd = grpSpclInstrctnTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLglEntyCd() {
		return this.lglEntyCd;
	}

	public void setLglEntyCd(String lglEntyCd) {
		this.lglEntyCd = lglEntyCd;
	}

	public String getMbrshpLctnCd() {
		return this.mbrshpLctnCd;
	}

	public void setMbrshpLctnCd(String mbrshpLctnCd) {
		this.mbrshpLctnCd = mbrshpLctnCd;
	}

	public String getMedcrPrcRulesCd() {
		return this.medcrPrcRulesCd;
	}

	public void setMedcrPrcRulesCd(String medcrPrcRulesCd) {
		this.medcrPrcRulesCd = medcrPrcRulesCd;
	}

	public Date getNatlCareNtwkRfrlEfctvDt() {
		return this.natlCareNtwkRfrlEfctvDt;
	}

	public void setNatlCareNtwkRfrlEfctvDt(Date natlCareNtwkRfrlEfctvDt) {
		this.natlCareNtwkRfrlEfctvDt = natlCareNtwkRfrlEfctvDt;
	}

	public String getPriorIdCd() {
		return this.priorIdCd;
	}

	public void setPriorIdCd(String priorIdCd) {
		this.priorIdCd = priorIdCd;
	}

	public BigDecimal getRetroaDaysOnlnNbr() {
		return this.retroaDaysOnlnNbr;
	}

	public void setRetroaDaysOnlnNbr(BigDecimal retroaDaysOnlnNbr) {
		this.retroaDaysOnlnNbr = retroaDaysOnlnNbr;
	}

	public BigDecimal getRetroaDaysTapeNbr() {
		return this.retroaDaysTapeNbr;
	}

	public void setRetroaDaysTapeNbr(BigDecimal retroaDaysTapeNbr) {
		this.retroaDaysTapeNbr = retroaDaysTapeNbr;
	}

	public BigDecimal getRltdGrpId() {
		return this.rltdGrpId;
	}

	public void setRltdGrpId(BigDecimal rltdGrpId) {
		this.rltdGrpId = rltdGrpId;
	}

	public BigDecimal getRtEvalnMnthNbr() {
		return this.rtEvalnMnthNbr;
	}

	public void setRtEvalnMnthNbr(BigDecimal rtEvalnMnthNbr) {
		this.rtEvalnMnthNbr = rtEvalnMnthNbr;
	}

	public Date getStokSbsdryDt() {
		return this.stokSbsdryDt;
	}

	public void setStokSbsdryDt(Date stokSbsdryDt) {
		this.stokSbsdryDt = stokSbsdryDt;
	}

	public BigDecimal getTermRvrsLessMngmntPrsnPgm() {
		return this.termRvrsLessMngmntPrsnPgm;
	}

	public void setTermRvrsLessMngmntPrsnPgm(BigDecimal termRvrsLessMngmntPrsnPgm) {
		this.termRvrsLessMngmntPrsnPgm = termRvrsLessMngmntPrsnPgm;
	}

	public Date getUndrwrtrRqrmntSentDt() {
		return this.undrwrtrRqrmntSentDt;
	}

	public void setUndrwrtrRqrmntSentDt(Date undrwrtrRqrmntSentDt) {
		this.undrwrtrRqrmntSentDt = undrwrtrRqrmntSentDt;
	}

	public BigDecimal getUndrwrtrWorkMnthNbr() {
		return this.undrwrtrWorkMnthNbr;
	}

	public void setUndrwrtrWorkMnthNbr(BigDecimal undrwrtrWorkMnthNbr) {
		this.undrwrtrWorkMnthNbr = undrwrtrWorkMnthNbr;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpSpclInstrctn [grpSpclInstrctnId=" + grpSpclInstrctnId + ", birthdateRuleEfctvDt="
				+ (birthdateRuleEfctvDt!=null?formatter.format(birthdateRuleEfctvDt):null) + ", elctrncExplntnCopy=" + elctrncExplntnCopy + ", expctdRtrmntBrktCd="
				+ expctdRtrmntBrktCd + ", fedDsclsrDt=" + (fedDsclsrDt!=null?formatter.format(fedDsclsrDt):null) + ", flexBnftEfctvDt=" + (flexBnftEfctvDt!=null?formatter.format(flexBnftEfctvDt):null)
				+ ", focalRnwlDt=" + (focalRnwlDt!=null?formatter.format(focalRnwlDt):null) + ", grpBusTypeCd=" + grpBusTypeCd + ", grpPrcsCd=" + grpPrcsCd
				+ ", grpSpclInstrctnEfctvDt=" + (grpSpclInstrctnEfctvDt!=null?formatter.format(grpSpclInstrctnEfctvDt):null) + ", grpSpclInstrctnTrmntnDt="
				+ (grpSpclInstrctnTrmntnDt!=null?formatter.format(grpSpclInstrctnTrmntnDt):null) + ", grpSpclInstrctnTxt=" + grpSpclInstrctnTxt + ", grpSpclInstrctnTypeCd="
				+ grpSpclInstrctnTypeCd + ", lastUpdtdByUserId=" + lastUpdtdByUserId + ", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null)
				+ ", lglEntyCd=" + lglEntyCd + ", mbrshpLctnCd=" + mbrshpLctnCd + ", medcrPrcRulesCd=" + medcrPrcRulesCd
				+ ", natlCareNtwkRfrlEfctvDt=" + (natlCareNtwkRfrlEfctvDt!=null?formatter.format(natlCareNtwkRfrlEfctvDt):null) + ", priorIdCd=" + priorIdCd
				+ ", retroaDaysOnlnNbr=" + retroaDaysOnlnNbr + ", retroaDaysTapeNbr=" + retroaDaysTapeNbr
				+ ", rltdGrpId=" + rltdGrpId + ", rtEvalnMnthNbr=" + rtEvalnMnthNbr + ", stokSbsdryDt=" + (stokSbsdryDt!=null?formatter.format(stokSbsdryDt):null)
				+ ", undrwrtrRqrmntSentDt=" + (undrwrtrRqrmntSentDt!=null?formatter.format(undrwrtrRqrmntSentDt):null) + ", undrwrtrWorkMnthNbr=" + undrwrtrWorkMnthNbr
				+ ", vrsnNbr=" + vrsnNbr + "]";
	}

	
}