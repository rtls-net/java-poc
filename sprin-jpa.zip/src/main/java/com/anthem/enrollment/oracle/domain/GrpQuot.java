package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the GRP_QUOT database table.
 * 
 */
@Entity
//@DynamicUpdate
@Table(name = "GRP_QUOT")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class GrpQuot implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "GRP_QUOT_ID")
	private Long grpQuotId;

	@Column(name = "ACTN_TYPE")
	private String actnType;

	@Column(name = "BILL_FRQNCY_CD")
	private String billFrqncyCd;
	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;
	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;
	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "PROD_CNT")
	private BigDecimal prodCnt;

	@Temporal(TemporalType.DATE)
	@Column(name = "QUOT_DT")
	private Date quotDt;

	@Column(name = "QUOT_ID")
	private String quotId;

	@Column(name = "QUOT_PRCSR_ID")
	private String quotPrcsrId;

	@Column(name = "QUOT_STTS_CD")
	private String quotSttsCd;

	@Column(name = "QUOT_SYS_CD")
	private String quotSysCd;
	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	// bi-directional many-to-one association to Cntrct
	@OneToMany(mappedBy = "grpQuot")
	private List<Cntrct> cntrcts;

	// bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GRP_ID")
	private Grp grp;

	// bi-directional many-to-one association to LdProd
	@JsonIgnore
	@OneToMany(mappedBy = "grpQuot")
	private List<LdProd> ldProds;

	public GrpQuot() {
	}

	public Long getGrpQuotId() {
		return this.grpQuotId;
	}

	public void setGrpQuotId(Long grpQuotId) {
		this.grpQuotId = grpQuotId;
	}

	public String getActnType() {
		return this.actnType;
	}

	public void setActnType(String actnType) {
		this.actnType = actnType;
	}

	public String getBillFrqncyCd() {
		return this.billFrqncyCd;
	}

	public void setBillFrqncyCd(String billFrqncyCd) {
		this.billFrqncyCd = billFrqncyCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public BigDecimal getProdCnt() {
		return this.prodCnt;
	}

	public void setProdCnt(BigDecimal prodCnt) {
		this.prodCnt = prodCnt;
	}

	public Date getQuotDt() {
		return this.quotDt;
	}

	public void setQuotDt(Date quotDt) {
		this.quotDt = quotDt;
	}

	public String getQuotId() {
		return this.quotId;
	}

	public void setQuotId(String quotId) {
		this.quotId = quotId;
	}

	public String getQuotPrcsrId() {
		return this.quotPrcsrId;
	}

	public void setQuotPrcsrId(String quotPrcsrId) {
		this.quotPrcsrId = quotPrcsrId;
	}

	public String getQuotSttsCd() {
		return this.quotSttsCd;
	}

	public void setQuotSttsCd(String quotSttsCd) {
		this.quotSttsCd = quotSttsCd;
	}

	public String getQuotSysCd() {
		return this.quotSysCd;
	}

	public void setQuotSysCd(String quotSysCd) {
		this.quotSysCd = quotSysCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public List<Cntrct> getCntrcts() {
		return this.cntrcts;
	}

	public void setCntrcts(List<Cntrct> cntrcts) {
		this.cntrcts = cntrcts;
	}

	public Cntrct addCntrct(Cntrct cntrct) {
		getCntrcts().add(cntrct);
		cntrct.setGrpQuot(this);

		return cntrct;
	}

	public Cntrct removeCntrct(Cntrct cntrct) {
		getCntrcts().remove(cntrct);
		cntrct.setGrpQuot(null);

		return cntrct;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public List<LdProd> getLdProds() {
		return this.ldProds;
	}

	public void setLdProds(List<LdProd> ldProds) {
		this.ldProds = ldProds;
	}

	public LdProd addLdProd(LdProd ldProd) {
		getLdProds().add(ldProd);
		ldProd.setGrpQuot(this);

		return ldProd;
	}

	public LdProd removeLdProd(LdProd ldProd) {
		getLdProds().remove(ldProd);
		ldProd.setGrpQuot(null);

		return ldProd;
	}

}