package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the RFRNC_DATA_ITEM_ADDNL_ATRB_VAL database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="RFRNC_DATA_ITEM_ADDNL_ATRB_VAL")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RfrncDataItemAddnlAtrbVal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="RFRNC_DATA_ITEM_ADDNL_ATRB_VAL")
	private long rfrncDataItemAddnlAtrbVal;

	@Column(name="ADDNL_ATRB_CD_VAL_CD")
	private String addnlAtrbCdValCd;

	@Column(name="ADDNL_ATRB_CD_VAL_TXT")
	private String addnlAtrbCdValTxt;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDNL_ATRB_EFCTV_DT")
	private Date addnlAtrbEfctvDt;

	@Column(name="ADDNL_ATRB_NM")
	private String addnlAtrbNm;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDNL_ATRB_TRMNTN_DT")
	private Date addnlAtrbTrmntnDt;

	@Column(name="ADDNL_ATRB_VAL_SQNC_NBR")
	private BigDecimal addnlAtrbValSqncNbr;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="UPDT_IND")
	private String updtInd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to CdVal
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CD_VAL_ID")
	private CdVal cdVal;

	//bi-directional many-to-one association to RfrncDataItemAddnlAtrb
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RFRNC_DATA_ITEM_ADDNL_ATRB_ID")
	private RfrncDataItemAddnlAtrb rfrncDataItemAddnlAtrb;

	public RfrncDataItemAddnlAtrbVal() {
	}

	public long getRfrncDataItemAddnlAtrbVal() {
		return this.rfrncDataItemAddnlAtrbVal;
	}

	public void setRfrncDataItemAddnlAtrbVal(long rfrncDataItemAddnlAtrbVal) {
		this.rfrncDataItemAddnlAtrbVal = rfrncDataItemAddnlAtrbVal;
	}

	public String getAddnlAtrbCdValCd() {
		return this.addnlAtrbCdValCd;
	}

	public void setAddnlAtrbCdValCd(String addnlAtrbCdValCd) {
		this.addnlAtrbCdValCd = addnlAtrbCdValCd;
	}

	public String getAddnlAtrbCdValTxt() {
		return this.addnlAtrbCdValTxt;
	}

	public void setAddnlAtrbCdValTxt(String addnlAtrbCdValTxt) {
		this.addnlAtrbCdValTxt = addnlAtrbCdValTxt;
	}

	public Date getAddnlAtrbEfctvDt() {
		return this.addnlAtrbEfctvDt;
	}

	public void setAddnlAtrbEfctvDt(Date addnlAtrbEfctvDt) {
		this.addnlAtrbEfctvDt = addnlAtrbEfctvDt;
	}

	public String getAddnlAtrbNm() {
		return this.addnlAtrbNm;
	}

	public void setAddnlAtrbNm(String addnlAtrbNm) {
		this.addnlAtrbNm = addnlAtrbNm;
	}

	public Date getAddnlAtrbTrmntnDt() {
		return this.addnlAtrbTrmntnDt;
	}

	public void setAddnlAtrbTrmntnDt(Date addnlAtrbTrmntnDt) {
		this.addnlAtrbTrmntnDt = addnlAtrbTrmntnDt;
	}

	public BigDecimal getAddnlAtrbValSqncNbr() {
		return this.addnlAtrbValSqncNbr;
	}

	public void setAddnlAtrbValSqncNbr(BigDecimal addnlAtrbValSqncNbr) {
		this.addnlAtrbValSqncNbr = addnlAtrbValSqncNbr;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getUpdtInd() {
		return this.updtInd;
	}

	public void setUpdtInd(String updtInd) {
		this.updtInd = updtInd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public CdVal getCdVal() {
		return this.cdVal;
	}

	public void setCdVal(CdVal cdVal) {
		this.cdVal = cdVal;
	}

	public RfrncDataItemAddnlAtrb getRfrncDataItemAddnlAtrb() {
		return this.rfrncDataItemAddnlAtrb;
	}

	public void setRfrncDataItemAddnlAtrb(RfrncDataItemAddnlAtrb rfrncDataItemAddnlAtrb) {
		this.rfrncDataItemAddnlAtrb = rfrncDataItemAddnlAtrb;
	}

}