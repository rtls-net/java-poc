package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SCRN_FLD_ST_LOB_PRFRNC database table.
 * 
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="SCRN_FLD_ST_LOB_PRFRNC")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScrnFldStLobPrfrnc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SCRN_FLD_ST_PRFRNC_ID")
	private long scrnFldStPrfrncId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LOB_CD")
	private String lobCd;

	@Temporal(TemporalType.DATE)
	@Column(name="PRFRNC_EFCTV_DT")
	private Date prfrncEfctvDt;

	@Column(name="PRFRNC_SQNC_NBR")
	private BigDecimal prfrncSqncNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="PRFRNC_TRMNTN_DT")
	private Date prfrncTrmntnDt;

	@Column(name="PRFRNC_TYPE_CD")
	private String prfrncTypeCd;

	@Column(name="PRFRNC_VAL_TXT")
	private String prfrncValTxt;

	@Column(name="ST_CD")
	private String stCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to ScrnFldPrfrnc
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SCRN_FLD_CNFGRN_ID")
	private ScrnFldPrfrnc scrnFldPrfrnc;

	public ScrnFldStLobPrfrnc() {
	}

	public long getScrnFldStPrfrncId() {
		return this.scrnFldStPrfrncId;
	}

	public void setScrnFldStPrfrncId(long scrnFldStPrfrncId) {
		this.scrnFldStPrfrncId = scrnFldStPrfrncId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLobCd() {
		return this.lobCd;
	}

	public void setLobCd(String lobCd) {
		this.lobCd = lobCd;
	}

	public Date getPrfrncEfctvDt() {
		return this.prfrncEfctvDt;
	}

	public void setPrfrncEfctvDt(Date prfrncEfctvDt) {
		this.prfrncEfctvDt = prfrncEfctvDt;
	}

	public BigDecimal getPrfrncSqncNbr() {
		return this.prfrncSqncNbr;
	}

	public void setPrfrncSqncNbr(BigDecimal prfrncSqncNbr) {
		this.prfrncSqncNbr = prfrncSqncNbr;
	}

	public Date getPrfrncTrmntnDt() {
		return this.prfrncTrmntnDt;
	}

	public void setPrfrncTrmntnDt(Date prfrncTrmntnDt) {
		this.prfrncTrmntnDt = prfrncTrmntnDt;
	}

	public String getPrfrncTypeCd() {
		return this.prfrncTypeCd;
	}

	public void setPrfrncTypeCd(String prfrncTypeCd) {
		this.prfrncTypeCd = prfrncTypeCd;
	}

	public String getPrfrncValTxt() {
		return this.prfrncValTxt;
	}

	public void setPrfrncValTxt(String prfrncValTxt) {
		this.prfrncValTxt = prfrncValTxt;
	}

	public String getStCd() {
		return this.stCd;
	}

	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public ScrnFldPrfrnc getScrnFldPrfrnc() {
		return this.scrnFldPrfrnc;
	}

	public void setScrnFldPrfrnc(ScrnFldPrfrnc scrnFldPrfrnc) {
		this.scrnFldPrfrnc = scrnFldPrfrnc;
	}

}