package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the BRKR database table.
 * @author Deloitte
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class Brkr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BRKR_ID")
	private long brkrId;

	@Column(name="AGNT_CD")
	private String agntCd;

	//@Temporal(TemporalType.DATE)
	@Column(name="BRKR_EFCTV_DT")
	private Date brkrEfctvDt;

	@Column(name="BRKR_TYPE_CD")
	private String brkrTypeCd;

	@Column(name="CMSN_PCT_NBR")
	private BigDecimal cmsnPctNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_BRKR_TRMNTN_DT")
	private Date cntrctBrkrTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="CVRG_TYPE_CD")
	private String cvrgTypeCd;

	@Column(name="GNRL_AGNT_IND_CD")
	private String gnrlAgntIndCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="NON_BRKR_CD")
	private String nonBrkrCd;

	@Column(name="OVRD_IND_CD")
	private String ovrdIndCd;

	@Column(name="PARNT_TAX_ID_NBR_CD")
	private String parntTaxIdNbrCd;

	@Column(name="TAX_ID_NBR_CD")
	private String taxIdNbrCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;
	
	//private String errMsgNonBrkr;

	//bi-directional many-to-one association to CntctPrsn
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="CNTCT_PRSN_ID")
	private CntctPrsn cntctPrsn1;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	//bi-directional many-to-one association to CntctPrsn
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="PRNT_CNTCT_PRSN_ID")
	private CntctPrsn cntctPrsn2;

	public Brkr() {
	}

	public long getBrkrId() {
		return this.brkrId;
	}

	public void setBrkrId(long brkrId) {
		this.brkrId = brkrId;
	}

	public String getAgntCd() {
		return this.agntCd;
	}

	public void setAgntCd(String agntCd) {
		this.agntCd = agntCd;
	}

	public Date getBrkrEfctvDt() {
		return this.brkrEfctvDt;
	}

	public void setBrkrEfctvDt(Date brkrEfctvDt) {
		this.brkrEfctvDt = brkrEfctvDt;
	}

	public String getBrkrTypeCd() {
		return this.brkrTypeCd;
	}

	public void setBrkrTypeCd(String brkrTypeCd) {
		this.brkrTypeCd = brkrTypeCd;
	}

	public BigDecimal getCmsnPctNbr() {
		return this.cmsnPctNbr;
	}

	public void setCmsnPctNbr(BigDecimal cmsnPctNbr) {
		this.cmsnPctNbr = cmsnPctNbr;
	}

	public Date getCntrctBrkrTrmntnDt() {
		return this.cntrctBrkrTrmntnDt;
	}

	public void setCntrctBrkrTrmntnDt(Date cntrctBrkrTrmntnDt) {
		this.cntrctBrkrTrmntnDt = cntrctBrkrTrmntnDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgTypeCd() {
		return this.cvrgTypeCd;
	}

	public void setCvrgTypeCd(String cvrgTypeCd) {
		this.cvrgTypeCd = cvrgTypeCd;
	}

	public String getGnrlAgntIndCd() {
		return this.gnrlAgntIndCd;
	}

	public void setGnrlAgntIndCd(String gnrlAgntIndCd) {
		this.gnrlAgntIndCd = gnrlAgntIndCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getNonBrkrCd() {
		return this.nonBrkrCd;
	}

	public void setNonBrkrCd(String nonBrkrCd) {
		this.nonBrkrCd = nonBrkrCd;
	}

	public String getOvrdIndCd() {
		return this.ovrdIndCd;
	}

	public void setOvrdIndCd(String ovrdIndCd) {
		this.ovrdIndCd = ovrdIndCd;
	}

	public String getParntTaxIdNbrCd() {
		return this.parntTaxIdNbrCd;
	}

	public void setParntTaxIdNbrCd(String parntTaxIdNbrCd) {
		this.parntTaxIdNbrCd = parntTaxIdNbrCd;
	}

	public String getTaxIdNbrCd() {
		return this.taxIdNbrCd;
	}

	public void setTaxIdNbrCd(String taxIdNbrCd) {
		this.taxIdNbrCd = taxIdNbrCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public CntctPrsn getCntctPrsn1() {
		return this.cntctPrsn1;
	}

	public void setCntctPrsn1(CntctPrsn cntctPrsn1) {
		this.cntctPrsn1 = cntctPrsn1;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public CntctPrsn getCntctPrsn2() {
		return this.cntctPrsn2;
	}

	public void setCntctPrsn2(CntctPrsn cntctPrsn2) {
		this.cntctPrsn2 = cntctPrsn2;
	}

	/*public String getErrMsgNonBrkr() {
		return errMsgNonBrkr;
	}

	public void setErrMsgNonBrkr(String errMsgNonBrkr) {
		this.errMsgNonBrkr = errMsgNonBrkr;
	}*/
}