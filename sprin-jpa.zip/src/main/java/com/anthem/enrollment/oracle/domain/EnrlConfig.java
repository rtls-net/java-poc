package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the ENRL_CONFIG database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="ENRL_CONFIG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EnrlConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ENRL_CFG_ID")
	private long enrlCfgId;

	@Column(name="BUS_UNIT_CD")
	private String busUnitCd;

	@Column(name="CFG_STATUS")
	private String cfgStatus;

	@CreatedBy
	@Column(name="CREATED_BY")
	private String createdBy;

	@CreatedDate
	@Column(name="CREATED_DTM")
	private Date createdDtm;

	@Column(name="EVNT_TYP_CD")
	private String evntTypCd;

	@LastModifiedBy
	@Column(name="LST_UPD_BY")
	private String lstUpdBy;

	@LastModifiedDate
	@Column(name="LST_UPD_DTM")
	private Date lstUpdDtm;

	public EnrlConfig() {
	}

	public long getEnrlCfgId() {
		return this.enrlCfgId;
	}

	public void setEnrlCfgId(long enrlCfgId) {
		this.enrlCfgId = enrlCfgId;
	}

	public String getBusUnitCd() {
		return this.busUnitCd;
	}

	public void setBusUnitCd(String busUnitCd) {
		this.busUnitCd = busUnitCd;
	}

	public String getCfgStatus() {
		return this.cfgStatus;
	}

	public void setCfgStatus(String cfgStatus) {
		this.cfgStatus = cfgStatus;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDtm() {
		return this.createdDtm;
	}

	public void setCreatedDtm(Date createdDtm) {
		this.createdDtm = createdDtm;
	}

	public String getEvntTypCd() {
		return this.evntTypCd;
	}

	public void setEvntTypCd(String evntTypCd) {
		this.evntTypCd = evntTypCd;
	}

	public String getLstUpdBy() {
		return this.lstUpdBy;
	}

	public void setLstUpdBy(String lstUpdBy) {
		this.lstUpdBy = lstUpdBy;
	}

	public Date getLstUpdDtm() {
		return this.lstUpdDtm;
	}

	public void setLstUpdDtm(Date lstUpdDtm) {
		this.lstUpdDtm = lstUpdDtm;
	}

}