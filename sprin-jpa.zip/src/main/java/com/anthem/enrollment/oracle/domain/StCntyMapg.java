package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the ST_CNTY_MAPG database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="ST_CNTY_MAPG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StCntyMapg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ZIP_ST_MAPG_ID")
	private long zipStMapgId;

	@Column(name="CNTY_CD")
	private String cntyCd;

	@Column(name="CNTY_NM")
	private String cntyNm;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="ST_CD")
	private String stCd;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	/*@OneToOne(fetch = FetchType.LAZY,
			cascade =  CascadeType.ALL,
			mappedBy = "stCntyMapg")
	private ZipCntyMapg zipCntyMapg;*/

	public StCntyMapg() {
	}

	public long getZipStMapgId() {
		return this.zipStMapgId;
	}

	public void setZipStMapgId(long zipStMapgId) {
		this.zipStMapgId = zipStMapgId;
	}

	public String getCntyCd() {
		return this.cntyCd;
	}

	public void setCntyCd(String cntyCd) {
		this.cntyCd = cntyCd;
	}

	public String getCntyNm() {
		return this.cntyNm;
	}

	public void setCntyNm(String cntyNm) {
		this.cntyNm = cntyNm;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getStCd() {
		return this.stCd;
	}

	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}