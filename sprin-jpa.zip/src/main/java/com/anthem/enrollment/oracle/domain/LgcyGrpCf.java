package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the LGCY_GRP_CF database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="LGCY_GRP_CF")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LgcyGrpCf implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LGCY_GRP_CF_ID")
	private long lgcyGrpCfId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	//@Temporal(TemporalType.DATE)
	@Column(name="LGCY_GRP_CF_EFCTV_DT")
	private Date lgcyGrpCfEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="LGCY_GRP_CF_TRMNTN_DT")
	private Date lgcyGrpCfTrmntnDt;

	@Column(name="LGCY_LCTN_LOB_CD")
	private String lgcyLctnLobCd;

	@Column(name="LGCY_MBU_CD")
	private String lgcyMbuCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="LGCY_MBU_CD_EFCTV_DT")
	private Date lgcyMbuCdEfctvDt;

	@Column(name="LGCY_SRVC_LCTN_CD")
	private String lgcySrvcLctnCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="LGCY_SRVC_LCTN_CD_EFCTV_DT")
	private Date lgcySrvcLctnCdEfctvDt;

	@Column(name="LGCY_WORK_LCTN_CD")
	private String lgcyWorkLctnCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="LGCY_WORK_LCTN_CD_EFCTV_DT")
	private Date lgcyWorkLctnCdEfctvDt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public LgcyGrpCf() {
	}

	public long getLgcyGrpCfId() {
		return this.lgcyGrpCfId;
	}

	public void setLgcyGrpCfId(long lgcyGrpCfId) {
		this.lgcyGrpCfId = lgcyGrpCfId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Date getLgcyGrpCfEfctvDt() {
		return this.lgcyGrpCfEfctvDt;
	}

	public void setLgcyGrpCfEfctvDt(Date lgcyGrpCfEfctvDt) {
		this.lgcyGrpCfEfctvDt = lgcyGrpCfEfctvDt;
	}

	public Date getLgcyGrpCfTrmntnDt() {
		return this.lgcyGrpCfTrmntnDt;
	}

	public void setLgcyGrpCfTrmntnDt(Date lgcyGrpCfTrmntnDt) {
		this.lgcyGrpCfTrmntnDt = lgcyGrpCfTrmntnDt;
	}

	public String getLgcyLctnLobCd() {
		
		return this.lgcyLctnLobCd;
	}

	public void setLgcyLctnLobCd(String lgcyLctnLobCd) {
		this.lgcyLctnLobCd = lgcyLctnLobCd;
	}

	public String getLgcyMbuCd() {
		return this.lgcyMbuCd;
	}

	public void setLgcyMbuCd(String lgcyMbuCd) {
		this.lgcyMbuCd = lgcyMbuCd;
	}

	public Date getLgcyMbuCdEfctvDt() {
		return this.lgcyMbuCdEfctvDt;
	}

	public void setLgcyMbuCdEfctvDt(Date lgcyMbuCdEfctvDt) {
		this.lgcyMbuCdEfctvDt = lgcyMbuCdEfctvDt;
	}

	public String getLgcySrvcLctnCd() {
		return this.lgcySrvcLctnCd;
	}

	public void setLgcySrvcLctnCd(String lgcySrvcLctnCd) {
		this.lgcySrvcLctnCd = lgcySrvcLctnCd;
	}

	public Date getLgcySrvcLctnCdEfctvDt() {
		return this.lgcySrvcLctnCdEfctvDt;
	}

	public void setLgcySrvcLctnCdEfctvDt(Date lgcySrvcLctnCdEfctvDt) {
		this.lgcySrvcLctnCdEfctvDt = lgcySrvcLctnCdEfctvDt;
	}

	public String getLgcyWorkLctnCd() {
		return this.lgcyWorkLctnCd;
	}

	public void setLgcyWorkLctnCd(String lgcyWorkLctnCd) {
		this.lgcyWorkLctnCd = lgcyWorkLctnCd;
	}

	public Date getLgcyWorkLctnCdEfctvDt() {
		return this.lgcyWorkLctnCdEfctvDt;
	}

	public void setLgcyWorkLctnCdEfctvDt(Date lgcyWorkLctnCdEfctvDt) {
		this.lgcyWorkLctnCdEfctvDt = lgcyWorkLctnCdEfctvDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}