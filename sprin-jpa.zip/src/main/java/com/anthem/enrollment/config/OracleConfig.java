package com.anthem.enrollment.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;


@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManagerFactory",
        basePackages = { "com.anthem.enrollment.oracle.dao"}
)
public class OracleConfig {

	
	
	@Value("${spring.datasource.jdbc-url}")
	 private String url;
	
	@Value("${spring.datasource.username}")
	 private String username;
	
	@Value("${spring.datasource.password}")
	 private String password;
	
	@Value("${spring.datasource.driver-class-name}")
	 private String driverClassName;
	
	@Value("${spring.datasource.hikari.maximum-pool-size}")
	 private int maxPoolSize;
	
	@Value("${spring.datasource.hikari.minimum-idle}")
	 private int minPoolSize;
	
	@Value("${spring.datasource.hikari.pool-name}")
	 private String poolName;
	
	@Value("${spring.datasource.hikari.idle-timeout}")
	 private int idleTimeout;
	
	@Value("${spring.datasource.hikari.connection-timeout}")
	 private int connectionTimeout;
	
	@Value("${spring.datasource.hikari.connection-test-query}")
	 private String connectionTestQuery;
	
	@Value("${spring.datasource.hikari.max-lifetime}")
	 private Long maxLifetimeMs;
	
	
	@Primary
    @Bean(name = "dataSource")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {  
		HikariConfig config = new HikariConfig();
        
        config.setJdbcUrl(url);
        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(maxPoolSize);
        config.setMinimumIdle(minPoolSize);
         config.setPoolName(poolName);
         config.setDriverClassName(driverClassName);
         config.setIdleTimeout(idleTimeout);
         config.setConnectionTimeout(connectionTimeout);
         config.setConnectionTestQuery(connectionTestQuery);
         config.setMaxLifetime(maxLifetimeMs);
        return new HikariDataSource(config);
		
		
    } 
    @Primary
    @Bean(name = "entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(
            EntityManagerFactoryBuilder builder, @Qualifier("dataSource") DataSource dataSource) {
        return builder.dataSource(dataSource).packages("com.anthem.enrollment.oracle.domain").persistenceUnit("oracle")
                .build();
    }

    @Primary
    @Bean(name = "transactionManager")
    public PlatformTransactionManager transactionManager(
            @Qualifier("entityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
}
