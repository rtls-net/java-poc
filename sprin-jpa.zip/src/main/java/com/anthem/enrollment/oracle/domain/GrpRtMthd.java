package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the GRP_RT_MTHD database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_RT_MTHD")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpRtMthd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="GRP_RT_MTHD_ID")
	private long grpRtMthdId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_BILL_DT")
	private Date grpBillDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_RT_EFCTV_DT")
	private Date grpRtEfctvDt;

	@Column(name="GRP_RT_MTHD_CD")
	private String grpRtMthdCd;

	@Column(name="GRP_RT_MTHD_TYPE_CD")
	private String grpRtMthdTypeCd;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_RT_TRMNTN_DT")
	private Date grpRtTrmntnDt;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpRtMthd() {
	}

	public long getGrpRtMthdId() {
		return this.grpRtMthdId;
	}

	public void setGrpRtMthdId(long grpRtMthdId) {
		this.grpRtMthdId = grpRtMthdId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpBillDt() {
		return this.grpBillDt;
	}

	public void setGrpBillDt(Date grpBillDt) {
		this.grpBillDt = grpBillDt;
	}

	public Date getGrpRtEfctvDt() {
		return this.grpRtEfctvDt;
	}

	public void setGrpRtEfctvDt(Date grpRtEfctvDt) {
		this.grpRtEfctvDt = grpRtEfctvDt;
	}

	public String getGrpRtMthdCd() {
		return this.grpRtMthdCd;
	}

	public void setGrpRtMthdCd(String grpRtMthdCd) {
		this.grpRtMthdCd = grpRtMthdCd;
	}

	public String getGrpRtMthdTypeCd() {
		return this.grpRtMthdTypeCd;
	}

	public void setGrpRtMthdTypeCd(String grpRtMthdTypeCd) {
		this.grpRtMthdTypeCd = grpRtMthdTypeCd;
	}

	public Date getGrpRtTrmntnDt() {
		return this.grpRtTrmntnDt;
	}

	public void setGrpRtTrmntnDt(Date grpRtTrmntnDt) {
		this.grpRtTrmntnDt = grpRtTrmntnDt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}