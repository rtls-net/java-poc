package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Version;


/**
 * The persistent class for the PROD_MSG_SET_CNFGRN database table.
 * 
 */
@Entity
@Table(name="PROD_MSG_SET_CNFGRN")
public class ProdMsgSetCnfgrn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	/*@SequenceGenerator(name="PROD_MSG_SET_CNFGRN_PRODMSGSETCNFGRNID_GENERATOR", sequenceName="PROD_MSG_SET_CNFGRN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROD_MSG_SET_CNFGRN_PRODMSGSETCNFGRNID_GENERATOR")*/
	@Column(name="PROD_MSG_SET_CNFGRN_ID")
	private long prodMsgSetCnfgrnId;

	@Column(name="BGN_DT")
	private String bgnDt;

	@Column(name="CNTRCT_CD")
	private String cntrctCd;

	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@Column(name="CREATD_DTM")
	private Timestamp creatdDtm;

	@Column(name="END_DT")
	private String endDt;

	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@Column(name="LAST_UPDTD_DTM")
	private Timestamp lastUpdtdDtm;

	@Column(name="MSG_SET_NBR")
	private String msgSetNbr;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	public ProdMsgSetCnfgrn() {
	}

	public long getProdMsgSetCnfgrnId() {
		return this.prodMsgSetCnfgrnId;
	}

	public void setProdMsgSetCnfgrnId(long prodMsgSetCnfgrnId) {
		this.prodMsgSetCnfgrnId = prodMsgSetCnfgrnId;
	}

	public String getBgnDt() {
		return this.bgnDt;
	}

	public void setBgnDt(String bgnDt) {
		this.bgnDt = bgnDt;
	}

	public String getCntrctCd() {
		return this.cntrctCd;
	}

	public void setCntrctCd(String cntrctCd) {
		this.cntrctCd = cntrctCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getEndDt() {
		return this.endDt;
	}

	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Timestamp getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Timestamp lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getMsgSetNbr() {
		return this.msgSetNbr;
	}

	public void setMsgSetNbr(String msgSetNbr) {
		this.msgSetNbr = msgSetNbr;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}