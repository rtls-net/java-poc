package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the BSP_SQL_QUERIES database table.
 * @author Deloitte
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="BSP_SQL_QUERIES")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BspSqlQuery implements Serializable {
	private static final long serialVersionUID = 1L;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="QUERY_KEY")
	@Id
	private String queryKey;

	@Lob
	@Column(name="QUERY_TXT")
	private String queryTxt;

	@Column(name="SCRN_PRFRNC_ID")
	private BigDecimal scrnPrfrncId;

	public BspSqlQuery() {
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getQueryKey() {
		return this.queryKey;
	}

	public void setQueryKey(String queryKey) {
		this.queryKey = queryKey;
	}

	public String getQueryTxt() {
		return this.queryTxt;
	}

	public void setQueryTxt(String queryTxt) {
		this.queryTxt = queryTxt;
	}

	public BigDecimal getScrnPrfrncId() {
		return this.scrnPrfrncId;
	}

	public void setScrnPrfrncId(BigDecimal scrnPrfrncId) {
		this.scrnPrfrncId = scrnPrfrncId;
	}

}