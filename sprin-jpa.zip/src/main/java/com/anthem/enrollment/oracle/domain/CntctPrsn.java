package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CNTCT_PRSN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTCT_PRSN")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntctPrsn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CNTCT_PRSN_ID")
	private Long cntctPrsnId;

	@Column(name="CNTCT_PRSN_FRST_NM")
	private String cntctPrsnFrstNm;

	@Column(name="CNTCT_PRSN_LAST_NM")
	private String cntctPrsnLastNm;

	@Column(name="CNTCT_PRSN_MID_NM")
	private String cntctPrsnMidNm;

	@Column(name="CNTCT_PRSN_TTL_NM")
	private String cntctPrsnTtlNm;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="ORG_NM")
	private String cntctOrgNm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Brkr
	/*@JsonIgnore
	@OneToMany(mappedBy="cntctPrsn1")
	private List<Brkr> brkrs1;*/

	//bi-directional many-to-one association to Brkr
	/*@JsonIgnore
	@OneToMany(mappedBy="cntctPrsn2")
	private List<Brkr> brkrs2;*/

	@JsonIgnore
	@OneToOne(mappedBy="cntctPrsn1")
	private Brkr brkr1;

	@JsonIgnore
	@OneToOne(mappedBy="cntctPrsn2")
	private Brkr brkr2;

	//bi-directional many-to-one association to GrpCntctPrsn
	@JsonIgnore
	@OneToMany(mappedBy="cntctPrsn")
	private List<GrpCntctPrsn> grpCntctPrsns;

	public CntctPrsn() {
	}

	public Long getCntctPrsnId() {
		return this.cntctPrsnId;
	}

	public void setCntctPrsnId(Long cntctPrsnId) {
		this.cntctPrsnId = cntctPrsnId;
	}

	public String getCntctPrsnFrstNm() {
		return this.cntctPrsnFrstNm;
	}

	public void setCntctPrsnFrstNm(String cntctPrsnFrstNm) {
		this.cntctPrsnFrstNm = cntctPrsnFrstNm;
	}

	public String getCntctPrsnLastNm() {
		return this.cntctPrsnLastNm;
	}

	public void setCntctPrsnLastNm(String cntctPrsnLastNm) {
		this.cntctPrsnLastNm = cntctPrsnLastNm;
	}

	public String getCntctPrsnMidNm() {
		return this.cntctPrsnMidNm;
	}

	public void setCntctPrsnMidNm(String cntctPrsnMidNm) {
		this.cntctPrsnMidNm = cntctPrsnMidNm;
	}

	public String getCntctPrsnTtlNm() {
		return this.cntctPrsnTtlNm;
	}

	public void setCntctPrsnTtlNm(String cntctPrsnTtlNm) {
		this.cntctPrsnTtlNm = cntctPrsnTtlNm;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getCntctOrgNm() {
		return cntctOrgNm;
	}

	public void setCntctOrgNm(String cntctOrgNm) {
		this.cntctOrgNm = cntctOrgNm;
	}

	/*public List<Brkr> getBrkrs1() {
		return this.brkrs1;
	}*/

	/*public void setBrkrs1(List<Brkr> brkrs1) {
		this.brkrs1 = brkrs1;
	}*/

	/*public Brkr addBrkrs1(Brkr brkrs1) {
		getBrkrs1().add(brkrs1);
		brkrs1.setCntctPrsn1(this);

		return brkrs1;
	}*/

	/*public Brkr removeBrkrs1(Brkr brkrs1) {
		getBrkrs1().remove(brkrs1);
		brkrs1.setCntctPrsn1(null);

		return brkrs1;
	}*/

	/*public List<Brkr> getBrkrs2() {
		return this.brkrs2;
	}*/

	/*public void setBrkrs2(List<Brkr> brkrs2) {
		this.brkrs2 = brkrs2;
	}*/

	/*public Brkr addBrkrs2(Brkr brkrs2) {
		getBrkrs2().add(brkrs2);
		brkrs2.setCntctPrsn2(this);

		return brkrs2;
	}*/

	/*public Brkr removeBrkrs2(Brkr brkrs2) {
		getBrkrs2().remove(brkrs2);
		brkrs2.setCntctPrsn2(null);

		return brkrs2;
	}*/

	public List<GrpCntctPrsn> getGrpCntctPrsns() {
		return this.grpCntctPrsns;
	}

	public void setGrpCntctPrsns(List<GrpCntctPrsn> grpCntctPrsns) {
		this.grpCntctPrsns = grpCntctPrsns;
	}

	public GrpCntctPrsn addGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		getGrpCntctPrsns().add(grpCntctPrsn);
		grpCntctPrsn.setCntctPrsn(this);

		return grpCntctPrsn;
	}

	public GrpCntctPrsn removeGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		getGrpCntctPrsns().remove(grpCntctPrsn);
		grpCntctPrsn.setCntctPrsn(null);

		return grpCntctPrsn;
	}

	public Brkr getBrkr1() {
		return brkr1;
	}

	public void setBrkr1(Brkr brkr1) {
		this.brkr1 = brkr1;
	}

	public Brkr getBrkr2() {
		return brkr2;
	}

	public void setBrkr2(Brkr brkr2) {
		this.brkr2 = brkr2;
	}
}