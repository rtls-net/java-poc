package com.anthem.enrollment.oracle.domain;

import com.anthem.wgs.util.GSMAppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * 
 * ProductInfo - This class wraps all domain objects related to Product.
 *
 * @author Deloitte
 * @version 1.0
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ProductInfo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 4449609275985912517L;

	/** The activate clicked. */
	private String activateClicked;

	/** The save clicked. */
	private String saveClicked;
	
    private List<ProductData> productDataList;

    private Grp grp;

	/** The grp mnthly cntrbtn. */
	private GrpMnthlyCntrbtn grpMnthlyCntrbtn;

	/** The grp prbtn prd. */
	private GrpPrbtnPrd grpPrbtnPrd;

	/** The grp prbtn prd array. */
	private List<GrpPrbtnPrd> grpPrbtnPrdArray;

	/** The grp indctv. */
	private GrpIndctv grpIndctv;

	/** The bill src. */
	private String billSrc;

	/** The crvg type value. */
	private String crvgTypeValue;

	/** The state code. */
	private String stateCode;

	/** The network service code. */
	private String networkServiceCode;

	private String caseNumber;

    private String mrktTypeCd;
	
	/** The dual prbtn class. */
	//LIT-3155
	private String dualPrbtnClass = GSMAppConstants.EMPTY_STRING;
	
	private String errMsg =  GSMAppConstants.EMPTY_STRING;

    /**
     * Gets the activate clicked.
     *
     * @return String
     */
    public String getActivateClicked() {
        return activateClicked;
    }

    /**
     * Sets the activate clicked.
     *
     * @param activateClicked the new activate clicked
     */
    public void setActivateClicked(String activateClicked) {
        this.activateClicked = activateClicked;
    }

    /**
     * Gets the save clicked.
     *
     * @return String
     */
    public String getSaveClicked() {
        return saveClicked;
    }

    /**
     * Sets the save clicked.
     *
     * @param saveClicked the new save clicked
     */
    public void setSaveClicked(String saveClicked) {
        this.saveClicked = saveClicked;
    }

    public List<ProductData> getProductDataList() {
        return productDataList;
    }

    public void setProductDataList(List<ProductData> productDataList) {
        this.productDataList = productDataList;
    }

    public Grp getGrp() {
        return grp;
    }

    public void setGrp(Grp grp) {
        this.grp = grp;
    }

    /**
     * Gets the group mnthly cntrbtn.
     *
     * @return GrpMnthlyCntrbtn
     */
    public GrpMnthlyCntrbtn getGrpMnthlyCntrbtn() {
        return grpMnthlyCntrbtn;
    }

    /**
     * Sets the group mnthly cntrbtn.
     *
     * @param grpMnthlyCntrbtn the new group mnthly cntrbtn
     */
    public void setGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
        this.grpMnthlyCntrbtn = grpMnthlyCntrbtn;
    }

    /**
     * Gets the group prbtn prd.
     *
     * @return GrpPrbtnPrd
     */
    public GrpPrbtnPrd getGrpPrbtnPrd() {
        return grpPrbtnPrd;
    }

    /**
     * Sets the group prbtn prd.
     *
     * @param grpPrbtnPrd the new group prbtn prd
     */
    public void setGrpPrbtnPrd(GrpPrbtnPrd grpPrbtnPrd) {
        this.grpPrbtnPrd = grpPrbtnPrd;
    }

    /**
     * Gets the group prbtn prd array.
     *
     * @return ArrayList<GrpPrbtnPrd>
     */
    public List<GrpPrbtnPrd> getGrpPrbtnPrdArray() {
        return grpPrbtnPrdArray;
    }

    /**
     * Sets the group prbtn prd array.
     *
     * @param grpPrbtnPrdArray the new group prbtn prd array
     */
    public void setGrpPrbtnPrdArray(List<GrpPrbtnPrd> grpPrbtnPrdArray) {
        this.grpPrbtnPrdArray = grpPrbtnPrdArray;
    }


    /**
     * Gets the group indctv.
     *
     * @return GrpIndctv
     */
    public GrpIndctv getGrpIndctv() {
        return grpIndctv;
    }

    /**
     * Sets the group indctv.
     *
     * @param grpIndctv the new group indctv
     */
    public void setGrpIndctv(GrpIndctv grpIndctv) {
        this.grpIndctv = grpIndctv;
    }

    /**
     * Gets the bill src.
     *
     * @return String
     */
    public String getBillSrc() {
        return billSrc;
    }

    /**
     * Sets the bill src.
     *
     * @param billSrc the new bill src
     */
    public void setBillSrc(String billSrc) {
        this.billSrc = billSrc;
    }

    /**
     * Gets the crvg type value.
     *
     * @return String
     */
    public String getCrvgTypeValue() {
        return crvgTypeValue;
    }

    /**
     * Sets the crvg type value.
     *
     * @param crvgTypeValue the new crvg type value
     */
    public void setCrvgTypeValue(String crvgTypeValue) {
        this.crvgTypeValue = crvgTypeValue;
    }

    /**
     * Gets the state code.
     *
     * @return String
     */
    public String getStateCode() {
        return stateCode;
    }

    /**
     * Sets the state code.
     *
     * @param stateCode the new state code
     */
    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    /**
     * Gets the network service code.
     *
     * @return String
     */
    public String getNetworkServiceCode() {
        return networkServiceCode;
    }

    /**
     * Sets the network service code.
     *
     * @param networkServiceCode the new network service code
     */
    public void setNetworkServiceCode(String networkServiceCode) {
        this.networkServiceCode = networkServiceCode;
    }


    /**
     * Gets the dual prbtn class.
     *
     * @return String
     */
    public String getDualPrbtnClass() {
        return dualPrbtnClass;
    }

    /**
     * Sets the dual prbtn class.
     *
     * @param dualPrbtnClass the new dual prbtn class
     */
    public void setDualPrbtnClass(String dualPrbtnClass) {
        this.dualPrbtnClass = dualPrbtnClass;
    }

	/**
	 * @return the caseNumber
	 */
	public String getCaseNumber() {
		return caseNumber;
	}

	/**
	 * @param caseNumber the caseNumber to set
	 */
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

    public String getMrktTypeCd() {
        return mrktTypeCd;
    }

    public void setMrktTypeCd(String mrktTypeCd) {
        this.mrktTypeCd = mrktTypeCd;
    }

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
    
    
}
