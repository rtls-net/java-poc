package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;

public class CustomAddress implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String zipCd;
    private String cityNm;
    private String stNm;
    private String ansiCntyCd;
    private String cntyNm;

    public String getZipCd() {
        return zipCd;
    }

    public void setZipCd(String zipCd) {
        this.zipCd = zipCd;
    }

    public String getCityNm() {
        return cityNm;
    }

    public void setCityNm(String cityNm) {
        this.cityNm = cityNm;
    }

    public String getStNm() {
        return stNm;
    }

    public void setStNm(String stNm) {
        this.stNm = stNm;
    }

    public String getAnsiCntyCd() {
        return ansiCntyCd;
    }

    public void setAnsiCntyCd(String ansiCntyCd) {
        this.ansiCntyCd = ansiCntyCd;
    }

    public String getCntyNm() {
        return cntyNm;
    }

    public void setCntyNm(String cntyNm) {
        this.cntyNm = cntyNm;
    }
}
