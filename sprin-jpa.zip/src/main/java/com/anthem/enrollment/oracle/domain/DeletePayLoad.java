package com.anthem.enrollment.oracle.domain;

public class DeletePayLoad {
//	Long grpId, String cntrctCd, String userID, Long caseId, CaseWrapper caseWrapper,String cntrctIdAtr
	String grpId;
	String cntrctCd;
	String userID;
	String caseId;
	String cntrctIdAtr;
	String getLgcyGrpNbr;

	public String getGetLgcyGrpNbr() {
		return getLgcyGrpNbr;
	}

	public void setGetLgcyGrpNbr(String getLgcyGrpNbr) {
		this.getLgcyGrpNbr = getLgcyGrpNbr;
	}

	public String getGrpId() {
		return grpId;
	}

	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}

	public String getCntrctCd() {
		return cntrctCd;
	}

	public void setCntrctCd(String cntrctCd) {
		this.cntrctCd = cntrctCd;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getCntrctIdAtr() {
		return cntrctIdAtr;
	}

	public void setCntrctIdAtr(String cntrctIdAtr) {
		this.cntrctIdAtr = cntrctIdAtr;
	}

}
