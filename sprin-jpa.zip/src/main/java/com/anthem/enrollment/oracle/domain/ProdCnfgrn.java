package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the PROD_CNFGRN database table.
 * 
 */
@Entity
@Table(name="PROD_CNFGRN")
public class ProdCnfgrn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	/*@SequenceGenerator(name="PROD_CNFGRN_PRODCNFGRNID_GENERATOR", sequenceName="PROD_CNFGRN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROD_CNFGRN_PRODCNFGRNID_GENERATOR")*/
	@Column(name="PROD_CNFGRN_ID")
	private long prodCnfgrnId;

	@Column(name="ACTRL_PROD_CD")
	private String actrlProdCd;

	@Column(name="ADRS_PTR")
	private String adrsPtr;

	@Column(name="AGE_PTR")
	private String agePtr;

	@Column(name="ATT_AGE_RATG_IND")
	private String attAgeRatgInd;

	@Column(name="BCA_PRFX")
	private String bcaPrfx;

	@Column(name="BSIC_PROD_CD_SPLMNTL")
	private String bsicProdCdSplmntl;

	@Column(name="BSNS_CD")
	private String bsnsCd;

	@Column(name="BSNS_CD_EXT")
	private String bsnsCdExt;

	@Column(name="CDH_IND")
	private String cdhInd;

	@Column(name="CMBND_ID_CARD_IND")
	private String cmbndIdCardInd;

	@Column(name="CMPNY_CD")
	private String cmpnyCd;

	@Column(name="CNSMR_CHCE_IND")
	private String cnsmrChceInd;

	@Column(name="CNTNUTN_CD_SORT_IND")
	private String cntnutnCdSortInd;

	@Column(name="CNTRCT_CD")
	private String cntrctCd;

	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@Column(name="CREATD_DTM")
	private Timestamp creatdDtm;

	@Column(name="ENTRY_AGE_RT_IND")
	private String entryAgeRtInd;

	@Column(name="EXCHNG_IND")
	private String exchngInd;

	@Column(name="FLNG_TYPE")
	private String flngType;

	@Column(name="FRC_TO_2_MNTH_BIL")
	private String frcTo2MnthBil;

	@Column(name="FRZ_DT")
	private BigDecimal frzDt;

	@Column(name="HCR_IND")
	private String hcrInd;

	@Column(name="HOSP_ONLY_IND")
	private String hospOnlyInd;

	@Column(name="HSA_PROD_IND")
	private String hsaProdInd;

	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@Column(name="LAST_UPDTD_DTM")
	private Timestamp lastUpdtdDtm;

	@Column(name="LIFE_VOL")
	private String lifeVol;

	private String mbu;

	@Column(name="MHP_IND_FOR_H2_GRP")
	private String mhpIndForH2Grp;

	private String misc1;

	private String misc2;

	private String misc3;

	private String misc4;

	@Column(name="MSA_TYPE")
	private String msaType;

	@Column(name="NEW_CNTRCT_TYPES")
	private String newCntrctTypes;

	@Column(name="NIA_ELGBLTY")
	private String niaElgblty;

	@Column(name="OLD_AAR_IND")
	private String oldAarInd;

	@Column(name="OLD_AGE_PTR")
	private String oldAgePtr;

	@Column(name="OLD_EAR_IND")
	private String oldEarInd;

	@Column(name="OVRG_DPNDNT_CNTNUTN_CD")
	private String ovrgDpndntCntnutnCd;

	@Column(name="OVRG_SPOUS_CNTNUTN_CD")
	private String ovrgSpousCntnutnCd;

	@Column(name="PAY_BRKR_IND")
	private String payBrkrInd;

	@Column(name="PHONE_NBR")
	private BigDecimal phoneNbr;

	@Column(name="PHONE_NBR_AREA_CD")
	private BigDecimal phoneNbrAreaCd;

	@Column(name="PHRMCY_IND")
	private String phrmcyInd;

	@Column(name="PLAN_YEAR_CNTNUTN_IND")
	private String planYearCntnutnInd;

	@Column(name="PLCY_DDCTBL_AMT")
	private String plcyDdctblAmt;

	@Column(name="PLCY_FORM_NBR")
	private String plcyFormNbr;

	@Column(name="PRCS_FNCL_DB_CD")
	private String prcsFnclDbCd;

	@Column(name="PREXST_MOS")
	private String prexstMos;

	@Column(name="PROD_DESC")
	private String prodDesc;

	@Column(name="PROD_DESC_SHRT")
	private String prodDescShrt;

	@Column(name="PROD_SUB_TYPE_1")
	private String prodSubType1;

	@Column(name="PROD_SUB_TYPE_2")
	private String prodSubType2;

	@Column(name="PROD_TYPE")
	private String prodType;

	@Column(name="PROV_CD")
	private String provCd;

	@Column(name="PROV_DIR_CD")
	private String provDirCd;

	@Column(name="RDR_TYPE")
	private String rdrType;

	@Column(name="RPT_BRK_CD")
	private String rptBrkCd;

	@Column(name="SHRT_TERM_PLCY_IND")
	private String shrtTermPlcyInd;

	@Column(name="ST_CD")
	private String stCd;

	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name="WVR_IND")
	private String wvrInd;

	public ProdCnfgrn() {
	}

	public long getProdCnfgrnId() {
		return this.prodCnfgrnId;
	}

	public void setProdCnfgrnId(long prodCnfgrnId) {
		this.prodCnfgrnId = prodCnfgrnId;
	}

	public String getActrlProdCd() {
		return this.actrlProdCd;
	}

	public void setActrlProdCd(String actrlProdCd) {
		this.actrlProdCd = actrlProdCd;
	}

	public String getAdrsPtr() {
		return this.adrsPtr;
	}

	public void setAdrsPtr(String adrsPtr) {
		this.adrsPtr = adrsPtr;
	}

	public String getAgePtr() {
		return this.agePtr;
	}

	public void setAgePtr(String agePtr) {
		this.agePtr = agePtr;
	}

	public String getAttAgeRatgInd() {
		return this.attAgeRatgInd;
	}

	public void setAttAgeRatgInd(String attAgeRatgInd) {
		this.attAgeRatgInd = attAgeRatgInd;
	}

	public String getBcaPrfx() {
		return this.bcaPrfx;
	}

	public void setBcaPrfx(String bcaPrfx) {
		this.bcaPrfx = bcaPrfx;
	}

	public String getBsicProdCdSplmntl() {
		return this.bsicProdCdSplmntl;
	}

	public void setBsicProdCdSplmntl(String bsicProdCdSplmntl) {
		this.bsicProdCdSplmntl = bsicProdCdSplmntl;
	}

	public String getBsnsCd() {
		return this.bsnsCd;
	}

	public void setBsnsCd(String bsnsCd) {
		this.bsnsCd = bsnsCd;
	}

	public String getBsnsCdExt() {
		return this.bsnsCdExt;
	}

	public void setBsnsCdExt(String bsnsCdExt) {
		this.bsnsCdExt = bsnsCdExt;
	}

	public String getCdhInd() {
		return this.cdhInd;
	}

	public void setCdhInd(String cdhInd) {
		this.cdhInd = cdhInd;
	}

	public String getCmbndIdCardInd() {
		return this.cmbndIdCardInd;
	}

	public void setCmbndIdCardInd(String cmbndIdCardInd) {
		this.cmbndIdCardInd = cmbndIdCardInd;
	}

	public String getCmpnyCd() {
		return this.cmpnyCd;
	}

	public void setCmpnyCd(String cmpnyCd) {
		this.cmpnyCd = cmpnyCd;
	}

	public String getCnsmrChceInd() {
		return this.cnsmrChceInd;
	}

	public void setCnsmrChceInd(String cnsmrChceInd) {
		this.cnsmrChceInd = cnsmrChceInd;
	}

	public String getCntnutnCdSortInd() {
		return this.cntnutnCdSortInd;
	}

	public void setCntnutnCdSortInd(String cntnutnCdSortInd) {
		this.cntnutnCdSortInd = cntnutnCdSortInd;
	}

	public String getCntrctCd() {
		return this.cntrctCd;
	}

	public void setCntrctCd(String cntrctCd) {
		this.cntrctCd = cntrctCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getEntryAgeRtInd() {
		return this.entryAgeRtInd;
	}

	public void setEntryAgeRtInd(String entryAgeRtInd) {
		this.entryAgeRtInd = entryAgeRtInd;
	}

	public String getExchngInd() {
		return this.exchngInd;
	}

	public void setExchngInd(String exchngInd) {
		this.exchngInd = exchngInd;
	}

	public String getFlngType() {
		return this.flngType;
	}

	public void setFlngType(String flngType) {
		this.flngType = flngType;
	}

	public String getFrcTo2MnthBil() {
		return this.frcTo2MnthBil;
	}

	public void setFrcTo2MnthBil(String frcTo2MnthBil) {
		this.frcTo2MnthBil = frcTo2MnthBil;
	}

	public BigDecimal getFrzDt() {
		return this.frzDt;
	}

	public void setFrzDt(BigDecimal frzDt) {
		this.frzDt = frzDt;
	}

	public String getHcrInd() {
		return this.hcrInd;
	}

	public void setHcrInd(String hcrInd) {
		this.hcrInd = hcrInd;
	}

	public String getHospOnlyInd() {
		return this.hospOnlyInd;
	}

	public void setHospOnlyInd(String hospOnlyInd) {
		this.hospOnlyInd = hospOnlyInd;
	}

	public String getHsaProdInd() {
		return this.hsaProdInd;
	}

	public void setHsaProdInd(String hsaProdInd) {
		this.hsaProdInd = hsaProdInd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Timestamp getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Timestamp lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLifeVol() {
		return this.lifeVol;
	}

	public void setLifeVol(String lifeVol) {
		this.lifeVol = lifeVol;
	}

	public String getMbu() {
		return this.mbu;
	}

	public void setMbu(String mbu) {
		this.mbu = mbu;
	}

	public String getMhpIndForH2Grp() {
		return this.mhpIndForH2Grp;
	}

	public void setMhpIndForH2Grp(String mhpIndForH2Grp) {
		this.mhpIndForH2Grp = mhpIndForH2Grp;
	}

	public String getMisc1() {
		return this.misc1;
	}

	public void setMisc1(String misc1) {
		this.misc1 = misc1;
	}

	public String getMisc2() {
		return this.misc2;
	}

	public void setMisc2(String misc2) {
		this.misc2 = misc2;
	}

	public String getMisc3() {
		return this.misc3;
	}

	public void setMisc3(String misc3) {
		this.misc3 = misc3;
	}

	public String getMisc4() {
		return this.misc4;
	}

	public void setMisc4(String misc4) {
		this.misc4 = misc4;
	}

	public String getMsaType() {
		return this.msaType;
	}

	public void setMsaType(String msaType) {
		this.msaType = msaType;
	}

	public String getNewCntrctTypes() {
		return this.newCntrctTypes;
	}

	public void setNewCntrctTypes(String newCntrctTypes) {
		this.newCntrctTypes = newCntrctTypes;
	}

	public String getNiaElgblty() {
		return this.niaElgblty;
	}

	public void setNiaElgblty(String niaElgblty) {
		this.niaElgblty = niaElgblty;
	}

	public String getOldAarInd() {
		return this.oldAarInd;
	}

	public void setOldAarInd(String oldAarInd) {
		this.oldAarInd = oldAarInd;
	}

	public String getOldAgePtr() {
		return this.oldAgePtr;
	}

	public void setOldAgePtr(String oldAgePtr) {
		this.oldAgePtr = oldAgePtr;
	}

	public String getOldEarInd() {
		return this.oldEarInd;
	}

	public void setOldEarInd(String oldEarInd) {
		this.oldEarInd = oldEarInd;
	}

	public String getOvrgDpndntCntnutnCd() {
		return this.ovrgDpndntCntnutnCd;
	}

	public void setOvrgDpndntCntnutnCd(String ovrgDpndntCntnutnCd) {
		this.ovrgDpndntCntnutnCd = ovrgDpndntCntnutnCd;
	}

	public String getOvrgSpousCntnutnCd() {
		return this.ovrgSpousCntnutnCd;
	}

	public void setOvrgSpousCntnutnCd(String ovrgSpousCntnutnCd) {
		this.ovrgSpousCntnutnCd = ovrgSpousCntnutnCd;
	}

	public String getPayBrkrInd() {
		return this.payBrkrInd;
	}

	public void setPayBrkrInd(String payBrkrInd) {
		this.payBrkrInd = payBrkrInd;
	}

	public BigDecimal getPhoneNbr() {
		return this.phoneNbr;
	}

	public void setPhoneNbr(BigDecimal phoneNbr) {
		this.phoneNbr = phoneNbr;
	}

	public BigDecimal getPhoneNbrAreaCd() {
		return this.phoneNbrAreaCd;
	}

	public void setPhoneNbrAreaCd(BigDecimal phoneNbrAreaCd) {
		this.phoneNbrAreaCd = phoneNbrAreaCd;
	}

	public String getPhrmcyInd() {
		return this.phrmcyInd;
	}

	public void setPhrmcyInd(String phrmcyInd) {
		this.phrmcyInd = phrmcyInd;
	}

	public String getPlanYearCntnutnInd() {
		return this.planYearCntnutnInd;
	}

	public void setPlanYearCntnutnInd(String planYearCntnutnInd) {
		this.planYearCntnutnInd = planYearCntnutnInd;
	}

	public String getPlcyDdctblAmt() {
		return this.plcyDdctblAmt;
	}

	public void setPlcyDdctblAmt(String plcyDdctblAmt) {
		this.plcyDdctblAmt = plcyDdctblAmt;
	}

	public String getPlcyFormNbr() {
		return this.plcyFormNbr;
	}

	public void setPlcyFormNbr(String plcyFormNbr) {
		this.plcyFormNbr = plcyFormNbr;
	}

	public String getPrcsFnclDbCd() {
		return this.prcsFnclDbCd;
	}

	public void setPrcsFnclDbCd(String prcsFnclDbCd) {
		this.prcsFnclDbCd = prcsFnclDbCd;
	}

	public String getPrexstMos() {
		return this.prexstMos;
	}

	public void setPrexstMos(String prexstMos) {
		this.prexstMos = prexstMos;
	}

	public String getProdDesc() {
		return this.prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public String getProdDescShrt() {
		return this.prodDescShrt;
	}

	public void setProdDescShrt(String prodDescShrt) {
		this.prodDescShrt = prodDescShrt;
	}

	public String getProdSubType1() {
		return this.prodSubType1;
	}

	public void setProdSubType1(String prodSubType1) {
		this.prodSubType1 = prodSubType1;
	}

	public String getProdSubType2() {
		return this.prodSubType2;
	}

	public void setProdSubType2(String prodSubType2) {
		this.prodSubType2 = prodSubType2;
	}

	public String getProdType() {
		return this.prodType;
	}

	public void setProdType(String prodType) {
		this.prodType = prodType;
	}

	public String getProvCd() {
		return this.provCd;
	}

	public void setProvCd(String provCd) {
		this.provCd = provCd;
	}

	public String getProvDirCd() {
		return this.provDirCd;
	}

	public void setProvDirCd(String provDirCd) {
		this.provDirCd = provDirCd;
	}

	public String getRdrType() {
		return this.rdrType;
	}

	public void setRdrType(String rdrType) {
		this.rdrType = rdrType;
	}

	public String getRptBrkCd() {
		return this.rptBrkCd;
	}

	public void setRptBrkCd(String rptBrkCd) {
		this.rptBrkCd = rptBrkCd;
	}

	public String getShrtTermPlcyInd() {
		return this.shrtTermPlcyInd;
	}

	public void setShrtTermPlcyInd(String shrtTermPlcyInd) {
		this.shrtTermPlcyInd = shrtTermPlcyInd;
	}

	public String getStCd() {
		return this.stCd;
	}

	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getWvrInd() {
		return this.wvrInd;
	}

	public void setWvrInd(String wvrInd) {
		this.wvrInd = wvrInd;
	}

}