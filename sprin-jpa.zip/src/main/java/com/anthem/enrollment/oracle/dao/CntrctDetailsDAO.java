package com.anthem.enrollment.oracle.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.anthem.enrollment.domain.CntrctPlanProvNtwk;
import com.anthem.enrollment.oracle.domain.AdrsDetails;
import com.anthem.enrollment.oracle.domain.BillgEntyDetails;
import com.anthem.enrollment.oracle.domain.CntrctAdrsDetails;
import com.anthem.enrollment.oracle.domain.CntrctBillgEntyDetails;
import com.anthem.enrollment.oracle.domain.CntrctDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanProvNtwkDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtDtlDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtSmryDetails;
import com.anthem.enrollment.oracle.domain.CntrctTlphnDetails;
import com.anthem.enrollment.oracle.domain.GrpCntrctPrvsnDetails;
import com.anthem.enrollment.oracle.domain.GrpHcDetails;
import com.anthem.enrollment.oracle.domain.GrpMnthlyCntrbtnDetails;
import com.anthem.enrollment.oracle.domain.GrpPrbtnPrdDetails;



public interface CntrctDetailsDAO extends JpaRepository<CntrctDetails, Long> {

	/*@Query(value="SELECT *  from CNTRCT  where grp_id=:grpId",nativeQuery=true)
	List<CntrctDetails> getCntrctDetails(@Param("grpId")Long grpId);*/
	
	
	
	//@Query(value="SELECT c  from CntrctDetails c where  c.grpId=:grpId")
	/*@Query(value="SELECT c  from CntrctDetails c ")
	List<CntrctDetails> getCntrctDetails(@Param("grpId")Long grpId,Pageable pageable);*/
	
	@Query(value="SELECT c  from CntrctDetails c where  c.grpId=:grpId")
	List<CntrctDetails> getCntrctDetails(@Param("grpId")Long grpId);
	
	@Query(value="SELECT cp  from CntrctPlanDetails cp,CntrctDetails c where c.cntrctId=cp.cntrctId and  c.grpId=:grpId")
	List<CntrctPlanDetails> getCntrctPlanDetails(@Param("grpId")Long grpId);
	@Query(value="SELECT ca  from CntrctAdrsDetails ca,CntrctDetails c where c.cntrctId=ca.cntrctId and  c.grpId=:grpId")
	List<CntrctAdrsDetails> getCntrctAdrsDetails(@Param("grpId")Long grpId);
	
	@Query(value="SELECT cb  from CntrctBillgEntyDetails cb,CntrctDetails c where c.cntrctId=cb.cntrctId and  c.grpId=:grpId")
	List<CntrctBillgEntyDetails>getCntrctBillgEntityDetails(@Param("grpId")Long grpId);//need to check
	
	@Query(value="SELECT a  from AdrsDetails a,CntrctDetails c,CntrctAdrsDetails ca where c.cntrctId=ca.cntrctId and ca.adrsId=a.adrsId and  c.grpId=:grpId")
	List<AdrsDetails>getAdrsDetails(@Param("grpId")Long grpId);
	
	@Query(value="SELECT ct  from CntrctTlphnDetails ct,CntrctDetails c where c.cntrctId=ct.cntrctId and  c.grpId=:grpId")
	List<CntrctTlphnDetails>getCntrctTlphnDetails(@Param("grpId")Long grpId);
	
	@Query(value="SELECT provN  from CntrctPlanProvNtwkDetails provN ,CntrctDetails c where c.cntrctId=provN.cntrctId and  c.grpId=:grpId")
	List<CntrctPlanProvNtwkDetails>getCntrctPlanProvNtwkDetails(@Param("grpId")Long grpId);
	@Query(value="SELECT prvsn  from GrpCntrctPrvsnDetails prvsn where   prvsn.grpId=:grpId")
	List<GrpCntrctPrvsnDetails>getGrpCntrctPrvsnDetails(@Param("grpId")Long grpId);
	@Query(value="SELECT hc  from GrpHcDetails hc where   hc.grpId=:grpId")
	List<GrpHcDetails>getGrpHCDetails(@Param("grpId")Long grpId);
	@Query(value="SELECT mc  from GrpMnthlyCntrbtnDetails mc where   mc.grpId=:grpId")
	List<GrpMnthlyCntrbtnDetails>getGrpMnthlyCntrbtnDetails(@Param("grpId")Long grpId);
	@Query(value="select rt from CntrctPlanRtDetails rt where rtTrmntnDt IS NULL and rt.cntrctPlanId IN(select cp.cntrctPlanId from CntrctPlanDetails cp where cp.cvrgTypeCd=:cvrgTypCd and cp.cntrctId in(select c.cntrctId from CntrctDetails c where c.grpId in(:grpId)))")
	List<CntrctPlanRtDetails>getCntrctPlanRtDetails(@Param("grpId")Long grpId,@Param("cvrgTypCd")String cvrgTypCd);
	@Query(value="select smry from CntrctPlanRtSmryDetails smry where smry.cntrctPlanRtId IN(select rt.cntrctPlanRtId from CntrctPlanRtDetails rt where rtTrmntnDt IS NULL and rt.cntrctPlanId IN(select cp.cntrctPlanId from CntrctPlanDetails cp where cp.cvrgTypeCd=:cvrgTypCd and cp.cntrctId in(select c.cntrctId from CntrctDetails c where c.grpId in(:grpId))))")
	List<CntrctPlanRtSmryDetails>getCntrctPlanRtSmryDetails(@Param("grpId")Long grpId,@Param("cvrgTypCd")String cvrgTypCd);
	@Query(value="select dtl from CntrctPlanRtDtlDetails dtl where dtl.cntrctPlanRtSmryId IN(select smry.cntrctPlanRtSmryId from CntrctPlanRtSmryDetails smry where smry.cntrctPlanRtId IN(select rt.cntrctPlanRtId from CntrctPlanRtDetails rt where rtTrmntnDt IS NULL and rt.cntrctPlanId IN(select cp.cntrctPlanId from CntrctPlanDetails cp where cp.cvrgTypeCd=:cvrgTypCd and cp.cntrctId in(select c.cntrctId from CntrctDetails c where c.grpId in(:grpId)))))")
	List<CntrctPlanRtDtlDetails>getCntrctPlanRtDtlDetails(@Param("grpId")Long grpId,@Param("cvrgTypCd")String cvrgTypCd);
	
	//@Query(value="SELECT pp  from GrpPrbtnPrdDetails pp where pp.grpId=:grpId and pp.cvrgTypeCd:cvrgTypCd")
	//List<GrpPrbtnPrdDetails>getGrpPrbtnPrdDetails(@Param("grpId")Long grpId,@Param("cvrgTypCd")String cvrgTypCd);
	@Query(value="SELECT be  from BillgEntyDetails be where be.billgEntyId IN(Select cb.billgEntyId from CntrctBillgEntyDetails cb ,CntrctDetails c where c.cntrctId=cb.cntrctId and  c.grpId=:grpId)")
	List<BillgEntyDetails>getbillgEntyDetails(@Param("grpId")Long grpId);
}