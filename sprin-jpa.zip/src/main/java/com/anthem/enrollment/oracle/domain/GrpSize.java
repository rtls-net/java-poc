package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the GRP_SIZE database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_SIZE")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpSize implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_SIZE_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private long grpSizeId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="CVRG_TYPE_CD")
	private String cvrgTypeCd;

	@Column(name="GRP_SIZE_NBR")
	private BigDecimal grpSizeNbr;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	@Column(name="GRP_SIZE_CTGRY_CD")
	private String grpSizeCtgryCd;

	public GrpSize() {
	}

	public long getGrpSizeId() {
		return this.grpSizeId;
	}

	public void setGrpSizeId(long grpSizeId) {
		this.grpSizeId = grpSizeId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgTypeCd() {
		return this.cvrgTypeCd;
	}

	public void setCvrgTypeCd(String cvrgTypeCd) {
		this.cvrgTypeCd = cvrgTypeCd;
	}

	public BigDecimal getGrpSizeNbr() {
		return this.grpSizeNbr;
	}

	public void setGrpSizeNbr(BigDecimal grpSizeNbr) {
		this.grpSizeNbr = grpSizeNbr;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public String getGrpSizeCtgryCd() {
		return grpSizeCtgryCd;
	}

	public void setGrpSizeCtgryCd(String grpSizeCtgryCd) {
		this.grpSizeCtgryCd = grpSizeCtgryCd;
	}
}