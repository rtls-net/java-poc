package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the GRP_CNTRCT_PRVSN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "GRP_CNTRCT_PRVSN")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class GrpCntrctPrvsnDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "GRP_CNTRCT_PRVSN_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private long grpCntrctPrvsnId;

	@Column(name = "ADD_NEW_HIRES_CD")
	private String addNewHiresCd;

	@Column(name = "CARR_REPLCD_CD")
	private String carrReplcdCd;

	@Column(name = "CLMS_PRCS_TYPE_CD")
	private String clmsPrcsTypeCd;

	@Column(name = "CNTRCT_CO_CARR_IND_CD")
	private String cntrctCoCarrIndCd;

	@Column(name = "CNTRCT_PLAN_CD")
	private String cntrctPlanCd;

//	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_PRVSN_EFCTV_DT")
	private Date cntrctPrvsnEfctvDt;

//	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_PRVSN_TRMNTN_DT")
	private Date cntrctPrvsnTrmntnDt;

	@Column(name = "CNVRSN_OFFER_CD")
	private String cnvrsnOfferCd;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "CVRG_IND_CD")
	private String cvrgIndCd;

	@Column(name = "DLAY_LTR_CD")
	private String dlayLtrCd;

	@Column(name = "DNTL_CLM_PRCSG_SYS_CD")
	private String dntlClmPrcsgSysCd;

	@Column(name = "DUP_CVRG_CD")
	private String dupCvrgCd;

	@Column(name = "ELCTRNC_EXPLNTN_COPY")
	private String elctrncExplntnCopy;

	@Column(name = "EMP_EXCLD_CD")
	private String empExcldCd;

	@Column(name = "GRP_ATSTN_IND_CD")
	private String grpAtstnIndCd;

	@Column(name = "GRP_TAPE_ENRLMNT_CD")
	private String grpTapeEnrlmntCd;

//	@Temporal(TemporalType.DATE)
	@Column(name = "GRP_TAPE_LAST_PRCSG_DT")
	private Date grpTapeLastPrcsgDt;

	@Column(name = "HIPAA_LTR_CD")
	private String hipaaLtrCd;

	@Column(name = "HLTH_CNTRL_PLAN_NBR")
	private BigDecimal hlthCntrlPlanNbr;

//	@Temporal(TemporalType.DATE)
	@Column(name = "HOSP_CNCLN_EFCTV_DT")
	private Date hospCnclnEfctvDt;

//	@Temporal(TemporalType.DATE)
	@Column(name = "HOSP_EFCTV_DT")
	private Date hospEfctvDt;

	@Column(name = "INIT_WRKRS_CMPNSTN_CD")
	private String initWrkrsCmpnstnCd;

//	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_CNTRCT_ANIV_DT")
	private Date lastCntrctAnivDt;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "LGCY_DNTL_CLM_PRCSG_SYS_CD")
	private String lgcyDntlClmPrcsgSysCd;

	@Column(name = "ONLN_DATES_NBR")
	private BigDecimal onlnDatesNbr;

	@Column(name = "OPEN_ENRLMNT_MNTH")
	private BigDecimal openEnrlmntMnth;

	@Column(name = "OVER_65_CD")
	private String over65Cd;

	@Column(name = "OVER_AGE_MAILG_CD")
	private String overAgeMailgCd;

	@Column(name = "PAYRL_LCTN_CD")
	private String payrlLctnCd;

	@Column(name = "PRBTN_PRD_CD")
	private String prbtnPrdCd;

//	@Temporal(TemporalType.DATE)
	@Column(name = "PRFSNL_CNCLN_EFCTV_DT")
	private Date prfsnlCnclnEfctvDt;

//	@Temporal(TemporalType.DATE)
	@Column(name = "PRFSNL_EFCTV_DT")
	private Date prfsnlEfctvDt;

	@Column(name = "PRODN_TYPE_CNTRL_CD")
	private String prodnTypeCntrlCd;

	@Column(name = "PROV_CARE_CD")
	private String provCareCd;

	@Column(name = "RDR_OPTNL_BNFTS_CD")
	private String rdrOptnlBnftsCd;

	@Column(name = "REINST_PRCS_DTM")
	private Date reinstPrcsDtm;

//	@Temporal(TemporalType.DATE)
	@Column(name = "RNWL_DT")
	private Date rnwlDt;

	@Column(name = "RRT_MNTH_NBR")
	private BigDecimal rrtMnthNbr;

	@Column(name = "SFTY_NET_PROV_PRFRNC_CD")
	private String sftyNetProvPrfrncCd;

	@Column(name = "SSPNSN_GRAC_CD")
	private String sspnsnGracCd;

	@Column(name = "SSPNSN_GRAC_DAYS_NBR")
	private BigDecimal sspnsnGracDaysNbr;

//	@Temporal(TemporalType.DATE)
	@Column(name = "STOK_SBSDY_DT")
	private Date stokSbsdyDt;

	@Column(name = "TRMNTD_OVRG_DPNDNT_CD")
	private String trmntdOvrgDpndntCd;

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	// bi-directional many-to-one association to Grp
	/*@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GRP_ID")
	private Grp grp;

	// bi-directional many-to-one association to Cntrct
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_ID")
	private Cntrct cntrct;*/
	
	@Column(name = "GRP_ID")
	private Long grpId;
	@Column(name = "CNTRCT_ID")
	private Long cntrctId;
	
	@Column(name = "RETROA_DAYS_ONLN_NBR")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long retroaDaysOnlnNbr;
	
	@Column(name = "RETROA_DAYS_GL_NBR")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long retroaDaysGlNbr ;
	
	@Column(name = "RETROA_DAYS_IND")
	private String retroaDaysInd;
	
	@Column(name = "EAP_CD")
	private String eapCd;
	
	@Column(name = "SIC_CD")
	private String sicCode;
	
	@Column(name = "VNDR_RFRL_CD")
	private String vendorReferral ;
	
	@Column(name = "OVER_AGE_DEPENDENT_CD")
	private String overAgeDependentCd;
	
	@Column(name = "DELETE_DEPENDENT_CD")
	private String deleteDependentCd;
	
	@Column(name = "OAD_AUTO_DEL_CD")
	private String oadAutoDelCd ;
	
	@Column(name = "ADMIN_NAME")
	private String adminName;
	
	@Column(name = "CONTRACT_NAME")
	private String contractName;
	
	@Column(name = "DMSTC_PRTNR_IND_CD")
	private String dmstcPrtNrIndCd;
	
	@Column(name = "GRP_HC_INIT_DSTRBTN_CD")
	private String initDstrbtnCd;
	
	@Column(name = "GRP_HC_ONGOG_DSTRBTN_CD")
	private String ongngDstrbtnCd;
	
	@Column(name = "DENTAL_NET_SWITCH_CD")
	private String dentalNetSwitchCd;
	
	@Column(name = "EMBEDDED_SWITCH_CD")
	private String embeddedSwitchCd;
	
	@Column(name = "MEDCARE_PRICE_CD")
	private String medcarePriceCd;
	
	
	public String getMedcarePriceCd() {
		return medcarePriceCd;
	}

	public void setMedcarePriceCd(String medcarePriceCd) {
		this.medcarePriceCd = medcarePriceCd;
	}

	

	public long getGrpCntrctPrvsnId() {
		return this.grpCntrctPrvsnId;
	}

	public void setGrpCntrctPrvsnId(long grpCntrctPrvsnId) {
		this.grpCntrctPrvsnId = grpCntrctPrvsnId;
	}

	public String getAddNewHiresCd() {
		return this.addNewHiresCd;
	}

	public void setAddNewHiresCd(String addNewHiresCd) {
		this.addNewHiresCd = addNewHiresCd;
	}

	public String getCarrReplcdCd() {
		return this.carrReplcdCd;
	}

	public void setCarrReplcdCd(String carrReplcdCd) {
		this.carrReplcdCd = carrReplcdCd;
	}

	public String getClmsPrcsTypeCd() {
		return this.clmsPrcsTypeCd;
	}

	public void setClmsPrcsTypeCd(String clmsPrcsTypeCd) {
		this.clmsPrcsTypeCd = clmsPrcsTypeCd;
	}

	public String getCntrctCoCarrIndCd() {
		return this.cntrctCoCarrIndCd;
	}

	public void setCntrctCoCarrIndCd(String cntrctCoCarrIndCd) {
		this.cntrctCoCarrIndCd = cntrctCoCarrIndCd;
	}

	public String getCntrctPlanCd() {
		return this.cntrctPlanCd;
	}

	public void setCntrctPlanCd(String cntrctPlanCd) {
		this.cntrctPlanCd = cntrctPlanCd;
	}

	public Date getCntrctPrvsnEfctvDt() {
		return this.cntrctPrvsnEfctvDt;
	}

	public void setCntrctPrvsnEfctvDt(Date cntrctPrvsnEfctvDt) {
		this.cntrctPrvsnEfctvDt = cntrctPrvsnEfctvDt;
	}

	public Date getCntrctPrvsnTrmntnDt() {
		return this.cntrctPrvsnTrmntnDt;
	}

	public void setCntrctPrvsnTrmntnDt(Date cntrctPrvsnTrmntnDt) {
		this.cntrctPrvsnTrmntnDt = cntrctPrvsnTrmntnDt;
	}

	public String getCnvrsnOfferCd() {
		return this.cnvrsnOfferCd;
	}

	public void setCnvrsnOfferCd(String cnvrsnOfferCd) {
		this.cnvrsnOfferCd = cnvrsnOfferCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgIndCd() {
		return this.cvrgIndCd;
	}

	public void setCvrgIndCd(String cvrgIndCd) {
		this.cvrgIndCd = cvrgIndCd;
	}

	public String getDlayLtrCd() {
		return this.dlayLtrCd;
	}

	public void setDlayLtrCd(String dlayLtrCd) {
		this.dlayLtrCd = dlayLtrCd;
	}

	public String getDntlClmPrcsgSysCd() {
		return this.dntlClmPrcsgSysCd;
	}

	public void setDntlClmPrcsgSysCd(String dntlClmPrcsgSysCd) {
		this.dntlClmPrcsgSysCd = dntlClmPrcsgSysCd;
	}

	public String getDupCvrgCd() {
		return this.dupCvrgCd;
	}

	public void setDupCvrgCd(String dupCvrgCd) {
		this.dupCvrgCd = dupCvrgCd;
	}

	public String getElctrncExplntnCopy() {
		return this.elctrncExplntnCopy;
	}

	public void setElctrncExplntnCopy(String elctrncExplntnCopy) {
		this.elctrncExplntnCopy = elctrncExplntnCopy;
	}

	public String getEmpExcldCd() {
		return this.empExcldCd;
	}

	public void setEmpExcldCd(String empExcldCd) {
		this.empExcldCd = empExcldCd;
	}

	public String getGrpAtstnIndCd() {
		return this.grpAtstnIndCd;
	}

	public void setGrpAtstnIndCd(String grpAtstnIndCd) {
		this.grpAtstnIndCd = grpAtstnIndCd;
	}

	public String getGrpTapeEnrlmntCd() {
		return this.grpTapeEnrlmntCd;
	}

	public void setGrpTapeEnrlmntCd(String grpTapeEnrlmntCd) {
		this.grpTapeEnrlmntCd = grpTapeEnrlmntCd;
	}

	public Date getGrpTapeLastPrcsgDt() {
		return this.grpTapeLastPrcsgDt;
	}

	public void setGrpTapeLastPrcsgDt(Date grpTapeLastPrcsgDt) {
		this.grpTapeLastPrcsgDt = grpTapeLastPrcsgDt;
	}

	public String getHipaaLtrCd() {
		return this.hipaaLtrCd;
	}

	public void setHipaaLtrCd(String hipaaLtrCd) {
		this.hipaaLtrCd = hipaaLtrCd;
	}

	public BigDecimal getHlthCntrlPlanNbr() {
		return this.hlthCntrlPlanNbr;
	}

	public void setHlthCntrlPlanNbr(BigDecimal hlthCntrlPlanNbr) {
		this.hlthCntrlPlanNbr = hlthCntrlPlanNbr;
	}

	public Date getHospCnclnEfctvDt() {
		return this.hospCnclnEfctvDt;
	}

	public void setHospCnclnEfctvDt(Date hospCnclnEfctvDt) {
		this.hospCnclnEfctvDt = hospCnclnEfctvDt;
	}

	public Date getHospEfctvDt() {
		return this.hospEfctvDt;
	}

	public void setHospEfctvDt(Date hospEfctvDt) {
		this.hospEfctvDt = hospEfctvDt;
	}

	public String getInitWrkrsCmpnstnCd() {
		return this.initWrkrsCmpnstnCd;
	}

	public void setInitWrkrsCmpnstnCd(String initWrkrsCmpnstnCd) {
		this.initWrkrsCmpnstnCd = initWrkrsCmpnstnCd;
	}

	public Date getLastCntrctAnivDt() {
		return this.lastCntrctAnivDt;
	}

	public void setLastCntrctAnivDt(Date lastCntrctAnivDt) {
		this.lastCntrctAnivDt = lastCntrctAnivDt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLgcyDntlClmPrcsgSysCd() {
		return this.lgcyDntlClmPrcsgSysCd;
	}

	public void setLgcyDntlClmPrcsgSysCd(String lgcyDntlClmPrcsgSysCd) {
		this.lgcyDntlClmPrcsgSysCd = lgcyDntlClmPrcsgSysCd;
	}

	public BigDecimal getOnlnDatesNbr() {
		return this.onlnDatesNbr;
	}

	public void setOnlnDatesNbr(BigDecimal onlnDatesNbr) {
		this.onlnDatesNbr = onlnDatesNbr;
	}

	public BigDecimal getOpenEnrlmntMnth() {
		return this.openEnrlmntMnth;
	}

	public void setOpenEnrlmntMnth(BigDecimal openEnrlmntMnth) {
		this.openEnrlmntMnth = openEnrlmntMnth;
	}

	public String getOver65Cd() {
		return this.over65Cd;
	}

	public void setOver65Cd(String over65Cd) {
		this.over65Cd = over65Cd;
	}

	public String getOverAgeMailgCd() {
		return this.overAgeMailgCd;
	}

	public void setOverAgeMailgCd(String overAgeMailgCd) {
		this.overAgeMailgCd = overAgeMailgCd;
	}

	public String getPayrlLctnCd() {
		return this.payrlLctnCd;
	}

	public void setPayrlLctnCd(String payrlLctnCd) {
		this.payrlLctnCd = payrlLctnCd;
	}

	public String getPrbtnPrdCd() {
		return this.prbtnPrdCd;
	}

	public void setPrbtnPrdCd(String prbtnPrdCd) {
		this.prbtnPrdCd = prbtnPrdCd;
	}

	public Date getPrfsnlCnclnEfctvDt() {
		return this.prfsnlCnclnEfctvDt;
	}

	public void setPrfsnlCnclnEfctvDt(Date prfsnlCnclnEfctvDt) {
		this.prfsnlCnclnEfctvDt = prfsnlCnclnEfctvDt;
	}

	public Date getPrfsnlEfctvDt() {
		return this.prfsnlEfctvDt;
	}

	public void setPrfsnlEfctvDt(Date prfsnlEfctvDt) {
		this.prfsnlEfctvDt = prfsnlEfctvDt;
	}

	public String getProdnTypeCntrlCd() {
		return this.prodnTypeCntrlCd;
	}

	public void setProdnTypeCntrlCd(String prodnTypeCntrlCd) {
		this.prodnTypeCntrlCd = prodnTypeCntrlCd;
	}

	public String getProvCareCd() {
		return this.provCareCd;
	}

	public void setProvCareCd(String provCareCd) {
		this.provCareCd = provCareCd;
	}

	public String getRdrOptnlBnftsCd() {
		return this.rdrOptnlBnftsCd;
	}

	public void setRdrOptnlBnftsCd(String rdrOptnlBnftsCd) {
		this.rdrOptnlBnftsCd = rdrOptnlBnftsCd;
	}

	public Date getReinstPrcsDtm() {
		return this.reinstPrcsDtm;
	}

	public void setReinstPrcsDtm(Date reinstPrcsDtm) {
		this.reinstPrcsDtm = reinstPrcsDtm;
	}

	public Date getRnwlDt() {
		return this.rnwlDt;
	}

	public void setRnwlDt(Date rnwlDt) {
		this.rnwlDt = rnwlDt;
	}

	public BigDecimal getRrtMnthNbr() {
		return this.rrtMnthNbr;
	}

	public void setRrtMnthNbr(BigDecimal rrtMnthNbr) {
		this.rrtMnthNbr = rrtMnthNbr;
	}

	public String getSftyNetProvPrfrncCd() {
		return this.sftyNetProvPrfrncCd;
	}

	public void setSftyNetProvPrfrncCd(String sftyNetProvPrfrncCd) {
		this.sftyNetProvPrfrncCd = sftyNetProvPrfrncCd;
	}

	public String getSspnsnGracCd() {
		return this.sspnsnGracCd;
	}

	public void setSspnsnGracCd(String sspnsnGracCd) {
		this.sspnsnGracCd = sspnsnGracCd;
	}

	public BigDecimal getSspnsnGracDaysNbr() {
		return this.sspnsnGracDaysNbr;
	}

	public void setSspnsnGracDaysNbr(BigDecimal sspnsnGracDaysNbr) {
		this.sspnsnGracDaysNbr = sspnsnGracDaysNbr;
	}

	public Date getStokSbsdyDt() {
		return this.stokSbsdyDt;
	}

	public void setStokSbsdyDt(Date stokSbsdyDt) {
		this.stokSbsdyDt = stokSbsdyDt;
	}

	public String getTrmntdOvrgDpndntCd() {
		return this.trmntdOvrgDpndntCd;
	}

	public void setTrmntdOvrgDpndntCd(String trmntdOvrgDpndntCd) {
		this.trmntdOvrgDpndntCd = trmntdOvrgDpndntCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	/*public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public Cntrct getCntrct() {
		return this.cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}
	*/
	public String getEapCd() {
		return eapCd;
	}

	public void setEapCd(String eapCd) {
		this.eapCd = eapCd;
	}

	public String getOverAgeDependentCd() {
		return overAgeDependentCd;
	}

	public void setOverAgeDependentCd(String overAgeDependentCd) {
		this.overAgeDependentCd = overAgeDependentCd;
	}

	public String getDeleteDependentCd() {
		return deleteDependentCd;
	}

	public void setDeleteDependentCd(String deleteDependentCd) {
		this.deleteDependentCd = deleteDependentCd;
	}

	public String getOadAutoDelCd() {
		return oadAutoDelCd;
	}

	public void setOadAutoDelCd(String oadAutoDelCd) {
		this.oadAutoDelCd = oadAutoDelCd;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}
	
	public String getDmstcPrtNrIndCd() {
		return dmstcPrtNrIndCd;
	}

	public void setDmstcPrtNrIndCd(String dmstcPrtNrIndCd) {
		this.dmstcPrtNrIndCd = dmstcPrtNrIndCd;
	}

	public String getInitDstrbtnCd() {
		return initDstrbtnCd;
	}

	public void setInitDstrbtnCd(String initDstrbtnCd) {
		this.initDstrbtnCd = initDstrbtnCd;
	}

	public String getOngngDstrbtnCd() {
		return ongngDstrbtnCd;
	}

	public void setOngngDstrbtnCd(String ongngDstrbtnCd) {
		this.ongngDstrbtnCd = ongngDstrbtnCd;
	}

	public Long getRetroaDaysOnlnNbr() {
		return retroaDaysOnlnNbr;
	}

	public void setRetroaDaysOnlnNbr(Long retroaDaysOnlnNbr) {
		this.retroaDaysOnlnNbr = retroaDaysOnlnNbr;
	}

	public Long getRetroaDaysGlNbr() {
		return retroaDaysGlNbr;
	}

	public void setRetroaDaysGlNbr(Long retroaDaysGlNbr) {
		this.retroaDaysGlNbr = retroaDaysGlNbr;
	}

	public String getRetroaDaysInd() {
		return retroaDaysInd;
	}

	public void setRetroaDaysInd(String retroaDaysInd) {
		this.retroaDaysInd = retroaDaysInd;
	}

	public String getSicCode() {
		return sicCode;
	}

	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}

	public String getVendorReferral() {
		return vendorReferral;
	}

	public void setVendorReferral(String vendorReferral) {
		this.vendorReferral = vendorReferral;
	}

	public String getDentalNetSwitchCd() {
		return dentalNetSwitchCd;
	}

	public void setDentalNetSwitchCd(String dentalNetSwitchCd) {
		this.dentalNetSwitchCd = dentalNetSwitchCd;
	}

	public String getEmbeddedSwitchCd() {
		return embeddedSwitchCd;
	}

	public void setEmbeddedSwitchCd(String embeddedSwitchCd) {
		this.embeddedSwitchCd = embeddedSwitchCd;
	}
	
	

	public Long getGrpId() {
		return grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}

	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpCntrctPrvsn [grpCntrctPrvsnId=" + grpCntrctPrvsnId + ", addNewHiresCd=" + addNewHiresCd
				+ ", carrReplcdCd=" + carrReplcdCd + ", clmsPrcsTypeCd=" + clmsPrcsTypeCd + ", cntrctCoCarrIndCd="
				+ cntrctCoCarrIndCd + ", cntrctPlanCd=" + cntrctPlanCd + ", cntrctPrvsnEfctvDt=" + cntrctPrvsnEfctvDt!=null?formatter.format(cntrctPrvsnEfctvDt):null
				+ ", cntrctPrvsnTrmntnDt=" + (cntrctPrvsnTrmntnDt!=null?formatter.format(cntrctPrvsnTrmntnDt):null) + ", cnvrsnOfferCd=" + cnvrsnOfferCd + ", cvrgIndCd="
				+ cvrgIndCd + ", dlayLtrCd=" + dlayLtrCd + ", dntlClmPrcsgSysCd=" + dntlClmPrcsgSysCd + ", dupCvrgCd="
				+ dupCvrgCd + ", elctrncExplntnCopy=" + elctrncExplntnCopy + ", empExcldCd=" + empExcldCd
				+ ", grpAtstnIndCd=" + grpAtstnIndCd + ", grpTapeEnrlmntCd=" + grpTapeEnrlmntCd
				+ ", grpTapeLastPrcsgDt=" + (grpTapeLastPrcsgDt!=null?formatter.format(grpTapeLastPrcsgDt):null) + ", hipaaLtrCd=" + hipaaLtrCd + ", hlthCntrlPlanNbr="
				+ hlthCntrlPlanNbr + ", hospCnclnEfctvDt=" +(hospCnclnEfctvDt!=null?formatter.format(hospCnclnEfctvDt):null) + ", hospEfctvDt=" + (hospEfctvDt!=null?formatter.format(hospEfctvDt):null)
				+ ", initWrkrsCmpnstnCd=" + initWrkrsCmpnstnCd + ", lastCntrctAnivDt=" + (lastCntrctAnivDt!=null?formatter.format(lastCntrctAnivDt):null)
				+ ", lgcyDntlClmPrcsgSysCd=" + lgcyDntlClmPrcsgSysCd + ", onlnDatesNbr=" + onlnDatesNbr
				+ ", openEnrlmntMnth=" + openEnrlmntMnth + ", over65Cd=" + over65Cd + ", overAgeMailgCd="
				+ overAgeMailgCd + ", payrlLctnCd=" + payrlLctnCd + ", prbtnPrdCd=" + prbtnPrdCd
				+ ", prfsnlCnclnEfctvDt=" + (prfsnlCnclnEfctvDt!=null?formatter.format(prfsnlCnclnEfctvDt):null) + ", prfsnlEfctvDt=" + (prfsnlEfctvDt!=null?formatter.format(prfsnlEfctvDt):null)
				+ ", prodnTypeCntrlCd=" + prodnTypeCntrlCd + ", provCareCd=" + provCareCd + ", rdrOptnlBnftsCd="
				+ rdrOptnlBnftsCd + ", reinstPrcsDtm=" + reinstPrcsDtm + ", rnwlDt=" + rnwlDt + ", rrtMnthNbr="
				+ rrtMnthNbr + ", sftyNetProvPrfrncCd=" + sftyNetProvPrfrncCd + ", sspnsnGracCd=" + sspnsnGracCd
				+ ", sspnsnGracDaysNbr=" + sspnsnGracDaysNbr + ", stokSbsdyDt=" + stokSbsdyDt + ", trmntdOvrgDpndntCd="
				+ trmntdOvrgDpndntCd + ", vrsnNbr=" + vrsnNbr + ", retroaDaysOnlnNbr=" + retroaDaysOnlnNbr
				+ ", retroaDaysGlNbr=" + retroaDaysGlNbr + ", retroaDaysInd=" + retroaDaysInd + ", eapCd=" + eapCd
				+ ", sicCode=" + sicCode + ", vendorReferral=" + vendorReferral + ", overAgeDependentCd="
				+ overAgeDependentCd + ", deleteDependentCd=" + deleteDependentCd + ", oadAutoDelCd=" + oadAutoDelCd
				+ ", adminName=" + adminName + ", contractName=" + contractName + ", dmstcPrtNrIndCd=" + dmstcPrtNrIndCd
				+ ", initDstrbtnCd=" + initDstrbtnCd + ", ongngDstrbtnCd=" + ongngDstrbtnCd + ", dentalNetSwitchCd="
				+ dentalNetSwitchCd + ", embeddedSwitchCd=" + embeddedSwitchCd + ", medcarePriceCd=" + medcarePriceCd
				+ ", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null)
				+ "]";
	}

	
}