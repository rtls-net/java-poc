package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CNTRCT_BENEFIT database table.
 * 
 */
@Entity
@Table(name="CNTRCT_BENEFIT")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctBenefit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BENEFITS_ID")
	private Long benefitsId;

	@Column(name="ACDT_DTH_BNFT_AMT")
	private BigDecimal acdtDthBnftAmt;

	@Column(name="ACDT_DTH_BNFT_PER")
	private BigDecimal acdtDthBnftPer;

	@Column(name="CNTRCT_PLAN_ID")
	private BigDecimal cntrctPlanId;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_END_DT")
	private Date effEndDt;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_START_DT")
	private Date effStartDt;

	@Column(name="GRNT_ISU_AMT")
	private BigDecimal grntIsuAmt;

	@Column(name="GRP_EMP_VAL")
	private BigDecimal grpEmpVal;

	@Column(name="INC_VAL")
	private BigDecimal incVal;

	@Column(name="MAX_BNFT")
	private BigDecimal maxBnft;

	@Column(name="MAX_PER")
	private BigDecimal maxPer;

	@Column(name="MIN_BNFT")
	private BigDecimal minBnft;

	private BigDecimal multipliers;

	@Column(name="NEW_BRN_CVRG_AMT")
	private BigDecimal newBrnCvrgAmt;

	@Column(name="ROUND_CD")
	private BigDecimal roundCd;

	@Column(name="STATUS_CD")
	private String statusCd;

	@Column(name="VAL_TYPE")
	private String valType;

	@Column(name="VALUE_TYP_CD")
	private String valueTypCd;

	public CntrctBenefit() {
	}

	public Long getBenefitsId() {
		return this.benefitsId;
	}

	public void setBenefitsId(Long benefitsId) {
		this.benefitsId = benefitsId;
	}

	public BigDecimal getAcdtDthBnftAmt() {
		return this.acdtDthBnftAmt;
	}

	public void setAcdtDthBnftAmt(BigDecimal acdtDthBnftAmt) {
		this.acdtDthBnftAmt = acdtDthBnftAmt;
	}

	public BigDecimal getAcdtDthBnftPer() {
		return this.acdtDthBnftPer;
	}

	public void setAcdtDthBnftPer(BigDecimal acdtDthBnftPer) {
		this.acdtDthBnftPer = acdtDthBnftPer;
	}

	public BigDecimal getCntrctPlanId() {
		return this.cntrctPlanId;
	}

	public void setCntrctPlanId(BigDecimal cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}

	public Date getEffEndDt() {
		return this.effEndDt;
	}

	public void setEffEndDt(Date effEndDt) {
		this.effEndDt = effEndDt;
	}

	public Date getEffStartDt() {
		return this.effStartDt;
	}

	public void setEffStartDt(Date effStartDt) {
		this.effStartDt = effStartDt;
	}

	public BigDecimal getGrntIsuAmt() {
		return this.grntIsuAmt;
	}

	public void setGrntIsuAmt(BigDecimal grntIsuAmt) {
		this.grntIsuAmt = grntIsuAmt;
	}

	public BigDecimal getGrpEmpVal() {
		return this.grpEmpVal;
	}

	public void setGrpEmpVal(BigDecimal grpEmpVal) {
		this.grpEmpVal = grpEmpVal;
	}

	public BigDecimal getIncVal() {
		return this.incVal;
	}

	public void setIncVal(BigDecimal incVal) {
		this.incVal = incVal;
	}

	public BigDecimal getMaxBnft() {
		return this.maxBnft;
	}

	public void setMaxBnft(BigDecimal maxBnft) {
		this.maxBnft = maxBnft;
	}

	public BigDecimal getMaxPer() {
		return this.maxPer;
	}

	public void setMaxPer(BigDecimal maxPer) {
		this.maxPer = maxPer;
	}

	public BigDecimal getMinBnft() {
		return this.minBnft;
	}

	public void setMinBnft(BigDecimal minBnft) {
		this.minBnft = minBnft;
	}

	public BigDecimal getMultipliers() {
		return this.multipliers;
	}

	public void setMultipliers(BigDecimal multipliers) {
		this.multipliers = multipliers;
	}

	public BigDecimal getNewBrnCvrgAmt() {
		return this.newBrnCvrgAmt;
	}

	public void setNewBrnCvrgAmt(BigDecimal newBrnCvrgAmt) {
		this.newBrnCvrgAmt = newBrnCvrgAmt;
	}

	public BigDecimal getRoundCd() {
		return this.roundCd;
	}

	public void setRoundCd(BigDecimal roundCd) {
		this.roundCd = roundCd;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getValType() {
		return this.valType;
	}

	public void setValType(String valType) {
		this.valType = valType;
	}

	public String getValueTypCd() {
		return this.valueTypCd;
	}

	public void setValueTypCd(String valueTypCd) {
		this.valueTypCd = valueTypCd;
	}

}