package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * BrokerInfo - This class wraps all domain objects related to Broker.
 *
 * @author Deloitte
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class BrokerInfo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1651086383909071352L;

	/** The brkr. */
	private Brkr brkr;

	private Grp grp;

	private CntctPrsn agentCntctPrsn;

	private CntctPrsn parentCntctPrsn;

	/**
	 * Default constructor BrokerInfo
	 */
	public BrokerInfo(){
	}

	/**
	 * Gets the brkr.
	 *
	 * @return Brkr
	 */
	public Brkr getBrkr() {
		return brkr;
	}

	/**
	 * Sets the brkr.
	 *
	 * @param brkr the new brkr
	 */
	public void setBrkr(Brkr brkr) {
		this.brkr = brkr;
	}

	public Grp getGrp() {
		return grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public CntctPrsn getAgentCntctPrsn() {
		return agentCntctPrsn;
	}

	public void setAgentCntctPrsn(CntctPrsn agentCntctPrsn) {
		this.agentCntctPrsn = agentCntctPrsn;
	}

	public CntctPrsn getParentCntctPrsn() {
		return parentCntctPrsn;
	}

	public void setParentCntctPrsn(CntctPrsn parentCntctPrsn) {
		this.parentCntctPrsn = parentCntctPrsn;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return long
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}