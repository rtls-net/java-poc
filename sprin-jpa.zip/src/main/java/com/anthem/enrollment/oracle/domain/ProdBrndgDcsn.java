package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;


/**
 * The persistent class for the PROD_BRNDG_DCSN database table.
 * 
 */
@Entity
@Table(name="PROD_BRNDG_DCSN")
public class ProdBrndgDcsn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	/*@SequenceGenerator(name="PROD_BRNDG_DCSN_PRODBRNDGDCSNID_GENERATOR", sequenceName="PROD_BRNDG_DCSN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROD_BRNDG_DCSN_PRODBRNDGDCSNID_GENERATOR")*/
	@Column(name="PROD_BRNDG_DCSN_ID")
	private long prodBrndgDcsnId;

	@Column(name="BRNDG_DCMNT_TYPE_CD")
	private String brndgDcmntTypeCd;

	@Column(name="BRNDG_LOGO_TYPE_CD")
	private String brndgLogoTypeCd;

	@Column(name="BRNDG_TGLN_CD")
	private String brndgTglnCd;

	@Column(name="BRNDG_TGLN_OCC_NBR")
	private BigDecimal brndgTglnOccNbr;

	@Column(name="CMPNY_CD")
	private String cmpnyCd;

	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@Column(name="CREATD_DTM")
	private Timestamp creatdDtm;

	@Column(name="CVRG_OPRTN_CD")
	private String cvrgOprtnCd;

	@Column(name="CVRG_VALS_TXT")
	private String cvrgValsTxt;

	@Column(name="DCSN_OPRTN_CD")
	private String dcsnOprtnCd;

	@Column(name="EGR_OPRTN_CD")
	private String egrOprtnCd;

	@Column(name="EGR_VALS_TXT")
	private String egrValsTxt;

	@Column(name="GNRL_DEFN_OPRTN_CD")
	private String gnrlDefnOprtnCd;

	@Column(name="GNRL_DEFN_VALS_TXT")
	private String gnrlDefnValsTxt;

	@Column(name="HRCHY_CD")
	private BigDecimal hrchyCd;

	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@Column(name="LAST_UPDTD_DTM")
	private Timestamp lastUpdtdDtm;

	@Column(name="LOB_OPRTN_CD")
	private String lobOprtnCd;

	@Column(name="LOB_VALS_TXT")
	private String lobValsTxt;

	@Column(name="MBU_OPRTN_CD")
	private String mbuOprtnCd;

	@Column(name="MBU_VALS_TXT")
	private String mbuValsTxt;

	@Column(name="NATL_ACCT_OPRTN_CD")
	private String natlAcctOprtnCd;

	@Column(name="NATL_ACCT_VALS_TXT")
	private String natlAcctValsTxt;

	@Column(name="NTWK_OPRTN_CD")
	private String ntwkOprtnCd;

	@Column(name="NTWK_VALS_TXT")
	private String ntwkValsTxt;

	@Temporal(TemporalType.DATE)
	@Column(name="PROD_BRNDG_DCSN_EFCTV_DT")
	private Date prodBrndgDcsnEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="PROD_BRNDG_DCSN_TRMNTN_DT")
	private Date prodBrndgDcsnTrmntnDt;

	@Column(name="PROD_LINE_OPRTN_CD")
	private String prodLineOprtnCd;

	@Column(name="PROD_LINE_VALS_TXT")
	private String prodLineValsTxt;

	@Column(name="PROD_TYPE_OPRTN_CD")
	private String prodTypeOprtnCd;

	@Column(name="PROD_TYPE_VALS_TXT")
	private String prodTypeValsTxt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	public ProdBrndgDcsn() {
	}

	public long getProdBrndgDcsnId() {
		return this.prodBrndgDcsnId;
	}

	public void setProdBrndgDcsnId(long prodBrndgDcsnId) {
		this.prodBrndgDcsnId = prodBrndgDcsnId;
	}

	public String getBrndgDcmntTypeCd() {
		return this.brndgDcmntTypeCd;
	}

	public void setBrndgDcmntTypeCd(String brndgDcmntTypeCd) {
		this.brndgDcmntTypeCd = brndgDcmntTypeCd;
	}

	public String getBrndgLogoTypeCd() {
		return this.brndgLogoTypeCd;
	}

	public void setBrndgLogoTypeCd(String brndgLogoTypeCd) {
		this.brndgLogoTypeCd = brndgLogoTypeCd;
	}

	public String getBrndgTglnCd() {
		return this.brndgTglnCd;
	}

	public void setBrndgTglnCd(String brndgTglnCd) {
		this.brndgTglnCd = brndgTglnCd;
	}

	public BigDecimal getBrndgTglnOccNbr() {
		return this.brndgTglnOccNbr;
	}

	public void setBrndgTglnOccNbr(BigDecimal brndgTglnOccNbr) {
		this.brndgTglnOccNbr = brndgTglnOccNbr;
	}

	public String getCmpnyCd() {
		return this.cmpnyCd;
	}

	public void setCmpnyCd(String cmpnyCd) {
		this.cmpnyCd = cmpnyCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Timestamp getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Timestamp creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgOprtnCd() {
		return this.cvrgOprtnCd;
	}

	public void setCvrgOprtnCd(String cvrgOprtnCd) {
		this.cvrgOprtnCd = cvrgOprtnCd;
	}

	public String getCvrgValsTxt() {
		return this.cvrgValsTxt;
	}

	public void setCvrgValsTxt(String cvrgValsTxt) {
		this.cvrgValsTxt = cvrgValsTxt;
	}

	public String getDcsnOprtnCd() {
		return this.dcsnOprtnCd;
	}

	public void setDcsnOprtnCd(String dcsnOprtnCd) {
		this.dcsnOprtnCd = dcsnOprtnCd;
	}

	public String getEgrOprtnCd() {
		return this.egrOprtnCd;
	}

	public void setEgrOprtnCd(String egrOprtnCd) {
		this.egrOprtnCd = egrOprtnCd;
	}

	public String getEgrValsTxt() {
		return this.egrValsTxt;
	}

	public void setEgrValsTxt(String egrValsTxt) {
		this.egrValsTxt = egrValsTxt;
	}

	public String getGnrlDefnOprtnCd() {
		return this.gnrlDefnOprtnCd;
	}

	public void setGnrlDefnOprtnCd(String gnrlDefnOprtnCd) {
		this.gnrlDefnOprtnCd = gnrlDefnOprtnCd;
	}

	public String getGnrlDefnValsTxt() {
		return this.gnrlDefnValsTxt;
	}

	public void setGnrlDefnValsTxt(String gnrlDefnValsTxt) {
		this.gnrlDefnValsTxt = gnrlDefnValsTxt;
	}

	public BigDecimal getHrchyCd() {
		return this.hrchyCd;
	}

	public void setHrchyCd(BigDecimal hrchyCd) {
		this.hrchyCd = hrchyCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Timestamp getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Timestamp lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLobOprtnCd() {
		return this.lobOprtnCd;
	}

	public void setLobOprtnCd(String lobOprtnCd) {
		this.lobOprtnCd = lobOprtnCd;
	}

	public String getLobValsTxt() {
		return this.lobValsTxt;
	}

	public void setLobValsTxt(String lobValsTxt) {
		this.lobValsTxt = lobValsTxt;
	}

	public String getMbuOprtnCd() {
		return this.mbuOprtnCd;
	}

	public void setMbuOprtnCd(String mbuOprtnCd) {
		this.mbuOprtnCd = mbuOprtnCd;
	}

	public String getMbuValsTxt() {
		return this.mbuValsTxt;
	}

	public void setMbuValsTxt(String mbuValsTxt) {
		this.mbuValsTxt = mbuValsTxt;
	}

	public String getNatlAcctOprtnCd() {
		return this.natlAcctOprtnCd;
	}

	public void setNatlAcctOprtnCd(String natlAcctOprtnCd) {
		this.natlAcctOprtnCd = natlAcctOprtnCd;
	}

	public String getNatlAcctValsTxt() {
		return this.natlAcctValsTxt;
	}

	public void setNatlAcctValsTxt(String natlAcctValsTxt) {
		this.natlAcctValsTxt = natlAcctValsTxt;
	}

	public String getNtwkOprtnCd() {
		return this.ntwkOprtnCd;
	}

	public void setNtwkOprtnCd(String ntwkOprtnCd) {
		this.ntwkOprtnCd = ntwkOprtnCd;
	}

	public String getNtwkValsTxt() {
		return this.ntwkValsTxt;
	}

	public void setNtwkValsTxt(String ntwkValsTxt) {
		this.ntwkValsTxt = ntwkValsTxt;
	}

	public Date getProdBrndgDcsnEfctvDt() {
		return this.prodBrndgDcsnEfctvDt;
	}

	public void setProdBrndgDcsnEfctvDt(Date prodBrndgDcsnEfctvDt) {
		this.prodBrndgDcsnEfctvDt = prodBrndgDcsnEfctvDt;
	}

	public Date getProdBrndgDcsnTrmntnDt() {
		return this.prodBrndgDcsnTrmntnDt;
	}

	public void setProdBrndgDcsnTrmntnDt(Date prodBrndgDcsnTrmntnDt) {
		this.prodBrndgDcsnTrmntnDt = prodBrndgDcsnTrmntnDt;
	}

	public String getProdLineOprtnCd() {
		return this.prodLineOprtnCd;
	}

	public void setProdLineOprtnCd(String prodLineOprtnCd) {
		this.prodLineOprtnCd = prodLineOprtnCd;
	}

	public String getProdLineValsTxt() {
		return this.prodLineValsTxt;
	}

	public void setProdLineValsTxt(String prodLineValsTxt) {
		this.prodLineValsTxt = prodLineValsTxt;
	}

	public String getProdTypeOprtnCd() {
		return this.prodTypeOprtnCd;
	}

	public void setProdTypeOprtnCd(String prodTypeOprtnCd) {
		this.prodTypeOprtnCd = prodTypeOprtnCd;
	}

	public String getProdTypeValsTxt() {
		return this.prodTypeValsTxt;
	}

	public void setProdTypeValsTxt(String prodTypeValsTxt) {
		this.prodTypeValsTxt = prodTypeValsTxt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}