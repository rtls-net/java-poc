package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the GRP_PRBTN_PRD database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "GRP_PRBTN_PRD")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class GrpPrbtnPrd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="GRP_PRBTN_PRD_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private long grpPrbtnPrdId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

    @CreatedDate
	@Column(name="CREATD_DTM")
    private Date creatdDtm;

	@Column(name="CVRG_TYPE_CD")
	private String cvrgTypeCd;

	@Column(name="GRP_PRBTN_PRD_STTS_CD")
    private String sttsCd;

    @LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

    @LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
    private Date lastUpdtdDtm;

	@Column(name="PRBTN_CLS_TXT")
	private String prbtnClsTxt;

	@Column(name="PRBTN_PRD_CD")
	private String prbtnPrdCd;

	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="PRBTN_PRD_CD_EFCTV_DT")
	private Date prbtnPrdCdEfctvDt;

	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="PRBTN_PRD_CD_TRMNTN_DT")
	private Date prbtnPrdCdTrmntnDt;

    @Version
	@Column(name="VRSN_NBR")
    private Long vrsnNbr = 1L;

    //bi-directional many-to-one association to Cntrct
    @JsonIgnore
    @ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name="CNTRCT_ID")
	private Cntrct cntrct;

	//bi-directional many-to-one association to Grp
    @JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name="GRP_ID")
	private Grp grp;
    
    @Transient
    private Long cntrctId;
	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}   

	public GrpPrbtnPrd() {
	}

	public long getGrpPrbtnPrdId() {
		return this.grpPrbtnPrdId;
	}

	public void setGrpPrbtnPrdId(long grpPrbtnPrdId) {
		this.grpPrbtnPrdId = grpPrbtnPrdId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgTypeCd() {
		return this.cvrgTypeCd;
	}

	public void setCvrgTypeCd(String cvrgTypeCd) {
		this.cvrgTypeCd = cvrgTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getPrbtnClsTxt() {
		return this.prbtnClsTxt;
	}

	public void setPrbtnClsTxt(String prbtnClsTxt) {
		this.prbtnClsTxt = prbtnClsTxt;
	}

	public String getPrbtnPrdCd() {
		return this.prbtnPrdCd;
	}

	public void setPrbtnPrdCd(String prbtnPrdCd) {
		this.prbtnPrdCd = prbtnPrdCd;
	}

	public Date getPrbtnPrdCdEfctvDt() {
		return this.prbtnPrdCdEfctvDt;
	}

	public void setPrbtnPrdCdEfctvDt(Date prbtnPrdCdEfctvDt) {
		this.prbtnPrdCdEfctvDt = prbtnPrdCdEfctvDt;
	}

	public Date getPrbtnPrdCdTrmntnDt() {
		return this.prbtnPrdCdTrmntnDt;
	}

	public void setPrbtnPrdCdTrmntnDt(Date prbtnPrdCdTrmntnDt) {
		this.prbtnPrdCdTrmntnDt = prbtnPrdCdTrmntnDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public String getSttsCd() {
		return sttsCd;
	}

	public void setSttsCd(String sttsCd) {
		this.sttsCd = sttsCd;
	}

	public Cntrct getCntrct() {
		return cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpPrbtnPrd [grpPrbtnPrdId=" + grpPrbtnPrdId + ", cvrgTypeCd=" + cvrgTypeCd + ", sttsCd=" + sttsCd
				+", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null)
				+ ", prbtnClsTxt=" + prbtnClsTxt + ", prbtnPrdCd=" + prbtnPrdCd + ", prbtnPrdCdEfctvDt="
				+ (prbtnPrdCdEfctvDt!=null?formatter.format(prbtnPrdCdEfctvDt):null) + ", prbtnPrdCdTrmntnDt=" + (prbtnPrdCdTrmntnDt!=null?formatter.format(prbtnPrdCdTrmntnDt):null) + ", vrsnNbr=" + vrsnNbr + "]";
	}
	
	
}