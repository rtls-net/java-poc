package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CD_VAL_FLTR database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="CD_VAL_FLTR")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CdValFltr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CD_VAL_FLTR_ID")
	private long cdValFltrId;

	@Column(name="CD_VAL_CD")
	private String cdValCd;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="DESC_TXT")
	private String descTxt;

	@Column(name="DSPLY_SQNC_NBR")
	private BigDecimal dsplySqncNbr;

	@Column(name="FLTR_CDCV_CD_VAL_CD")
	private String fltrCdcvCdValCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LFCYCL_STTS_CD")
	private String lfcyclSttsCd;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_EFCTV_DT")
	private Date lfcyclSttsEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_TRMNTN_DT")
	private Date lfcyclSttsTrmntnDt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr;

	//bi-directional many-to-one association to CdVal
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FLTR_CD_SET_RDMC_ITEM_ID")
	private CdVal cdVal1;

	//bi-directional many-to-one association to CdVal
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CD_SET_RDMC_ID")
	private CdVal cdVal2;

	public CdValFltr() {
	}

	public long getCdValFltrId() {
		return this.cdValFltrId;
	}

	public void setCdValFltrId(long cdValFltrId) {
		this.cdValFltrId = cdValFltrId;
	}

	public String getCdValCd() {
		return this.cdValCd;
	}

	public void setCdValCd(String cdValCd) {
		this.cdValCd = cdValCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getDescTxt() {
		return this.descTxt;
	}

	public void setDescTxt(String descTxt) {
		this.descTxt = descTxt;
	}

	public BigDecimal getDsplySqncNbr() {
		return this.dsplySqncNbr;
	}

	public void setDsplySqncNbr(BigDecimal dsplySqncNbr) {
		this.dsplySqncNbr = dsplySqncNbr;
	}

	public String getFltrCdcvCdValCd() {
		return this.fltrCdcvCdValCd;
	}

	public void setFltrCdcvCdValCd(String fltrCdcvCdValCd) {
		this.fltrCdcvCdValCd = fltrCdcvCdValCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLfcyclSttsCd() {
		return this.lfcyclSttsCd;
	}

	public void setLfcyclSttsCd(String lfcyclSttsCd) {
		this.lfcyclSttsCd = lfcyclSttsCd;
	}

	public Date getLfcyclSttsEfctvDt() {
		return this.lfcyclSttsEfctvDt;
	}

	public void setLfcyclSttsEfctvDt(Date lfcyclSttsEfctvDt) {
		this.lfcyclSttsEfctvDt = lfcyclSttsEfctvDt;
	}

	public Date getLfcyclSttsTrmntnDt() {
		return this.lfcyclSttsTrmntnDt;
	}

	public void setLfcyclSttsTrmntnDt(Date lfcyclSttsTrmntnDt) {
		this.lfcyclSttsTrmntnDt = lfcyclSttsTrmntnDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public CdVal getCdVal1() {
		return this.cdVal1;
	}

	public void setCdVal1(CdVal cdVal1) {
		this.cdVal1 = cdVal1;
	}

	public CdVal getCdVal2() {
		return this.cdVal2;
	}

	public void setCdVal2(CdVal cdVal2) {
		this.cdVal2 = cdVal2;
	}

}