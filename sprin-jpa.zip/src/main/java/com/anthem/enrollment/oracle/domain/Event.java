package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the "EVENTS" database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="\"EVENTS\"")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Event implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EVENT_ID")
	private long eventId;

	@Column(name="BUS_UNIT")
	private String busUnit;

	@LastModifiedDate
	@Temporal(TemporalType.DATE)
	@Column(name="CHANGED_AT")
	private Date changedAt;

	@LastModifiedBy
	@Column(name="CHANGED_BY")
	private String changedBy;

	@Column(name="EVENT_ID2")
	private String eventId2;

	@Column(name="EVENT_SRC")
	private String eventSrc;

	@Column(name="EVENT_STATUS")
	private String eventStatus;

	@Column(name="EVENT_TYPE")
	private String eventType;

	@Lob
	private String payload;

	public Event() {
	}

	public long getEventId() {
		return this.eventId;
	}

	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	public String getBusUnit() {
		return this.busUnit;
	}

	public void setBusUnit(String busUnit) {
		this.busUnit = busUnit;
	}

	public Date getChangedAt() {
		return this.changedAt;
	}

	public void setChangedAt(Date changedAt) {
		this.changedAt = changedAt;
	}

	public String getChangedBy() {
		return this.changedBy;
	}

	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}

	public String getEventId2() {
		return this.eventId2;
	}

	public void setEventId2(String eventId2) {
		this.eventId2 = eventId2;
	}

	public String getEventSrc() {
		return this.eventSrc;
	}

	public void setEventSrc(String eventSrc) {
		this.eventSrc = eventSrc;
	}

	public String getEventStatus() {
		return this.eventStatus;
	}

	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	public String getEventType() {
		return this.eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getPayload() {
		return this.payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}