package com.anthem.enrollment.oracle.dao;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.anthem.enrollment.oracle.domain.Cntrct;


public interface CntrctDAO extends CrudRepository<Cntrct, Long> {

	//List<Cntrct> findByGrpGrpId(Long grpId);

	@Query(value="select c from Cntrct c where grpId=:grpId")//,nativeQuery=true
	List<Cntrct> findByGrpGrpId(@Param("grpId")Long grpId);
}
