package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * The persistent class for the WGS_PRFRNC_DTLS database table.
 *
 * @author Deloitte
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="WGS_PRFRNC_DTLS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WgsPrfrncDtls implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "WGS_PRFRNCS_DTLS_ID")
    private long wgsPrfrncDtlsId;

    //@Column(name = "WGS_PRFRNCS_ID")
    //private long wgsPrfrncsId;

    @Column(name = "ST_CD")
    private String stCd;

    @Column(name = "EFCTV_DT")
    private Timestamp efctvDt;

    @Column(name = "TRMNTN_DT")
    private Timestamp trmntnDt;

    @Version
    @Column(name = "VRSN_NBR")
    private Long vrsnNbr = 1L;

    @Column(name = "LOB_CD")
    private String lobCd;

    @Column(name = "PRFRNC_VAL_TXT")
    private String prfrncValTxt;

    @Column(name = "PRFRNC_TYPE_CD")
    private String prfrncTypeCd;

    @Column(name = "PRFRNC_DTLS_DESC")
    private String prfrncDtlsDesc;

    @CreatedBy
    @Column(name = "CREATD_BY")
    private String creatdBy;

    @LastModifiedBy
    @Column(name = "UPDTD_BY")
    private String updtdBy;

    @CreatedDate
    @Column(name = "CREATD_DTM")
    private Date creatdDtm;

    @LastModifiedDate
    @Column(name = "UPDTD_DTM")
    private Date updtdDtm;

    //bi-directional many-to-one association to WgsPrfrncs
    //@JsonIgnore
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="WGS_PRFRNCS_ID")
    private WgsPrfrncs wgsPrfrncs;

    @Column(name = "FLTR_TYPE_CD")
    private String fltrTypeCd;

    public WgsPrfrncDtls() {

    }

    public long getWgsPrfrncDtlsId() {
        return wgsPrfrncDtlsId;
    }

    public void setWgsPrfrncDtlsId(long wgsPrfrncDtlsId) {
        this.wgsPrfrncDtlsId = wgsPrfrncDtlsId;
    }

   /* public long getWgsPrfrncsId() {
        return wgsPrfrncsId;
    }

    public void setWgsPrfrncsId(long wgsPrfrncsId) {
        this.wgsPrfrncsId = wgsPrfrncsId;
    }*/

    public String getStCd() {
        return stCd;
    }

    public void setStCd(String stCd) {
        this.stCd = stCd;
    }

    public Timestamp getEfctvDt() {
        return efctvDt;
    }

    public void setEfctvDt(Timestamp efctvDt) {
        this.efctvDt = efctvDt;
    }

    public Timestamp getTrmntnDt() {
        return trmntnDt;
    }

    public void setTrmntnDt(Timestamp trmntnDt) {
        this.trmntnDt = trmntnDt;
    }

    public Long getVrsnNbr() {
        return vrsnNbr;
    }

    public void setVrsnNbr(Long vrsnNbr) {
        this.vrsnNbr = vrsnNbr;
    }

    public String getLobCd() {
        return lobCd;
    }

    public void setLobCd(String lobCd) {
        this.lobCd = lobCd;
    }

    public String getPrfrncValTxt() {
        return prfrncValTxt;
    }

    public void setPrfrncValTxt(String prfrncValTxt) {
        this.prfrncValTxt = prfrncValTxt;
    }

    public String getPrfrncTypeCd() {
        return prfrncTypeCd;
    }

    public void setPrfrncTypeCd(String prfrncTypeCd) {
        this.prfrncTypeCd = prfrncTypeCd;
    }

    public String getPrfrncDtlsDesc() {
        return prfrncDtlsDesc;
    }

    public void setPrfrncDtlsDesc(String prfrncDtlsDesc) {
        this.prfrncDtlsDesc = prfrncDtlsDesc;
    }

    public String getCreatdBy() {
        return creatdBy;
    }

    public void setCreatdBy(String creatdBy) {
        this.creatdBy = creatdBy;
    }

    public String getUpdtdBy() {
        return updtdBy;
    }

    public void setUpdtdBy(String updtdBy) {
        this.updtdBy = updtdBy;
    }

    public Date getCreatdDtm() {
        return creatdDtm;
    }

    public void setCreatdDtm(Date creatdDtm) {
        this.creatdDtm = creatdDtm;
    }

    public Date getUpdtdDtm() {
        return updtdDtm;
    }

    public void setUpdtdDtm(Date updtdDtm) {
        this.updtdDtm = updtdDtm;
    }

    public WgsPrfrncs getWgsPrfrncs() {
        return wgsPrfrncs;
    }

    public void setWgsPrfrncs(WgsPrfrncs wgsPrfrncs) {
        this.wgsPrfrncs = wgsPrfrncs;
    }

    public String getFltrTypeCd() {
        return fltrTypeCd;
    }

    public void setFltrTypeCd(String fltrTypeCd) {
        this.fltrTypeCd = fltrTypeCd;
    }
}
