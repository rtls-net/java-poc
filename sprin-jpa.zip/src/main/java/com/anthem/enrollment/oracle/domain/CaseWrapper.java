package com.anthem.enrollment.oracle.domain;

import com.anthem.enrollment.domain.CaseAssociation;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CaseWrapper - This class wraps all domain objects related to case creation.
 *
 * @author Deloitte
 * @version 1.0
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class CaseWrapper implements Serializable {

    /**
     * The Constant serialVersionUID.
     */
    private static final long serialVersionUID = -6647027099464873497L;

    /**
     * Constructs CaseWrapper with default member values.
     */
    public CaseWrapper() {
    }

    ;

    Map<String, Map<String, String>> rtDataMap = new HashMap<>();

    public Map<String, Map<String, String>> getRtDataMap() {
        return rtDataMap;
    }

    public void setRtDataMap(Map<String, Map<String, String>> rtDataMap) {
        this.rtDataMap = rtDataMap;
    }
    
    private List<CaseLinkageAssocation> caseLinkageAssocation;
    
    private String migrationCase;


	/**
     * The sic cd drp dwn.
     */
    private List<String> sicCdDrpDwn;

    /**
     * Gets the sic cd drp dwn.
     *
     * @return List<String>
     */
    public List<String> getSicCdDrpDwn() {
        return sicCdDrpDwn;
    }

    /**
     * Sets the sic cd drp dwn.
     *
     * @param sicCdDrpDwn the new sic cd drp dwn
     */
    public void setSicCdDrpDwn(List<String> sicCdDrpDwn) {
        this.sicCdDrpDwn = sicCdDrpDwn;
    }

    /**
     * The act coord drp dwn.
     */
    private List<String> actCoordDrpDwn;

    /**
     * Gets the act coord drp dwn.
     *
     * @return List<String>
     */
    public List<String> getActCoordDrpDwn() {
        return actCoordDrpDwn;
    }

    /**
     * Sets the act coord drp dwn.
     *
     * @param actCoordDrpDwn the new act coord drp dwn
     */
    public void setActCoordDrpDwn(List<String> actCoordDrpDwn) {
        this.actCoordDrpDwn = actCoordDrpDwn;
    }

    /**
     * The undrwrtr cd drp dwn.
     */
    private List<String> undrwrtrCdDrpDwn;

    /**
     * Gets the undrwrtr cd drp dwn.
     *
     * @return List<String>
     */
    public List<String> getUndrwrtrCdDrpDwn() {
        return undrwrtrCdDrpDwn;
    }

    /**
     * Sets the undrwrtr cd drp dwn.
     *
     * @param undrwrtrCdDrpDwn the new undrwrtr cd drp dwn
     */
    public void setUndrwrtrCdDrpDwn(List<String> undrwrtrCdDrpDwn) {
        this.undrwrtrCdDrpDwn = undrwrtrCdDrpDwn;
    }

    /**
     * The srvc rp drp dwn.
     */
    private List<String> srvcRpDrpDwn;

    /**
     * Gets the srvc rp drp dwn.
     *
     * @return List<String>
     */
    public List<String> getSrvcRpDrpDwn() {
        return srvcRpDrpDwn;
    }

    /**
     * Sets the srvc rp drp dwn.
     *
     * @param srvcRpDrpDwn the new srvc rp drp dwn
     */
    public void setSrvcRpDrpDwn(List<String> srvcRpDrpDwn) {
        this.srvcRpDrpDwn = srvcRpDrpDwn;
    }

    /**
     * The sls rp drp dwn.
     */
    private List<String> slsRpDrpDwn;

    /**
     * Gets the sls rp drp dwn.
     *
     * @return List<String>
     */
    public List<String> getSlsRpDrpDwn() {
        return slsRpDrpDwn;
    }

    /**
     * Sets the sls rp drp dwn.
     *
     * @param slsRpDrpDwn the new sls rp drp dwn
     */
    public void setSlsRpDrpDwn(List<String> slsRpDrpDwn) {
        this.slsRpDrpDwn = slsRpDrpDwn;
    }

    /**
     * The activate clicked.
     */
    private String activateClicked;

    /**
     * Gets the activate clicked.
     *
     * @return String
     */
    public String getActivateClicked() {
        return activateClicked;
    }

    /**
     * Sets the activate clicked.
     *
     * @param activateClicked the new activate clicked
     */
    public void setActivateClicked(String activateClicked) {
        this.activateClicked = activateClicked;
    }

    /**
     * The save clicked.
     */
    private String saveClicked;

    /**
     * Gets the save clicked.
     *
     * @return String
     */
    public String getSaveClicked() {
        return saveClicked;
    }

    /**
     * Sets the save clicked.
     *
     * @param saveClicked the new save clicked
     */
    public void setSaveClicked(String saveClicked) {
        this.saveClicked = saveClicked;
    }

    /**
     * The enrollment type.
     */
    private String enrollment_type;

    /**
     * Gets the enrollment type.
     *
     * @return String
     */
    public String getEnrollment_type() {
        return enrollment_type;
    }

    /**
     * Sets the enrollment type.
     *
     * @param enrollment_type the new enrollment type
     */
    public void setEnrollment_type(String enrollment_type) {
        this.enrollment_type = enrollment_type;
    }

    /**
     * The group.
     */
    private Grp group;

    /**
     * Sets the group.
     *
     * @param theValue the new group
     */
    public void setGroup(Grp theValue) {
        this.group = theValue;
    }

    /**
     * Gets the group.
     *
     * @return Grp
     */
    public Grp getGroup() {
        return group;
    }

    /**
     * The cntrct plan.
     */
    private CntrctPlan cntrctPlan;

    /**
     * Gets the cntrct plan.
     *
     * @return CntrctPlan
     */
    public CntrctPlan getCntrctPlan() {
        return cntrctPlan;
    }

    /**
     * Sets the cntrct plan.
     *
     * @param cntrctPlan the new cntrct plan
     */
    public void setCntrctPlan(CntrctPlan cntrctPlan) {
        this.cntrctPlan = cntrctPlan;
    }

    /** The cntrct plan fncl acct. */
//	private CntrctPlanFnclAcct cntrctPlanFnclAcct;

    /**
     * Sets the cntrct plan fncl acct.
     *
     * @param theValue the new cntrct plan fncl acct
     */
//	public void setCntrctPlanFnclAcct(CntrctPlanFnclAcct theValue) {
//		this.cntrctPlanFnclAcct = theValue;
//	}

    /**
     * Gets the cntrct plan fncl acct.
     *
     * @return CntrctPlanFnclAcct
     */
//	public CntrctPlanFnclAcct getCntrctPlanFnclAcct() {
//		return cntrctPlanFnclAcct;
//	}

    /**
     * The adrs.
     */
    private Adrs adrs;

    /**
     * Gets the adrs.
     *
     * @return Adrs
     */
    public Adrs getAdrs() {
        return adrs;
    }

    /**
     * Sets the adrs.
     *
     * @param adrs the new adrs
     */
    public void setAdrs(Adrs adrs) {
        this.adrs = adrs;
    }

    /**
     * The grp adrs.
     */
    private GrpAdr grpAdrs;

    /**
     * Sets the group adrs.
     *
     * @param theValue the new group adrs
     */
    public void setGrpAdrs(GrpAdr theValue) {
        this.grpAdrs = theValue;
    }

    /**
     * Gets the group adrs.
     *
     * @return GrpAdrs
     */
    public GrpAdr getGrpAdrs() {
        return grpAdrs;
    }

    /**
     * The grp email adrs.
     */
    private GrpEmailAdr grpEmailAdrs;

    /**
     * Sets the group email adrs.
     *
     * @param theValue the new group email adrs
     */
    public void setGrpEmailAdrs(GrpEmailAdr theValue) {
        this.grpEmailAdrs = theValue;
    }

    /**
     * Gets the group email adrs.
     *
     * @return GrpEmailAdrs
     */
    public GrpEmailAdr getGrpEmailAdrs() {
        return grpEmailAdrs;
    }

    /**
     * The grp hc.
     */
    private GrpHc grpHc;

    /**
     * Sets the group hc.
     *
     * @param theValue the new group hc
     */
    public void setGrpHc(GrpHc theValue) {
        this.grpHc = theValue;
    }

    /**
     * Gets the group hc.
     *
     * @return GrpHc
     */
    public GrpHc getGrpHc() {
        return grpHc;
    }

    /**
     * The grp indctv.
     */
    private GrpIndctv grpIndctv;

    /**
     * Sets the group indctv.
     *
     * @param theValue the new group indctv
     */
    public void setGrpIndctv(GrpIndctv theValue) {
        this.grpIndctv = theValue;
    }

    /**
     * Gets the group indctv.
     *
     * @return GrpIndctv
     */
    public GrpIndctv getGrpIndctv() {
        return grpIndctv;
    }

    /**
     * The grp lang.
     */
    private GrpLang grpLang;

    /**
     * Sets the group lang.
     *
     * @param theValue the new group lang
     */
    public void setGrpLang(GrpLang theValue) {
        this.grpLang = theValue;
    }

    /**
     * Gets the group lang.
     *
     * @return GrpLang
     */
    public GrpLang getGrpLang() {
        return grpLang;
    }

    /**
     * The grp note.
     */
    private GrpNote grpNote;
    
    
    private List<GrpNote> grpNoteList = new ArrayList<>();

    /**
     * Sets the group note.
     *
     * @param theValue the new group note
     */
    public void setGrpNote(GrpNote theValue) {
        this.grpNote = theValue;
    }

    /**
     * Gets the group note.
     *
     * @return GrpNote
     */
    public GrpNote getGrpNote() {
        return grpNote;
    }

    /**
     * The grp size.
     */
    private GrpSize grpSize;

    /**
     * Sets the group size.
     *
     * @param theValue the new group size
     */
    public void setGrpSize(GrpSize theValue) {
        this.grpSize = theValue;
    }

    /**
     * Gets the group size.
     *
     * @return GrpSize
     */
    public GrpSize getGrpSize() {
        return grpSize;
    }

    /**
     * The grp spcl instrctn.
     */
    private GrpSpclInstrctn grpSpclInstrctn;

    /**
     * Sets the group spcl instrctn.
     *
     * @param theValue the new group spcl instrctn
     */
    public void setGrpSpclInstrctn(GrpSpclInstrctn theValue) {
        this.grpSpclInstrctn = theValue;
    }

    /**
     * Gets the group spcl instrctn.
     *
     * @return GrpSpclInstrctn
     */
    public GrpSpclInstrctn getGrpSpclInstrctn() {
        return grpSpclInstrctn;
    }

    /**
     * The grp sprt asgnmnt.
     */
    private GrpSprtAsgnmnt grpSprtAsgnmnt;

    private List<GrpSprtAsgnmnt> grpSprtAsgnmntList = new ArrayList<>();

    public List<GrpSprtAsgnmnt> getGrpSprtAsgnmntList() {
        return grpSprtAsgnmntList;
    }

    public void setGrpSprtAsgnmntList(List<GrpSprtAsgnmnt> grpSprtAsgnmntList) {
        this.grpSprtAsgnmntList = grpSprtAsgnmntList;
    }
    
    private List<CaseAssociation> caseAssocation;

    /**
     * Sets the group sprt asgnmnt.
     *
     * @param theValue the new group sprt asgnmnt
     */
    public void setGrpSprtAsgnmnt(GrpSprtAsgnmnt theValue) {
        this.grpSprtAsgnmnt = theValue;
    }

    /**
     * Gets the group sprt asgnmnt.
     *
     * @return GrpSprtAsgnmnt
     */
    public GrpSprtAsgnmnt getGrpSprtAsgnmnt() {
        return grpSprtAsgnmnt;
    }

    /** The grp tax st. */
//	private GrpTaxSt grpTaxSt;

    /**
     * Sets the group tax st.
     *
     * @param theValue the new group tax st
     */
//	public void setGrpTaxSt(GrpTaxSt theValue) {
//		this.grpTaxSt = theValue;
//	}

    /**
     * Gets the group tax st.
     *
     * @return GrpTaxSt
     */
//	public GrpTaxSt getGrpTaxSt() {
//		return grpTaxSt;
//	}

    /**
     * The cntct prsn.
     */
    private CntctPrsn cntctPrsn;

    /**
     * Gets the cntct prsn.
     *
     * @return CntctPrsn
     */
    public CntctPrsn getCntctPrsn() {
        return cntctPrsn;
    }

    /**
     * Sets the cntct prsn.
     *
     * @param cntctPrsn the new cntct prsn
     */
    public void setCntctPrsn(CntctPrsn cntctPrsn) {
        this.cntctPrsn = cntctPrsn;
    }

    /**
     * The grp cntct prsn email adrs.
     */
    private GrpCntctPrsnEmailAdr grpCntctPrsnEmailAdrs;

    /**
     * Gets the group cntct prsn email adrs.
     *
     * @return GrpCntctPrsnEmailAdrs
     */
    public GrpCntctPrsnEmailAdr getGrpCntctPrsnEmailAdrs() {
        return grpCntctPrsnEmailAdrs;
    }

    /**
     * Sets the group cntct prsn email adrs.
     *
     * @param grpCntctPrsnEmailAdrs the new group cntct prsn email adrs
     */
    public void setGrpCntctPrsnEmailAdrs(
            GrpCntctPrsnEmailAdr grpCntctPrsnEmailAdrs) {
        this.grpCntctPrsnEmailAdrs = grpCntctPrsnEmailAdrs;
    }

    /**
     * The grp tlphn.
     */
    private GrpTlphn grpTlphn;

    private List<GrpTlphn> grpTlphnList = new ArrayList<>();

    public List<GrpTlphn> getGrpTlphnList() {
        return grpTlphnList;
    }

    public void setGrpTlphnList(List<GrpTlphn> grpTlphnList) {
        this.grpTlphnList = grpTlphnList;
    }

    /**
     * Sets the group tlphn.
     *
     * @param theValue the new group tlphn
     */
    public void setGrpTlphn(GrpTlphn theValue) {
        this.grpTlphn = theValue;
    }

    /**
     * Gets the group tlphn.
     *
     * @return GrpTlphn
     */
    public GrpTlphn getGrpTlphn() {
        return grpTlphn;
    }

    /**
     * The grp to grp rltnshp.
     */
    private GrpToGrpRltnshp grpToGrpRltnshp;

    /**
     * Sets the group to group rltnshp.
     *
     * @param theValue the new group to group rltnshp
     */
    public void setGrpToGrpRltnshp(GrpToGrpRltnshp theValue) {
        this.grpToGrpRltnshp = theValue;
    }

    /**
     * Gets the group to group rltnshp.
     *
     * @return GrpToGrpRltnshp
     */
    public GrpToGrpRltnshp getGrpToGrpRltnshp() {
        return grpToGrpRltnshp;
    }

    /**
     * The lgcy grp cf.
     */
    private LgcyGrpCf lgcyGrpCf;

    /**
     * Sets the lgcy group cf.
     *
     * @param theValue the new lgcy group cf
     */
    public void setLgcyGrpCf(LgcyGrpCf theValue) {
        this.lgcyGrpCf = theValue;
    }

    /**
     * Gets the lgcy group cf.
     *
     * @return LgcyGrpCf
     */
    public LgcyGrpCf getLgcyGrpCf() {
        return lgcyGrpCf;
    }

    /**
     * The grp cntrct prvsn.
     */
    private GrpCntrctPrvsn grpCntrctPrvsn;

    /**
     * Gets the group cntrct prvsn.
     *
     * @return GrpCntrctPrvsn
     */
    public GrpCntrctPrvsn getGrpCntrctPrvsn() {
        return grpCntrctPrvsn;
    }

    /**
     * Sets the group cntrct prvsn.
     *
     * @param grpCntrctPrvsn the new group cntrct prvsn
     */
    public void setGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
        this.grpCntrctPrvsn = grpCntrctPrvsn;
    }

    /**
     * The grp rt mthd.
     */
    private GrpRtMthd grpRtMthd;
    private List<GrpRtMthd> grpRtMthdList = new ArrayList<>();

    public List<GrpRtMthd> getGrpRtMthdList() {
        return grpRtMthdList;
    }

    public void setGrpRtMthdList(List<GrpRtMthd> grpRtMthdList) {
        this.grpRtMthdList = grpRtMthdList;
    }

    /**
     * Gets the group rt mthd.
     *
     * @return GrpRtMthd
     */
    public GrpRtMthd getGrpRtMthd() {
        return grpRtMthd;
    }

    /**
     * Sets the group rt mthd.
     *
     * @param grpRtMthd the new group rt mthd
     */
    public void setGrpRtMthd(GrpRtMthd grpRtMthd) {
        this.grpRtMthd = grpRtMthd;
    }

    /**
     * The grp prior cvrg.
     */
    private GrpPriorCvrg grpPriorCvrg;

    /**
     * Gets the group prior cvrg.
     *
     * @return GrpPriorCvrg
     */
    public GrpPriorCvrg getGrpPriorCvrg() {
        return grpPriorCvrg;
    }

    /**
     * Sets the group prior cvrg.
     *
     * @param grpPriorCvrg the new group prior cvrg
     */
    public void setGrpPriorCvrg(GrpPriorCvrg grpPriorCvrg) {
        this.grpPriorCvrg = grpPriorCvrg;
    }

    /**
     * The cntrct.
     */
    private Cntrct cntrct;

    /**
     * Gets the cntrct.
     *
     * @return Cntrct
     */
    public Cntrct getCntrct() {
        return cntrct;
    }

    /**
     * Sets the cntrct.
     *
     * @param cntrct the new cntrct
     */
    public void setCntrct(Cntrct cntrct) {
        this.cntrct = cntrct;
    }

    /**
     * The prior coverage flag.
     */
    private String priorCoverageFlag;

    /**
     * Gets the prior coverage flag.
     *
     * @return String
     */
    public String getPriorCoverageFlag() {
        return priorCoverageFlag;
    }

    /**
     * Sets the prior coverage flag.
     *
     * @param priorCoverageFlag the new prior coverage flag
     */
    public void setPriorCoverageFlag(String priorCoverageFlag) {
        this.priorCoverageFlag = priorCoverageFlag;
    }

    /** The save to wgs. */
//	private String saveToWgs = FwConstants.LETTER_N;

    /**
     * Gets the save to wgs.
     *
     * @return String
     */
//	public String getSaveToWgs() {
//		return saveToWgs;
//	}

    /**
     * Sets the save to wgs.
     *
     * @param saveToWgs the new save to wgs
     */
//	public void setSaveToWgs(String saveToWgs) {
//		this.saveToWgs = saveToWgs;
//	}

    /** Adding CaseInquiry object in CaseWrapper To be used for storing WGS Inquiry data. */
//	private CaseInquiry caseInquiry;

    /**
     * Gets the case inquiry.
     *
     * @return CaseInquiry
     */
//	public CaseInquiry getCaseInquiry() {
//		return caseInquiry;
//	}

    /**
     * Sets the case inquiry.
     *
     * @param caseInquiry the new case inquiry
     */
//	public void setCaseInquiry(CaseInquiry caseInquiry) {
//		this.caseInquiry = caseInquiry;
//	}

    /**
     * The grp rwnl dtls.
     */
    private GrpRwnlDtl grpRwnlDtls; //added for LIT-2090

    /**
     * Gets the group rwnl dtls.
     *
     * @return GrpRwnlDtls
     */
    public GrpRwnlDtl getGrpRwnlDtls() {
        return grpRwnlDtls;
    }

    /**
     * Sets the group rwnl dtls.
     *
     * @param grpRwnlDtls the new group rwnl dtls
     */
    public void setGrpRwnlDtls(GrpRwnlDtl grpRwnlDtls) {
        this.grpRwnlDtls = grpRwnlDtls;
    }

    /**
     * The concurrent local version.
     */
    private String concurrentLocalVersion;

    /**
     * Gets the concurrent local version.
     *
     * @return String
     */
    public String getConcurrentLocalVersion() {
        return concurrentLocalVersion;
    }

    /**
     * Sets the concurrent local version.
     *
     * @param concurrentLocalVersion the new concurrent local version
     */
    public void setConcurrentLocalVersion(String concurrentLocalVersion) {
        this.concurrentLocalVersion = concurrentLocalVersion;
    }

    /**
     * The is bill to date diff.
     */
    private String isBillToDateDiff;

    /**
     * Gets the checks if is bill to date diff.
     *
     * @return String
     */
    public String getIsBillToDateDiff() {
        return isBillToDateDiff;
    }

    /**
     * Sets the checks if is bill to date diff.
     *
     * @param isBillToDateDiff the new checks if is bill to date diff
     */
    public void setIsBillToDateDiff(String isBillToDateDiff) {
        this.isBillToDateDiff = isBillToDateDiff;
    }

    /**
     * The bill to date month.
     */
    private int billToDateMonth;

    /**
     * Gets the bill to date month.
     *
     * @return int
     */
    public int getBillToDateMonth() {
        return billToDateMonth;
    }

    /**
     * Sets the bill to date month.
     *
     * @param billToDateMonth the new bill to date month
     */
    public void setBillToDateMonth(int billToDateMonth) {
        this.billToDateMonth = billToDateMonth;
    }

    /**
     * The case mode.
     */
    private String caseMode;

    /**
     * Gets the case mode.
     *
     * @return String
     */
    public String getCaseMode() {
        return caseMode;
    }

    public List<GrpPriorCvrg> grpPriorCvrgList = new ArrayList<>();

    public List<GrpPriorCvrg> getGrpPriorCvrgList() {
        return grpPriorCvrgList;
    }

    public void setGrpPriorCvrgList(List<GrpPriorCvrg> grpPriorCvrgList) {
        this.grpPriorCvrgList = grpPriorCvrgList;
    }

    /**
     * Sets the case mode.
     *
     * @param caseMode the new case mode
     */
    public void setCaseMode(String caseMode) {
        this.caseMode = caseMode;
    }

    /**
     * The no grp prsnt.
     */
    private boolean noGrpPrsnt;

    /**
     * Checks if is no group prsnt.
     *
     * @return boolean
     */
    public boolean isNoGrpPrsnt() {
        return noGrpPrsnt;
    }

    /**
     * Sets the no group prsnt.
     *
     * @param noGrpPrsnt the noGrpPrsnt to set
     */
    public void setNoGrpPrsnt(boolean noGrpPrsnt) {
        this.noGrpPrsnt = noGrpPrsnt;
    }

    /**
     * Flag to indicate if the case is getting added for the first time
     **/
    public boolean addCaseFlag = true;

    public boolean isAddCaseFlag() {
        return addCaseFlag;
    }

    public void setAddCaseFlag(boolean addCaseFlag) {
        this.addCaseFlag = addCaseFlag;
    }

    private GrpCntctPrsn grpCntctPrsn;

    public GrpCntctPrsn getGrpCntctPrsn() {
        return grpCntctPrsn;
    }

    public void setGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
        this.grpCntctPrsn = grpCntctPrsn;
    }

	/**
	 * @return the caseLinkageAssocation
	 */
	public List<CaseLinkageAssocation> getCaseLinkageAssocation() {
		return caseLinkageAssocation;
	}

	/**
	 * @param caseLinkageAssocation the caseLinkageAssocation to set
	 */
	public void setCaseLinkageAssocation(List<CaseLinkageAssocation> caseLinkageAssocation) {
		this.caseLinkageAssocation = caseLinkageAssocation;
	}

	public List<CaseAssociation> getCaseAssocation() {
		return caseAssocation;
	}

	public void setCaseAssocation(List<CaseAssociation> caseAssocation) {
		this.caseAssocation = caseAssocation;
	}
	
	private String personId;
	
	private String gcustId;

	public String getPersonId() {
		return personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	public String getGcustId() {
		return gcustId;
	}
	public void setGcustId(String gcustId) {
		this.gcustId = gcustId;
	}

	public List<GrpNote> getGrpNoteList() {
		return grpNoteList;
	}

	public void setGrpNoteList(List<GrpNote> grpNoteList) {
		this.grpNoteList = grpNoteList;
	}
	
	public String getMigrationCase() {
		return migrationCase;
	}

	public void setMigrationCase(String migrationCase) {
		this.migrationCase = migrationCase;
	}

}
