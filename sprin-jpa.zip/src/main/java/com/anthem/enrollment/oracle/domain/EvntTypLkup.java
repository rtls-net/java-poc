package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the EVNT_TYP_LKUP database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="EVNT_TYP_LKUP")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EvntTypLkup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EVNT_LKUP_ID")
	private long evntLkupId;

	@CreatedBy
	@Column(name="CREATED_BY")
	private String createdBy;

	@CreatedDate
	@Column(name="CREATED_DTM")
	private Date createdDtm;

	@Column(name="EVNT_STATUS")
	private String evntStatus;

	@Column(name="EVNT_TYP_CD")
	private String evntTypCd;

	@Column(name="EVNT_TYP_DESC")
	private String evntTypDesc;

	@LastModifiedBy
	@Column(name="UPDATED_BY")
	private String updatedBy;

	@LastModifiedDate
	@Column(name="UPDATED_DTM")
	private Date updatedDtm;

	public EvntTypLkup() {
	}

	public long getEvntLkupId() {
		return this.evntLkupId;
	}

	public void setEvntLkupId(long evntLkupId) {
		this.evntLkupId = evntLkupId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDtm() {
		return this.createdDtm;
	}

	public void setCreatedDtm(Date createdDtm) {
		this.createdDtm = createdDtm;
	}

	public String getEvntStatus() {
		return this.evntStatus;
	}

	public void setEvntStatus(String evntStatus) {
		this.evntStatus = evntStatus;
	}

	public String getEvntTypCd() {
		return this.evntTypCd;
	}

	public void setEvntTypCd(String evntTypCd) {
		this.evntTypCd = evntTypCd;
	}

	public String getEvntTypDesc() {
		return this.evntTypDesc;
	}

	public void setEvntTypDesc(String evntTypDesc) {
		this.evntTypDesc = evntTypDesc;
	}

	public String getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDtm() {
		return this.updatedDtm;
	}

	public void setUpdatedDtm(Date updatedDtm) {
		this.updatedDtm = updatedDtm;
	}

}