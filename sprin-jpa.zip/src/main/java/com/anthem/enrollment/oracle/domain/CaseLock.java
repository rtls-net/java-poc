package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the CASE_LOCK database table.
 * @author Deloitte
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="CASE_LOCK")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CaseLock implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CASE_LOCK_ID")
	private long caseLockId;

	@Column(name="CASE_NBR")
	private String caseNbr;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="END_TIME")
	private Timestamp endTime;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LOCK_STTS")
	private String lockStts;

	@Column(name="LOCKD_BY_PRFL")
	private String lockdByPrfl;

	@Column(name="LOCKD_BY_USER")
	private String lockdByUser;

	@Column(name="LOCKED_BY_ENTY")
	private String lockedByEnty;

	@Column(name="STRT_TIME")
	private Timestamp strtTime;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	public CaseLock() {
	}

	public long getCaseLockId() {
		return this.caseLockId;
	}

	public void setCaseLockId(long caseLockId) {
		this.caseLockId = caseLockId;
	}

	public String getCaseNbr() {
		return this.caseNbr;
	}

	public void setCaseNbr(String caseNbr) {
		this.caseNbr = caseNbr;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Timestamp getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLockStts() {
		return this.lockStts;
	}

	public void setLockStts(String lockStts) {
		this.lockStts = lockStts;
	}

	public String getLockdByPrfl() {
		return this.lockdByPrfl;
	}

	public void setLockdByPrfl(String lockdByPrfl) {
		this.lockdByPrfl = lockdByPrfl;
	}

	public String getLockdByUser() {
		return this.lockdByUser;
	}

	public void setLockdByUser(String lockdByUser) {
		this.lockdByUser = lockdByUser;
	}

	public String getLockedByEnty() {
		return this.lockedByEnty;
	}

	public void setLockedByEnty(String lockedByEnty) {
		this.lockedByEnty = lockedByEnty;
	}

	public Timestamp getStrtTime() {
		return this.strtTime;
	}

	public void setStrtTime(Timestamp strtTime) {
		this.strtTime = strtTime;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}