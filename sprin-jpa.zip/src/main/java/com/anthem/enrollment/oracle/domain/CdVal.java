package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CD_VAL database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CD_VAL")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CdVal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CD_VAL_ID")
	private long cdValId;

	@Column(name="CD_VAL_CD")
	private String cdValCd;

	@Column(name="CD_VAL_NM")
	private String cdValNm;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="DSPLY_SQNC_NBR")
	private BigDecimal dsplySqncNbr;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="LFCYCL_STTS_CD")
	private String lfcyclSttsCd;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_EFCTV_DT")
	private Date lfcyclSttsEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="LFCYCL_STTS_TRMNTN_DT")
	private Date lfcyclSttsTrmntnDt;

	@Column(name="LONG_DESC_TXT")
	private String longDescTxt;

	@Column(name="SHRT_DESC_TXT")
	private String shrtDescTxt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr;

	//bi-directional many-to-one association to RfrncDataItem
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RFRNC_DATA_ITEM_ID")
	private RfrncDataItem rfrncDataItem;

	//bi-directional many-to-one association to CdValFltr
	@JsonIgnore
	@OneToMany(mappedBy="cdVal1")
	private List<CdValFltr> cdValFltrs1;

	//bi-directional many-to-one association to CdValFltr
	@JsonIgnore
	@OneToMany(mappedBy="cdVal2")
	private List<CdValFltr> cdValFltrs2;

	//bi-directional many-to-one association to RfrncDataItemAddnlAtrbVal
	@JsonIgnore
	@OneToMany(mappedBy="cdVal")
	private List<RfrncDataItemAddnlAtrbVal> rfrncDataItemAddnlAtrbVals;

	public CdVal() {
	}

	public long getCdValId() {
		return this.cdValId;
	}

	public void setCdValId(long cdValId) {
		this.cdValId = cdValId;
	}

	public String getCdValCd() {
		return this.cdValCd;
	}

	public void setCdValCd(String cdValCd) {
		this.cdValCd = cdValCd;
	}

	public String getCdValNm() {
		return this.cdValNm;
	}

	public void setCdValNm(String cdValNm) {
		this.cdValNm = cdValNm;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getDsplySqncNbr() {
		return this.dsplySqncNbr;
	}

	public void setDsplySqncNbr(BigDecimal dsplySqncNbr) {
		this.dsplySqncNbr = dsplySqncNbr;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLfcyclSttsCd() {
		return this.lfcyclSttsCd;
	}

	public void setLfcyclSttsCd(String lfcyclSttsCd) {
		this.lfcyclSttsCd = lfcyclSttsCd;
	}

	public Date getLfcyclSttsEfctvDt() {
		return this.lfcyclSttsEfctvDt;
	}

	public void setLfcyclSttsEfctvDt(Date lfcyclSttsEfctvDt) {
		this.lfcyclSttsEfctvDt = lfcyclSttsEfctvDt;
	}

	public Date getLfcyclSttsTrmntnDt() {
		return this.lfcyclSttsTrmntnDt;
	}

	public void setLfcyclSttsTrmntnDt(Date lfcyclSttsTrmntnDt) {
		this.lfcyclSttsTrmntnDt = lfcyclSttsTrmntnDt;
	}

	public String getLongDescTxt() {
		return this.longDescTxt;
	}

	public void setLongDescTxt(String longDescTxt) {
		this.longDescTxt = longDescTxt;
	}

	public String getShrtDescTxt() {
		return this.shrtDescTxt;
	}

	public void setShrtDescTxt(String shrtDescTxt) {
		this.shrtDescTxt = shrtDescTxt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public RfrncDataItem getRfrncDataItem() {
		return this.rfrncDataItem;
	}

	public void setRfrncDataItem(RfrncDataItem rfrncDataItem) {
		this.rfrncDataItem = rfrncDataItem;
	}

	public List<CdValFltr> getCdValFltrs1() {
		return this.cdValFltrs1;
	}

	public void setCdValFltrs1(List<CdValFltr> cdValFltrs1) {
		this.cdValFltrs1 = cdValFltrs1;
	}

	public CdValFltr addCdValFltrs1(CdValFltr cdValFltrs1) {
		getCdValFltrs1().add(cdValFltrs1);
		cdValFltrs1.setCdVal1(this);

		return cdValFltrs1;
	}

	public CdValFltr removeCdValFltrs1(CdValFltr cdValFltrs1) {
		getCdValFltrs1().remove(cdValFltrs1);
		cdValFltrs1.setCdVal1(null);

		return cdValFltrs1;
	}

	public List<CdValFltr> getCdValFltrs2() {
		return this.cdValFltrs2;
	}

	public void setCdValFltrs2(List<CdValFltr> cdValFltrs2) {
		this.cdValFltrs2 = cdValFltrs2;
	}

	public CdValFltr addCdValFltrs2(CdValFltr cdValFltrs2) {
		getCdValFltrs2().add(cdValFltrs2);
		cdValFltrs2.setCdVal2(this);

		return cdValFltrs2;
	}

	public CdValFltr removeCdValFltrs2(CdValFltr cdValFltrs2) {
		getCdValFltrs2().remove(cdValFltrs2);
		cdValFltrs2.setCdVal2(null);

		return cdValFltrs2;
	}

	public List<RfrncDataItemAddnlAtrbVal> getRfrncDataItemAddnlAtrbVals() {
		return this.rfrncDataItemAddnlAtrbVals;
	}

	public void setRfrncDataItemAddnlAtrbVals(List<RfrncDataItemAddnlAtrbVal> rfrncDataItemAddnlAtrbVals) {
		this.rfrncDataItemAddnlAtrbVals = rfrncDataItemAddnlAtrbVals;
	}

	public RfrncDataItemAddnlAtrbVal addRfrncDataItemAddnlAtrbVal(RfrncDataItemAddnlAtrbVal rfrncDataItemAddnlAtrbVal) {
		getRfrncDataItemAddnlAtrbVals().add(rfrncDataItemAddnlAtrbVal);
		rfrncDataItemAddnlAtrbVal.setCdVal(this);

		return rfrncDataItemAddnlAtrbVal;
	}

	public RfrncDataItemAddnlAtrbVal removeRfrncDataItemAddnlAtrbVal(RfrncDataItemAddnlAtrbVal rfrncDataItemAddnlAtrbVal) {
		getRfrncDataItemAddnlAtrbVals().remove(rfrncDataItemAddnlAtrbVal);
		rfrncDataItemAddnlAtrbVal.setCdVal(null);

		return rfrncDataItemAddnlAtrbVal;
	}

}