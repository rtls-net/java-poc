package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the CNTRCT database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
@Table(name="CNTRCT")
public class CntrctDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue( strategy=GenerationType.SEQUENCE)
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	@Column(name = "CNTRCT_ID")
	private Long cntrctId;

	@Column(name = "ALT_NTWK_CD")
	private String altNtwkCd;

	@Column(name = "CLM_RTE_CD")
	private String clmRteCd;

	@Column(name = "CLM_TPA_ID")
	private BigDecimal clmTpaId;

	@Column(name = "CNCL_CNTRL_TYPE_CD")
	private String cnclCntrlTypeCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_EFCTV_DT")
	private Date cntrctEfctvDt;

	@Column(name = "CNTRCT_OWNR_TYPE_CD")
	private String cntrctOwnrTypeCd;

	@Column(name = "CNTRCT_STTS_CD")
	private String cntrctSttsCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_TRMNTN_DT")
	private Date cntrctTrmntnDt;

	@Column(name = "CNTRCT_TRMNTN_RSN_CD")
	private String cntrctTrmntnRsnCd;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "CUST_PLCY_NBR")
	private BigDecimal custPlcyNbr;

	@Column(name = "CVRD_DPNDNT_CNT")
	private BigDecimal cvrdDpndntCnt;

	@Column(name = "CVRD_SBSCRBR_CNT")
	private BigDecimal cvrdSbscrbrCnt;

	@Column(name = "GRP_HLTH_INSRNC_CTGRY_CD")
	private String grpHlthInsrncCtgryCd;

	@Column(name = "HA_PRCS_DTM")
	private Timestamp haPrcsDtm;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "LGCY_CMPNY_CF_CD")
	private String lgcyCmpnyCfCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "LGCY_CMPNY_CF_CD_EFCTV_DT")
	private Date lgcyCmpnyCfCdEfctvDt;

	@Column(name = "LGCY_CNTRCT_CD")
	private String lgcyCntrctCd;

	@Column(name = "LGCY_GRP_NBR")
	private String lgcyGrpNbr;

	@Column(name = "LGCY_SFX_NBR")
	private String lgcySfxNbr;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "MEDCALL_EFCTV_DT")
	private Date medcallEfctvDt;

	@Column(name = "MEDCALL_IND_CD")
	private String medcallIndCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "ORGNL_CNTRCT_EFCTV_DT")
	private Date orgnlCntrctEfctvDt;
	
	/*@JsonIgnore
	@OneToOne(mappedBy = "cntrctDetail", cascade = CascadeType.ALL)
	private CntrctPlanDetails cntrctPlanDetail;*/

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name = "grp_id")
	private Long grpId;

	

	@Column(name = "FUND_TYPE")
	private String fundType;

	@Column(name = "EMPLR_IDFCTN_NBR")
	private String ein;

	@Column(name = "WGS_UPDATE")
	private String wgsUpdate;



	@Column(name = "MASS_GRP_TRNFR_NEW_GRP_SFX_NBR")
	private String massgrpTrnfrnewGrpsfxn;
	
	@Column(name = "MASS_GRP_TRNFR_NEW_GRP_EFF_DT")
	private Date massgrpTrnfrnewGrpEffdt;

	public Date getMassgrpTrnfrnewGrpEffdt() {
		return massgrpTrnfrnewGrpEffdt;
	}

	public void setMassgrpTrnfrnewGrpEffdt(Date massgrpTrnfrnewGrpEffdt) {
		this.massgrpTrnfrnewGrpEffdt = massgrpTrnfrnewGrpEffdt;
	}

	public String getMassgrpTrnfrnewGrpsfxn() {
		return massgrpTrnfrnewGrpsfxn;
	}

	public void setMassgrpTrnfrnewGrpsfxn(String massgrpTrnfrnewGrpsfxn) {
		this.massgrpTrnfrnewGrpsfxn = massgrpTrnfrnewGrpsfxn;
	}

	

	

	public Long getCntrctId() {
		return this.cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	public String getAltNtwkCd() {
		return this.altNtwkCd;
	}

	public void setAltNtwkCd(String altNtwkCd) {
		this.altNtwkCd = altNtwkCd;
	}

	public String getClmRteCd() {
		return this.clmRteCd;
	}

	public void setClmRteCd(String clmRteCd) {
		this.clmRteCd = clmRteCd;
	}

	public BigDecimal getClmTpaId() {
		return this.clmTpaId;
	}

	public void setClmTpaId(BigDecimal clmTpaId) {
		this.clmTpaId = clmTpaId;
	}

	public String getCnclCntrlTypeCd() {
		return this.cnclCntrlTypeCd;
	}

	public void setCnclCntrlTypeCd(String cnclCntrlTypeCd) {
		this.cnclCntrlTypeCd = cnclCntrlTypeCd;
	}

	public Date getCntrctEfctvDt() {
		return this.cntrctEfctvDt;
	}

	public void setCntrctEfctvDt(Date cntrctEfctvDt) {
		this.cntrctEfctvDt = cntrctEfctvDt;
	}

	public String getCntrctOwnrTypeCd() {
		return this.cntrctOwnrTypeCd;
	}

	public void setCntrctOwnrTypeCd(String cntrctOwnrTypeCd) {
		this.cntrctOwnrTypeCd = cntrctOwnrTypeCd;
	}

	public String getCntrctSttsCd() {
		return this.cntrctSttsCd;
	}

	public void setCntrctSttsCd(String cntrctSttsCd) {
		this.cntrctSttsCd = cntrctSttsCd;
	}

	public Date getCntrctTrmntnDt() {
		return this.cntrctTrmntnDt;
	}

	public void setCntrctTrmntnDt(Date cntrctTrmntnDt) {
		this.cntrctTrmntnDt = cntrctTrmntnDt;
	}

	public String getCntrctTrmntnRsnCd() {
		return this.cntrctTrmntnRsnCd;
	}

	public void setCntrctTrmntnRsnCd(String cntrctTrmntnRsnCd) {
		this.cntrctTrmntnRsnCd = cntrctTrmntnRsnCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getCustPlcyNbr() {
		return this.custPlcyNbr;
	}

	public void setCustPlcyNbr(BigDecimal custPlcyNbr) {
		this.custPlcyNbr = custPlcyNbr;
	}

	public BigDecimal getCvrdDpndntCnt() {
		return this.cvrdDpndntCnt;
	}

	public void setCvrdDpndntCnt(BigDecimal cvrdDpndntCnt) {
		this.cvrdDpndntCnt = cvrdDpndntCnt;
	}

	public BigDecimal getCvrdSbscrbrCnt() {
		return this.cvrdSbscrbrCnt;
	}

	public void setCvrdSbscrbrCnt(BigDecimal cvrdSbscrbrCnt) {
		this.cvrdSbscrbrCnt = cvrdSbscrbrCnt;
	}

	public String getGrpHlthInsrncCtgryCd() {
		return this.grpHlthInsrncCtgryCd;
	}

	public void setGrpHlthInsrncCtgryCd(String grpHlthInsrncCtgryCd) {
		this.grpHlthInsrncCtgryCd = grpHlthInsrncCtgryCd;
	}

	public Timestamp getHaPrcsDtm() {
		return this.haPrcsDtm;
	}

	public void setHaPrcsDtm(Timestamp haPrcsDtm) {
		this.haPrcsDtm = haPrcsDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLgcyCmpnyCfCd() {
		return this.lgcyCmpnyCfCd;
	}

	public void setLgcyCmpnyCfCd(String lgcyCmpnyCfCd) {
		this.lgcyCmpnyCfCd = lgcyCmpnyCfCd;
	}

	public Date getLgcyCmpnyCfCdEfctvDt() {
		return this.lgcyCmpnyCfCdEfctvDt;
	}

	public void setLgcyCmpnyCfCdEfctvDt(Date lgcyCmpnyCfCdEfctvDt) {
		this.lgcyCmpnyCfCdEfctvDt = lgcyCmpnyCfCdEfctvDt;
	}

	public String getLgcyCntrctCd() {
		return this.lgcyCntrctCd;
	}

	public void setLgcyCntrctCd(String lgcyCntrctCd) {
		this.lgcyCntrctCd = lgcyCntrctCd;
	}

	public String getLgcyGrpNbr() {
		return this.lgcyGrpNbr;
	}

	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}

	public String getLgcySfxNbr() {
		return this.lgcySfxNbr;
	}

	public void setLgcySfxNbr(String lgcySfxNbr) {
		this.lgcySfxNbr = lgcySfxNbr;
	}

	public Date getMedcallEfctvDt() {
		return this.medcallEfctvDt;
	}

	public void setMedcallEfctvDt(Date medcallEfctvDt) {
		this.medcallEfctvDt = medcallEfctvDt;
	}

	public String getMedcallIndCd() {
		return this.medcallIndCd;
	}

	public void setMedcallIndCd(String medcallIndCd) {
		this.medcallIndCd = medcallIndCd;
	}

	public Date getOrgnlCntrctEfctvDt() {
		return this.orgnlCntrctEfctvDt;
	}

	public void setOrgnlCntrctEfctvDt(Date orgnlCntrctEfctvDt) {
		this.orgnlCntrctEfctvDt = orgnlCntrctEfctvDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	

	

	

	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	public String getEin() {
		return ein;
	}

	public void setEin(String ein) {
		this.ein = ein;
	}

	

	public Long getGrpId() {
		return grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}

	public String getWgsUpdate() {
		return wgsUpdate;
	}

	public void setWgsUpdate(String wgsUpdate) {
		this.wgsUpdate = wgsUpdate;
	}

	/*public CntrctPlanDetails getCntrctPlanDetail() {
		return cntrctPlanDetail;
	}

	public void setCntrctPlanDetail(CntrctPlanDetails cntrctPlanDetail) {
		this.cntrctPlanDetail = cntrctPlanDetail;
	}*/

	

	

	
}
/*public interface CntrctDetails {
	public Long getCntrctId();
	public String getGrpId() ;
	public String getLgcyGrpNbr();
	
	public Date getMassgrpTrnfrnewGrpEffdt();
	public String getMassgrpTrnfrnewGrpsfxn();
	public String getAltNtwkCd();
	public String getClmRteCd();
	public BigDecimal getClmTpaId();
	public String getCnclCntrlTypeCd();
	public Date getCntrctEfctvDt();
	public String getCntrctOwnrTypeCd();
	public String getCntrctSttsCd();
	public Date getCntrctTrmntnDt();
	public String getCntrctTrmntnRsnCd();
	public String getCreatdByUserId();
	public Date getCreatdDtm();
	public BigDecimal getCustPlcyNbr();
	public BigDecimal getCvrdDpndntCnt();
	public BigDecimal getCvrdSbscrbrCnt();
	public String getGrpHlthInsrncCtgryCd();
	public Timestamp getHaPrcsDtm();
	public String getLastUpdtdByUserId();
	public Date getLastUpdtdDtm();
	public String getLgcyCmpnyCfCd();
	public Date getLgcyCmpnyCfCdEfctvDt();
	public String getLgcyCntrctCd();
	public String getLgcySfxNbr();
	public Date getMedcallEfctvDt();
	public String getMedcallIndCd();
	public Date getOrgnlCntrctEfctvDt();
	public Long getVrsnNbr();
	public String getFundType();
	public String getEin();
	public String getWgsUpdate();
	public Long getldProdId();
	public String getGrpQuotId();
	public String getPrmptpay();
	public String getPrmptpayefctvdt();

	MASS_GRP_TRNFR_NEW_GRP_EFF_DT As massgrpTrnfrnewGrpEffdt,MASS_GRP_TRNFR_NEW_GRP_SFX_NBR AS massgrpTrnfrnewGrpsfxn,ALT_NTWK_CD AS altNtwkCd,LD_PROD_LD AS ldProdId,
	CLM_RTE_CD as clmRteCd,CLM_TPA_ID as clmTpaId,CNCL_CNTRL_TYPE_CD as cnclCntrlTypeCd,CNTRCT_EFCTV_DT as cntrctEfctvDt,GRP_QUOT_ID As grpQuotId,FUND_TYPE As fundType,PRMPT_PAY As Prmptpay,
	 PRMPT_PAY_EFCTV_DT As Prmptpayefctvdt,EMPLR_IDFCTN_NBR as ein,WGS_UPDATE as wgsupdate,
	VRSN_NBR as vrsnNbr,ORGNL_CNTRCT_EFCTV_DT as OrgnlCntrctEfctvDt,
	 CNTRCT_STTS_CD as cntrctSttsCd,CNTRCT_TRMNTN_DT as cntrctTrmntnDt,CNTRCT_TRMNTN_RSN_CD as cntrctTrmntnRsnCd, 
	CNTRCT_OWNR_TYPE_CD as CntrctOwnrTypeCd,CVRD_SBSCRBR_CNT as CvrdSbscrbrCnt,CVRD_DPNDNT_CNT as CvrdDpndntCnt,CUST_PLCY_NBR as CustPlcyNbr, 
	LGCY_SFX_NBR as LgcySfxNbr,LGCY_CNTRCT_CD as LgcyCntrctCd,MEDCALL_IND_CD as MedcallIndCd,MEDCALL_EFCTV_DT as MedcallEfctvDt,
	LGCY_CMPNY_CF_CD_EFCTV_DT as LgcyCmpnyCfCdEfctvDt,LGCY_CMPNY_CF_CD as LgcyCmpnyCfCd,HA_PRCS_DTM as HaPrcsDtm,
	GRP_HLTH_INSRNC_CTGRY_CD as GrpHlthInsrncCtgryCd,CREATD_BY_USER_ID as CreatdByUserId,
	CREATD_DTM as CreatdDtm,LAST_UPDTD_BY_USER_ID as LastUpdtdByUserId,LAST_UPDTD_DTM as LastUpdtdDtm 
	
	
	
	private Long cntrctId;
	private String grpId;
	private String lgcyGrpNbr;
	public Long getCntrctId() {
		return cntrctId;
	}
	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}
	public String getGrpId() {
		return grpId;
	}
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	public String getLgcyGrpNbr() {
		return lgcyGrpNbr;
	}
	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}
	public CntrctDetails(Long cntrctId, String grpId, String lgcyGrpNbr) {
		super();
		this.cntrctId = cntrctId;
		this.grpId = grpId;
		this.lgcyGrpNbr = lgcyGrpNbr;
	}
	
}*/
