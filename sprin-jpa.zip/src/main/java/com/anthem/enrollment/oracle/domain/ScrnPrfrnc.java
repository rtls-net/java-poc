package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the SCRN_PRFRNC database table.
 * 
 */
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="SCRN_PRFRNC")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScrnPrfrnc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SCRN_CNFGRN_ID")
	private long scrnCnfgrnId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="SCRN_EFCTV_DT")
	private Date scrnEfctvDt;

	@Column(name="SCRN_ID")
	private BigDecimal scrnId;

	@Column(name="SCRN_NM")
	private String scrnNm;

	@Temporal(TemporalType.DATE)
	@Column(name="SCRN_TRMNTN_DT")
	private Date scrnTrmntnDt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to ScrnFldPrfrnc
	@JsonIgnore
	@OneToMany(mappedBy="scrnPrfrnc")
	private List<ScrnFldPrfrnc> scrnFldPrfrncs;

	public ScrnPrfrnc() {
	}

	public long getScrnCnfgrnId() {
		return this.scrnCnfgrnId;
	}

	public void setScrnCnfgrnId(long scrnCnfgrnId) {
		this.scrnCnfgrnId = scrnCnfgrnId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Date getScrnEfctvDt() {
		return this.scrnEfctvDt;
	}

	public void setScrnEfctvDt(Date scrnEfctvDt) {
		this.scrnEfctvDt = scrnEfctvDt;
	}

	public BigDecimal getScrnId() {
		return this.scrnId;
	}

	public void setScrnId(BigDecimal scrnId) {
		this.scrnId = scrnId;
	}

	public String getScrnNm() {
		return this.scrnNm;
	}

	public void setScrnNm(String scrnNm) {
		this.scrnNm = scrnNm;
	}

	public Date getScrnTrmntnDt() {
		return this.scrnTrmntnDt;
	}

	public void setScrnTrmntnDt(Date scrnTrmntnDt) {
		this.scrnTrmntnDt = scrnTrmntnDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public List<ScrnFldPrfrnc> getScrnFldPrfrncs() {
		return this.scrnFldPrfrncs;
	}

	public void setScrnFldPrfrncs(List<ScrnFldPrfrnc> scrnFldPrfrncs) {
		this.scrnFldPrfrncs = scrnFldPrfrncs;
	}

	public ScrnFldPrfrnc addScrnFldPrfrnc(ScrnFldPrfrnc scrnFldPrfrnc) {
		getScrnFldPrfrncs().add(scrnFldPrfrnc);
		scrnFldPrfrnc.setScrnPrfrnc(this);

		return scrnFldPrfrnc;
	}

	public ScrnFldPrfrnc removeScrnFldPrfrnc(ScrnFldPrfrnc scrnFldPrfrnc) {
		getScrnFldPrfrncs().remove(scrnFldPrfrnc);
		scrnFldPrfrnc.setScrnPrfrnc(null);

		return scrnFldPrfrnc;
	}

}