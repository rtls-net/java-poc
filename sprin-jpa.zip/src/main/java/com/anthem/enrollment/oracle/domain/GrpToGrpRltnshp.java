package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the GRP_TO_GRP_RLTNSHP database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_TO_GRP_RLTNSHP")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class GrpToGrpRltnshp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_TO_GRP_RLTNSHP_ID")
	private long grpToGrpRltnshpId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	//@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Column(name="GRP_RLTNSHP_EFCTV_DT")
	private Date grpRltnshpEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name="GRP_RLTNSHP_TRMNTN_DT")
	private Date grpRltnshpTrmntnDt;

	@Column(name="GRP_RLTNSHP_TYPE_CD")
	private String grpRltnshpTypeCd;
	
	@Column(name="CS_IND_CSTM_ID_CARD_IND")
	private String customIdCard;
	
    public String getCustomIdCard() {
		return customIdCard;
	}

	public void setCustomIdCard(String customIdCard) {
		this.customIdCard = customIdCard;
	}

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="PARNT_GRP_ID")
	private Grp grp1;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="GRP_ID")
	private Grp grp2;
	
	@JsonIgnore
	@Column(name="PARNT_GRP_ID", insertable = false, updatable = false)
	private BigDecimal parntGrpId;
	
	@Column(name="GRP_ID", insertable = false, updatable = false)
	private BigDecimal grpId;

	public GrpToGrpRltnshp() {
	}

	public long getGrpToGrpRltnshpId() {
		return this.grpToGrpRltnshpId;
	}

	public void setGrpToGrpRltnshpId(long grpToGrpRltnshpId) {
		this.grpToGrpRltnshpId = grpToGrpRltnshpId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpRltnshpEfctvDt() {
		return this.grpRltnshpEfctvDt;
	}

	public void setGrpRltnshpEfctvDt(Date grpRltnshpEfctvDt) {
		this.grpRltnshpEfctvDt = grpRltnshpEfctvDt;
	}

	public Date getGrpRltnshpTrmntnDt() {
		return this.grpRltnshpTrmntnDt;
	}

	public void setGrpRltnshpTrmntnDt(Date grpRltnshpTrmntnDt) {
		this.grpRltnshpTrmntnDt = grpRltnshpTrmntnDt;
	}

	public String getGrpRltnshpTypeCd() {
		return this.grpRltnshpTypeCd;
	}

	public void setGrpRltnshpTypeCd(String grpRltnshpTypeCd) {
		this.grpRltnshpTypeCd = grpRltnshpTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp1() {
		return this.grp1;
	}

	public void setGrp1(Grp grp1) {
		this.grp1 = grp1;
	}

	public Grp getGrp2() {
		return this.grp2;
	}

	public void setGrp2(Grp grp2) {
		this.grp2 = grp2;
	}

	public BigDecimal getParntGrpId() {
		return parntGrpId;
	}

	public void setParntGrpId(BigDecimal parntGrpId) {
		this.parntGrpId = parntGrpId;
	}

	public BigDecimal getGrpId() {
		return grpId;
	}

	public void setGrpId(BigDecimal grpId) {
		this.grpId = grpId;
	}

	
}