package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Date;


/**
 * The persistent class for the CNTRCT_PLAN_RT_FACTORS database table.
 * 
 */
@Entity
@Table(name="CNTRCT_PLAN_RT_FACTORS")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctPlanRtFactor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CNTRCT_PLAN_RT_ID")
	private Long cntrctPlanRtId;

	@Column(name="AGE_BRCKT_JSON")
	private String ageBrcktJson;

	@Column(name="CHILD_FLAT_RT")
	private String childFlatRt;

	@Column(name="COMPST_RT")
	private String compstRt;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_END_DT")
	private Date effEndDt;

	@Temporal(TemporalType.DATE)
	@Column(name="EFF_START_DT")
	private Date effStartDt;

	@Column(name="SPOUSE_FLAT_RT")
	private String spouseFlatRt;

	@Column(name="STATUS_CD")
	private String statusCd;

	public CntrctPlanRtFactor() {
	}

	public Long getCntrctPlanRtId() {
		return this.cntrctPlanRtId;
	}

	public void setCntrctPlanRtId(Long cntrctPlanRtId) {
		this.cntrctPlanRtId = cntrctPlanRtId;
	}

	public String getAgeBrcktJson() {
		return this.ageBrcktJson;
	}

	public void setAgeBrcktJson(String ageBrcktJson) {
		this.ageBrcktJson = ageBrcktJson;
	}

	public String getChildFlatRt() {
		return this.childFlatRt;
	}

	public void setChildFlatRt(String childFlatRt) {
		this.childFlatRt = childFlatRt;
	}

	public String getCompstRt() {
		return this.compstRt;
	}

	public void setCompstRt(String compstRt) {
		this.compstRt = compstRt;
	}

	public Date getEffEndDt() {
		return this.effEndDt;
	}

	public void setEffEndDt(Date effEndDt) {
		this.effEndDt = effEndDt;
	}

	public Date getEffStartDt() {
		return this.effStartDt;
	}

	public void setEffStartDt(Date effStartDt) {
		this.effStartDt = effStartDt;
	}

	public String getSpouseFlatRt() {
		return this.spouseFlatRt;
	}

	public void setSpouseFlatRt(String spouseFlatRt) {
		this.spouseFlatRt = spouseFlatRt;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}