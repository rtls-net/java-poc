package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the CNTRCT_PLAN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTRCT_PLAN_PROV_NTWK")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctPlanProvNtwkDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CNTRCT_PLAN_PROV_NTWK_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctPlanProvNtwkId;

	//@Column(name="CNTRCT_PLAN_ID")
	//private Long cntrctPlanId;

	@Column(name="CNTRCT_PLAN_CD")
	private String cntrctPlanCd;

//	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_PLAN_EFCTV_DT")
	private Date cntrctPlanEfctvDt;

	@Column(name="CNTRCT_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctId;

//	@Temporal(TemporalType.DATE)
	@Column(name="NTWK_ID")
	private String ntwkId;

	@Column(name="CNTRCT_PLAN_NTWK_TRMNTN_DT")
	private Date cntrctPlanNtwkTrmntnDt;

	@Column(name="CNTRCT_PLAN_PROV_NTWK_EFCTV_DT")
	private Date cntrctPlanProvNtwkEfctvDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	/*//bi-directional many-to-one association to Cntrct Plan
	 @JsonIgnore
	 @OneToOne(fetch=FetchType.LAZY)
	 @JoinColumn(name="CNTRCT_PLAN_ID") 
	 private CntrctPlan cntrctPlan;*/
	
	@Column(name="CNTRCT_PLAN_ID")
	private Long cntrctPlanId;
	 
	
	

	public Long getCntrctPlanId() {
		return cntrctPlanId;
	}

	public void setCntrctPlanId(Long cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	/*
	 * public Cntrct getCntrct() { return this.cntrct; }
	 * 
	 * public void setCntrct(Cntrct cntrct) { this.cntrct = cntrct; }
	 */

	public Long getCntrctPlanProvNtwkId() {
		return cntrctPlanProvNtwkId;
	}

	public void setCntrctPlanProvNtwkId(Long cntrctPlanProvNtwkId) {
		this.cntrctPlanProvNtwkId = cntrctPlanProvNtwkId;
	}

	public String getCntrctPlanCd() {
		return cntrctPlanCd;
	}

	public void setCntrctPlanCd(String cntrctPlanCd) {
		this.cntrctPlanCd = cntrctPlanCd;
	}

	public Date getCntrctPlanEfctvDt() {
		return cntrctPlanEfctvDt;
	}

	public void setCntrctPlanEfctvDt(Date cntrctPlanEfctvDt) {
		this.cntrctPlanEfctvDt = cntrctPlanEfctvDt;
	}

	public String getNtwkId() {
		return ntwkId;
	}

	public void setNtwkId(String ntwkId) {
		this.ntwkId = ntwkId;
	}

	public Date getCntrctPlanNtwkTrmntnDt() {
		return cntrctPlanNtwkTrmntnDt;
	}

	public void setCntrctPlanNtwkTrmntnDt(Date cntrctPlanNtwkTrmntnDt) {
		this.cntrctPlanNtwkTrmntnDt = cntrctPlanNtwkTrmntnDt;
	}

	public Date getCntrctPlanProvNtwkEfctvDt() {
		return cntrctPlanProvNtwkEfctvDt;
	}

	public void setCntrctPlanProvNtwkEfctvDt(Date cntrctPlanProvNtwkEfctvDt) {
		this.cntrctPlanProvNtwkEfctvDt = cntrctPlanProvNtwkEfctvDt;
	}

	/*public CntrctPlan getCntrctPlan() {
		return cntrctPlan;
	}

	public void setCntrctPlan(CntrctPlan cntrctPlan) {
		this.cntrctPlan = cntrctPlan;
	}*/

	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "CntrctPlanProvNtwk [cntrctPlanProvNtwkId=" + cntrctPlanProvNtwkId + ", cntrctPlanCd=" + cntrctPlanCd
				+ ", cntrctPlanEfctvDt=" + cntrctPlanEfctvDt + ", cntrctId=" + cntrctId + ", ntwkId=" + ntwkId
				+ ", cntrctPlanNtwkTrmntnDt=" + (cntrctPlanNtwkTrmntnDt!=null?formatter.format(cntrctPlanNtwkTrmntnDt):null) + ", cntrctPlanProvNtwkEfctvDt="
				+ (cntrctPlanProvNtwkEfctvDt!=null ?formatter.format(cntrctPlanProvNtwkEfctvDt):null) + ", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null) + ", vrsnNbr=" + vrsnNbr + "]";
	}

	
}