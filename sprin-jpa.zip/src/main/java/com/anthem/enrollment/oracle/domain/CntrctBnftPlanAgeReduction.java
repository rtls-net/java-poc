package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the CNTRCT_BNFT_PLAN_AGE_REDUCTION database table.
 * 
 */
@Entity
@Table(name = "CNTRCT_BNFT_PLAN_AGE_REDUCTION")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class CntrctBnftPlanAgeReduction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "BENEFITS_ID")
	private Long benefitsId;

	@Column(name = "AGE_OF_SUBS")
	private BigDecimal ageOfSubs;

	@Column(name = "BASE_CD")
	private String baseCd;

	@Column(name = "BRTHDT_COMP_MNTHS")
	private BigDecimal brthdtCompMnths;

	@Temporal(TemporalType.DATE)
	@Column(name = "EFF_END_DT")
	private Date effEndDt;

	@Temporal(TemporalType.DATE)
	@Column(name = "EFF_START_DT")
	private Date effStartDt;

	@Column(name = "MIN_AMT")
	private BigDecimal minAmt;

	@Column(name = "OCC_CD")
	private String occCd;

	private String per;

	@Column(name = "SPS_CUT_BK")
	private String spsCutBk;

	@Column(name = "STATUS_CD")
	private String statusCd;

	private String vol;

	// bi-directional many-to-one association to CntrctPlanSpclty
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_PLAN_SPCLTY_ID")
	private CntrctPlanSpclty cntrctPlanSpclty;

	public CntrctBnftPlanAgeReduction() {
	}

	public Long getBenefitsId() {
		return this.benefitsId;
	}

	public void setBenefitsId(Long benefitsId) {
		this.benefitsId = benefitsId;
	}

	public BigDecimal getAgeOfSubs() {
		return this.ageOfSubs;
	}

	public void setAgeOfSubs(BigDecimal ageOfSubs) {
		this.ageOfSubs = ageOfSubs;
	}

	public String getBaseCd() {
		return this.baseCd;
	}

	public void setBaseCd(String baseCd) {
		this.baseCd = baseCd;
	}

	public BigDecimal getBrthdtCompMnths() {
		return this.brthdtCompMnths;
	}

	public void setBrthdtCompMnths(BigDecimal brthdtCompMnths) {
		this.brthdtCompMnths = brthdtCompMnths;
	}

	public Date getEffEndDt() {
		return this.effEndDt;
	}

	public void setEffEndDt(Date effEndDt) {
		this.effEndDt = effEndDt;
	}

	public Date getEffStartDt() {
		return this.effStartDt;
	}

	public void setEffStartDt(Date effStartDt) {
		this.effStartDt = effStartDt;
	}

	public BigDecimal getMinAmt() {
		return this.minAmt;
	}

	public void setMinAmt(BigDecimal minAmt) {
		this.minAmt = minAmt;
	}

	public String getOccCd() {
		return this.occCd;
	}

	public void setOccCd(String occCd) {
		this.occCd = occCd;
	}

	public String getPer() {
		return this.per;
	}

	public void setPer(String per) {
		this.per = per;
	}

	public String getSpsCutBk() {
		return this.spsCutBk;
	}

	public void setSpsCutBk(String spsCutBk) {
		this.spsCutBk = spsCutBk;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public String getVol() {
		return this.vol;
	}

	public void setVol(String vol) {
		this.vol = vol;
	}

	public CntrctPlanSpclty getCntrctPlanSpclty() {
		return this.cntrctPlanSpclty;
	}

	public void setCntrctPlanSpclty(CntrctPlanSpclty cntrctPlanSpclty) {
		this.cntrctPlanSpclty = cntrctPlanSpclty;
	}

}