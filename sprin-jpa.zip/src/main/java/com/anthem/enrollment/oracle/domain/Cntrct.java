package com.anthem.enrollment.oracle.domain;

import com.anthem.enrollment.oracle.domain.GrpMnthlyCntrbtn;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the CNTRCT database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class Cntrct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	@Column(name = "CNTRCT_ID")
	private Long cntrctId;

	@Column(name = "ALT_NTWK_CD")
	private String altNtwkCd;

	@Column(name = "CLM_RTE_CD")
	private String clmRteCd;

	@Column(name = "CLM_TPA_ID")
	private BigDecimal clmTpaId;

	@Column(name = "CNCL_CNTRL_TYPE_CD")
	private String cnclCntrlTypeCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_EFCTV_DT")
	private Date cntrctEfctvDt;

	@Column(name = "CNTRCT_OWNR_TYPE_CD")
	private String cntrctOwnrTypeCd;

	@Column(name = "CNTRCT_STTS_CD")
	private String cntrctSttsCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "CNTRCT_TRMNTN_DT")
	private Date cntrctTrmntnDt;

	@Column(name = "CNTRCT_TRMNTN_RSN_CD")
	private String cntrctTrmntnRsnCd;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "CUST_PLCY_NBR")
	private BigDecimal custPlcyNbr;

	@Column(name = "CVRD_DPNDNT_CNT")
	private BigDecimal cvrdDpndntCnt;

	@Column(name = "CVRD_SBSCRBR_CNT")
	private BigDecimal cvrdSbscrbrCnt;

	@Column(name = "GRP_HLTH_INSRNC_CTGRY_CD")
	private String grpHlthInsrncCtgryCd;

	@Column(name = "HA_PRCS_DTM")
	private Timestamp haPrcsDtm;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "LGCY_CMPNY_CF_CD")
	private String lgcyCmpnyCfCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "LGCY_CMPNY_CF_CD_EFCTV_DT")
	private Date lgcyCmpnyCfCdEfctvDt;

	@Column(name = "LGCY_CNTRCT_CD")
	private String lgcyCntrctCd;

	@Column(name = "LGCY_GRP_NBR")
	private String lgcyGrpNbr;

	@Column(name = "LGCY_SFX_NBR")
	private String lgcySfxNbr;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "MEDCALL_EFCTV_DT")
	private Date medcallEfctvDt;

	@Column(name = "MEDCALL_IND_CD")
	private String medcallIndCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone="PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "ORGNL_CNTRCT_EFCTV_DT")
	private Date orgnlCntrctEfctvDt;

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	// bi-directional many-to-one association to Grp
	// @JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GRP_ID")
	private Grp grp;

	
	@Column(name = "GRP_ID",insertable=false,updatable=false)
	private Long grpId;
	

	public Long getGrpId() {
		return grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}

	// bi-directional many-to-one association to CntrctBillgEnty
	@JsonIgnore
	@OneToMany(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private List<CntrctBillgEnty> cntrctBillgEnties;

	// bi-directional many-to-one association to CntrctPlan
	@JsonIgnore
	@OneToOne(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private CntrctPlan cntrctPlan;

	// bi-directional many-to-one association to GrpCntrctPrvsn
	@JsonIgnore
	@OneToOne(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private GrpCntrctPrvsn grpCntrctPrvsn;

	// bi-directional many-to-one association to LdProd
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LD_PROD_LD")
	private LdProd ldProd;

	// bi-directional many-to-one association to GrpQuot
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GRP_QUOT_ID")
	private GrpQuot grpQuot;

	// bi-directional many-to-one association to GrpPrbtnPrd
	@JsonIgnore
	@OneToMany(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private List<GrpPrbtnPrd> grpPrbtnPrds;

	@Column(name = "FUND_TYPE")
	private String fundType;

	@Column(name = "EMPLR_IDFCTN_NBR")
	private String ein;

	@Column(name = "WGS_UPDATE")
	private String wgsUpdate;

	// bi-directional many-to-one association to GrpMnthlyCntrbtn
	@OneToOne(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private GrpMnthlyCntrbtn grpMnthlyCntrbtn;

	@JsonIgnore
	@OneToOne(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private CntrctAdrs cntrctAdrs;

	@JsonIgnore
	@OneToOne(mappedBy = "cntrct", cascade = CascadeType.ALL)
	private CntrctTlphn cntrctTlphn;

	@Column(name = "MASS_GRP_TRNFR_NEW_GRP_SFX_NBR")
	private String massgrpTrnfrnewGrpsfxn;
	
	@Column(name = "MASS_GRP_TRNFR_NEW_GRP_EFF_DT")
	private Date massgrpTrnfrnewGrpEffdt;

	public Date getMassgrpTrnfrnewGrpEffdt() {
		return massgrpTrnfrnewGrpEffdt;
	}

	public void setMassgrpTrnfrnewGrpEffdt(Date massgrpTrnfrnewGrpEffdt) {
		this.massgrpTrnfrnewGrpEffdt = massgrpTrnfrnewGrpEffdt;
	}

	public String getMassgrpTrnfrnewGrpsfxn() {
		return massgrpTrnfrnewGrpsfxn;
	}

	public void setMassgrpTrnfrnewGrpsfxn(String massgrpTrnfrnewGrpsfxn) {
		this.massgrpTrnfrnewGrpsfxn = massgrpTrnfrnewGrpsfxn;
	}

	

	public Cntrct() {
	}

	public Long getCntrctId() {
		return this.cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	public String getAltNtwkCd() {
		return this.altNtwkCd;
	}

	public void setAltNtwkCd(String altNtwkCd) {
		this.altNtwkCd = altNtwkCd;
	}

	public String getClmRteCd() {
		return this.clmRteCd;
	}

	public void setClmRteCd(String clmRteCd) {
		this.clmRteCd = clmRteCd;
	}

	public BigDecimal getClmTpaId() {
		return this.clmTpaId;
	}

	public void setClmTpaId(BigDecimal clmTpaId) {
		this.clmTpaId = clmTpaId;
	}

	public String getCnclCntrlTypeCd() {
		return this.cnclCntrlTypeCd;
	}

	public void setCnclCntrlTypeCd(String cnclCntrlTypeCd) {
		this.cnclCntrlTypeCd = cnclCntrlTypeCd;
	}

	public Date getCntrctEfctvDt() {
		return this.cntrctEfctvDt;
	}

	public void setCntrctEfctvDt(Date cntrctEfctvDt) {
		this.cntrctEfctvDt = cntrctEfctvDt;
	}

	public String getCntrctOwnrTypeCd() {
		return this.cntrctOwnrTypeCd;
	}

	public void setCntrctOwnrTypeCd(String cntrctOwnrTypeCd) {
		this.cntrctOwnrTypeCd = cntrctOwnrTypeCd;
	}

	public String getCntrctSttsCd() {
		return this.cntrctSttsCd;
	}

	public void setCntrctSttsCd(String cntrctSttsCd) {
		this.cntrctSttsCd = cntrctSttsCd;
	}

	public Date getCntrctTrmntnDt() {
		return this.cntrctTrmntnDt;
	}

	public void setCntrctTrmntnDt(Date cntrctTrmntnDt) {
		this.cntrctTrmntnDt = cntrctTrmntnDt;
	}

	public String getCntrctTrmntnRsnCd() {
		return this.cntrctTrmntnRsnCd;
	}

	public void setCntrctTrmntnRsnCd(String cntrctTrmntnRsnCd) {
		this.cntrctTrmntnRsnCd = cntrctTrmntnRsnCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getCustPlcyNbr() {
		return this.custPlcyNbr;
	}

	public void setCustPlcyNbr(BigDecimal custPlcyNbr) {
		this.custPlcyNbr = custPlcyNbr;
	}

	public BigDecimal getCvrdDpndntCnt() {
		return this.cvrdDpndntCnt;
	}

	public void setCvrdDpndntCnt(BigDecimal cvrdDpndntCnt) {
		this.cvrdDpndntCnt = cvrdDpndntCnt;
	}

	public BigDecimal getCvrdSbscrbrCnt() {
		return this.cvrdSbscrbrCnt;
	}

	public void setCvrdSbscrbrCnt(BigDecimal cvrdSbscrbrCnt) {
		this.cvrdSbscrbrCnt = cvrdSbscrbrCnt;
	}

	public String getGrpHlthInsrncCtgryCd() {
		return this.grpHlthInsrncCtgryCd;
	}

	public void setGrpHlthInsrncCtgryCd(String grpHlthInsrncCtgryCd) {
		this.grpHlthInsrncCtgryCd = grpHlthInsrncCtgryCd;
	}

	public Timestamp getHaPrcsDtm() {
		return this.haPrcsDtm;
	}

	public void setHaPrcsDtm(Timestamp haPrcsDtm) {
		this.haPrcsDtm = haPrcsDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getLgcyCmpnyCfCd() {
		return this.lgcyCmpnyCfCd;
	}

	public void setLgcyCmpnyCfCd(String lgcyCmpnyCfCd) {
		this.lgcyCmpnyCfCd = lgcyCmpnyCfCd;
	}

	public Date getLgcyCmpnyCfCdEfctvDt() {
		return this.lgcyCmpnyCfCdEfctvDt;
	}

	public void setLgcyCmpnyCfCdEfctvDt(Date lgcyCmpnyCfCdEfctvDt) {
		this.lgcyCmpnyCfCdEfctvDt = lgcyCmpnyCfCdEfctvDt;
	}

	public String getLgcyCntrctCd() {
		return this.lgcyCntrctCd;
	}

	public void setLgcyCntrctCd(String lgcyCntrctCd) {
		this.lgcyCntrctCd = lgcyCntrctCd;
	}

	public String getLgcyGrpNbr() {
		return this.lgcyGrpNbr;
	}

	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}

	public String getLgcySfxNbr() {
		return this.lgcySfxNbr;
	}

	public void setLgcySfxNbr(String lgcySfxNbr) {
		this.lgcySfxNbr = lgcySfxNbr;
	}

	public Date getMedcallEfctvDt() {
		return this.medcallEfctvDt;
	}

	public void setMedcallEfctvDt(Date medcallEfctvDt) {
		this.medcallEfctvDt = medcallEfctvDt;
	}

	public String getMedcallIndCd() {
		return this.medcallIndCd;
	}

	public void setMedcallIndCd(String medcallIndCd) {
		this.medcallIndCd = medcallIndCd;
	}

	public Date getOrgnlCntrctEfctvDt() {
		return this.orgnlCntrctEfctvDt;
	}

	public void setOrgnlCntrctEfctvDt(Date orgnlCntrctEfctvDt) {
		this.orgnlCntrctEfctvDt = orgnlCntrctEfctvDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public List<CntrctBillgEnty> getCntrctBillgEnties() {
		return this.cntrctBillgEnties;
	}

	public void setCntrctBillgEnties(List<CntrctBillgEnty> cntrctBillgEnties) {
		this.cntrctBillgEnties = cntrctBillgEnties;
	}

	public CntrctBillgEnty addCntrctBillgEnty(CntrctBillgEnty cntrctBillgEnty) {
		getCntrctBillgEnties().add(cntrctBillgEnty);
		cntrctBillgEnty.setCntrct(this);

		return cntrctBillgEnty;
	}

	public CntrctBillgEnty removeCntrctBillgEnty(CntrctBillgEnty cntrctBillgEnty) {
		getCntrctBillgEnties().remove(cntrctBillgEnty);
		cntrctBillgEnty.setCntrct(null);

		return cntrctBillgEnty;
	}

	public CntrctPlan getCntrctPlan() {
		return this.cntrctPlan;
	}

	public void setCntrctPlans(CntrctPlan cntrctPlans) {
		this.cntrctPlan = cntrctPlans;
	}

	/**
	 * @return the grpCntrctPrvsn
	 */
	public GrpCntrctPrvsn getGrpCntrctPrvsn() {
		return grpCntrctPrvsn;
	}

	/**
	 * @param grpCntrctPrvsn the grpCntrctPrvsn to set
	 */
	public void setGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
		this.grpCntrctPrvsn = grpCntrctPrvsn;
	}

	/**
	 * @param cntrctPlan the cntrctPlan to set
	 */
	public void setCntrctPlan(CntrctPlan cntrctPlan) {
		this.cntrctPlan = cntrctPlan;
	}

	public LdProd getLdProd() {
		return this.ldProd;
	}

	public void setLdProd(LdProd ldProd) {
		this.ldProd = ldProd;
	}

	public GrpQuot getGrpQuot() {
		return this.grpQuot;
	}

	public void setGrpQuot(GrpQuot grpQuot) {
		this.grpQuot = grpQuot;
	}

	public List<GrpPrbtnPrd> getGrpPrbtnPrds() {
		return grpPrbtnPrds;
	}

	public void setGrpPrbtnPrds(List<GrpPrbtnPrd> grpPrbtnPrds) {
		this.grpPrbtnPrds = grpPrbtnPrds;
	}

	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	public String getEin() {
		return ein;
	}

	public void setEin(String ein) {
		this.ein = ein;
	}

	public GrpMnthlyCntrbtn getGrpMnthlyCntrbtn() {
		return grpMnthlyCntrbtn;
	}

	public void setGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		this.grpMnthlyCntrbtn = grpMnthlyCntrbtn;
	}

	public String getWgsUpdate() {
		return wgsUpdate;
	}

	public void setWgsUpdate(String wgsUpdate) {
		this.wgsUpdate = wgsUpdate;
	}

	public CntrctAdrs getCntrctAdrs() {
		return cntrctAdrs;
	}

	public void setCntrctAdrs(CntrctAdrs cntrctAdrs) {
		this.cntrctAdrs = cntrctAdrs;
	}

	public CntrctTlphn getCntrctTlphn() {
		return cntrctTlphn;
	}

	public void setCntrctTlphn(CntrctTlphn cntrctTlphn) {
		this.cntrctTlphn = cntrctTlphn;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "Cntrct [cntrctId=" + cntrctId + ", altNtwkCd=" + altNtwkCd + ", clmRteCd=" + clmRteCd + ", clmTpaId="
				+ clmTpaId + ", cnclCntrlTypeCd=" + cnclCntrlTypeCd + ", cntrctEfctvDt=" + (cntrctEfctvDt!=null?formatter.format(cntrctEfctvDt):null)
				+ ", cntrctOwnrTypeCd=" + cntrctOwnrTypeCd + ", cntrctSttsCd=" + cntrctSttsCd + ", cntrctTrmntnDt="
				+ (cntrctTrmntnDt!=null?formatter.format(cntrctTrmntnDt):null) + ", cntrctTrmntnRsnCd=" + cntrctTrmntnRsnCd + ", cvrdSbscrbrCnt=" + cvrdSbscrbrCnt
				+ ", grpHlthInsrncCtgryCd=" + grpHlthInsrncCtgryCd 
				+  ", lgcyCmpnyCfCd=" + lgcyCmpnyCfCd +", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null) 
				+  ", lgcyCntrctCd=" + lgcyCntrctCd + ", lgcyGrpNbr="
				+ lgcyGrpNbr + ", lgcySfxNbr=" + lgcySfxNbr + ", medcallEfctvDt=" + medcallEfctvDt + ", medcallIndCd="
				+ medcallIndCd + ", orgnlCntrctEfctvDt=" + (orgnlCntrctEfctvDt!=null?formatter.format(orgnlCntrctEfctvDt):null) + ", vrsnNbr=" + vrsnNbr + ", fundType="
				+ fundType + ", ein=" + ein + ", wgsUpdate=" + wgsUpdate + "]";
	}

	
}