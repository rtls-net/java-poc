package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CONCURRENCY_LOCK_TBL database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="CONCURRENCY_LOCK_TBL")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConcurrencyLockTbl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="CASE_NBR")
	private String caseNbr;

	@Column(name="CONCURCY_ID")
	@Id
	private long concurcyId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="GRP_BE_ID")
	private BigDecimal grpBeId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="SCREEN_ID")
	private String screenId;

	@LastModifiedBy
	@Column(name="USER_ID")
	private String userId;

	@Version
	@Column(name="VERSION_NUM")
	private Long versionNum;

	public ConcurrencyLockTbl() {
	}

	public String getCaseNbr() {
		return this.caseNbr;
	}

	public void setCaseNbr(String caseNbr) {
		this.caseNbr = caseNbr;
	}

	public long getConcurcyId() {
		return this.concurcyId;
	}

	public void setConcurcyId(long concurcyId) {
		this.concurcyId = concurcyId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getGrpBeId() {
		return this.grpBeId;
	}

	public void setGrpBeId(BigDecimal grpBeId) {
		this.grpBeId = grpBeId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getScreenId() {
		return this.screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getVersionNum() {
		return this.versionNum;
	}

	public void setVersionNum(Long versionNum) {
		this.versionNum = versionNum;
	}

}