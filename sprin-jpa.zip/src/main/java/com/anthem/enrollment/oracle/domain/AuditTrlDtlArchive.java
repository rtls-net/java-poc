package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The AuditData is the Domain object to hold all the data which is related to
 * Auditing. This is a common data which is used in all the table.
 * 
 * @author Deloitte
 * @version 1.0
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "AUDIT_TRL_DTL_ARCHIVE")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuditTrlDtlArchive implements Serializable {
	private static final long serialVersionUID = 1L;

	//@Id
	@Column(name = "GRP_ID")
	private long grpId;
	@Column(name = "GRP_NAME")
	private String grpName;
	@Column(name = "ENTITY_TYPE")
	private String entityType;
	@Column(name = "ENTITY_NUMBER")
	private String entityNumber;
	@Column(name = "FIELD_DATA_JSON")
	private String fieldDataJson;
	@Id
	@Column(name = "UPDATED_DT")
	private Date updatedDt;
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	@Column(name = "ENTITY_TYPE_ID")
	private String entityTypeId;
	@Column(name = "LGCY_GRP_NBR")
	private String lgcyGrpNbr;
	@Column(name = "MRKT_TYPE_CD")
	private String mrktTypeCd;
	public String getLgcyGrpNbr() {
		return lgcyGrpNbr;
	}
	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}
	public String getMrktTypeCd() {
		return mrktTypeCd;
	}
	public void setMrktTypeCd(String mrktTypeCd) {
		this.mrktTypeCd = mrktTypeCd;
	}
	
	public long getGrpId() {
		return grpId;
	}
	public void setGrpId(long grpId) {
		this.grpId = grpId;
	}
	public String getGrpName() {
		return grpName;
	}
	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getEntityNumber() {
		return entityNumber;
	}
	public void setEntityNumber(String entityNumber) {
		this.entityNumber = entityNumber;
	}
	public String getFieldDataJson() {
		return fieldDataJson;
	}
	public void setFieldDataJson(String fieldDataJson) {
		this.fieldDataJson = fieldDataJson;
	}
	public Date getUpdatedDt() {
		return updatedDt;
	}
	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getEntityTypeId() {
		return entityTypeId;
	}
	public void setEntityTypeId(String entityTypeId) {
		this.entityTypeId = entityTypeId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	

}
