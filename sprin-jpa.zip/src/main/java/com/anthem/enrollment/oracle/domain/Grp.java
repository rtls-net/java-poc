package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the GRP database table.
 *
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "GRP")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class Grp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "GRP_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long grpId;

	@Column(name = "BE_TYPE_CD")
	private String beTypeCd;

	@Column(name = "CLM_RPTG_CD")
	private String clmRptgCd;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@Column(name = "CTGRY_CD")
	private String ctgryCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "CTGRY_CD_EFCTV_DT")
	private Date ctgryCdEfctvDt;

	@Column(name = "EMP_OUTSD_USA_IND_CD")
	private String empOutsdUsaIndCd;

	@Column(name = "EMPLR_IDFCTN_NBR")
	private String emplrIdfctnNbr;

	@Column(name = "GHI_CTGRY_CD")
	private String ghiCtgryCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "GRP_APRVL_DT")
	private Date grpAprvlDt;

	@Column(name = "GRP_CLS_CD")
	private String grpClsCd;

	@Column(name = "GRP_CNVRSN_CD")
	private String grpCnvrsnCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "GRP_CNVRSN_DT")
	private Date grpCnvrsnDt;

	// @Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "GRP_EFCTV_DT")
	private Date grpEfctvDt;

	@Column(name = "GRP_NM")
	private String grpNm;

	@Column(name = "GRP_NM_SNDX_TXT")
	private String grpNmSndxTxt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "GRP_ORGNL_EFCTV_DT")
	private Date grpOrgnlEfctvDt;

	@Column(name = "GRP_PRCHS_RSN_CD")
	private String grpPrchsRsnCd;

	@Column(name = "GRP_PRCHS_RSN_TYPE_CNTRL_CD")
	private String grpPrchsRsnTypeCntrlCd;

	@Column(name = "GRP_PRSPCT_NBR")
	private String grpPrspctNbr;

	@Column(name = "GRP_SETUP_CMPLTD_CD")
	private String grpSetupCmpltdCd;

	@Column(name = "GRP_STTS_CD")
	private String grpSttsCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "GRP_TRMNTN_DT")
	private Date grpTrmntnDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "GRP_TRMNTN_PRCS_DT")
	private Date grpTrmntnPrcsDt;

	@Column(name = "GRP_TRMNTN_RSN_CD")
	private String grpTrmntnRsnCd;

	@Column(name = "GRP_TYPE_CD")
	private String grpTypeCd;

	@Column(name = "HC_ID_SRC_CD")
	private String hcIdSrcCd;

	@Column(name = "INIT_WRKRS_CMPNSTN_CD")
	private String initWrkrsCmpnstnCd;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "LCTN_CD_EFCTV_DT")
	private Date lctnCdEfctvDt;

	@Column(name = "LCTN_ST_CD")
	private String lctnStCd;

	@Column(name = "LGCY_GRP_NBR")
	private String lgcyGrpNbr;

	@Column(name = "LOCATION")
	private String location;

	@Column(name = "MDCL_LOA_CD")
	private String mdclLoaCd;

	@Column(name = "MDCR_IND")
	private String medicareInd;

	@Column(name = "MRKT_CD")
	private String mrktCd;

	@Column(name = "MRKT_SGMNT_CD")
	private String mrktSgmntCd;

	@Column(name = "MRKT_TYPE_CD")
	private String mrktTypeCd;

	@Column(name = "NATL_ACCT_CD")
	private String natlAcctCd;

	@Column(name = "PRMRY_GRP_IND_CD")
	private String prmryGrpIndCd;

	@Column(name = "PRSNL_LOA_CD")
	private String prsnlLoaCd;

	@Column(name = "RENEWAL_YEAR")
	private BigDecimal renewalYear;

	@Column(name = "RISK_AREA_CD")
	private String riskAreaCd;

	@Column(name = "RISK_CTGRY_CD")
	private String riskCtgryCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "RISK_CTGRY_EFCTV_DT")
	private Date riskCtgryEfctvDt;

	@Column(name = "RISK_POOL_CD")
	private String riskPoolCd;

	@Column(name = "SIC_CD")
	private String sicCd;

	@Column(name = "SRC_ONE_CD")
	private String srcOneCd;

	@Column(name = "WRKR_CMPNSTN_CMSN_RT_NBR")
	private String wrkrCmpnstnCmsnRtNbr;

	@Column(name = "WRKR_CMPNSTN_PLCY_NBR")
	private String wrkrCmpnstnPlcyNbr;

	@Column(name = "PERSON_ID")
	private String personId;

	@Column(name = "GCUST_ID")
	private String gcustId;

	@Column(name = "MIGRATION_GRP")
	private String migrationGrp;

	// CAIM-27258 CHANGES
	@Column(name = "UW_WRK_MNTH")
	private String uwWrkMnth;

	public String getUwWrkMnth() {
		return uwWrkMnth;
	}

	public void setUwWrkMnth(String uwWrkMnth) {
		this.uwWrkMnth = uwWrkMnth;
	}
	// END

	// bi-directional many-to-one association to Brkr
	@JsonIgnore
	@OneToMany(mappedBy = "grp")
	private List<Brkr> brkrs;

	// bi-directional many-to-one association to Cntrct
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<Cntrct> cntrcts;

	// bi-directional many-to-one association to GrpAdr
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpAdr> grpAdrs;

	// bi-directional many-to-one association to GrpCntctPrsn
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpCntctPrsn> grpCntctPrsns;

	// bi-directional many-to-one association to GrpCntrctPrvsn
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<GrpCntrctPrvsn> grpCntrctPrvsns;

	// bi-directional many-to-one association to GrpEmailAdr
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpEmailAdr> grpEmailAdrs;

	// bi-directional many-to-one association to GrpHc
	@JsonIgnore
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpHc> grpHcs;

	// bi-directional many-to-one association to GrpIndctv
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpIndctv> grpIndctvs;

	// bi-directional many-to-one association to GrpLang
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpLang> grpLangs;

	// bi-directional many-to-one association to GrpMnthlyCntrbtn
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpMnthlyCntrbtn> grpMnthlyCntrbtns;

	// bi-directional many-to-one association to GrpNote
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpNote> grpNotes;

	// bi-directional many-to-one association to GrpPrbtnPrd
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpPrbtnPrd> grpPrbtnPrds;

	// bi-directional many-to-one association to GrpPriorCvrg
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpPriorCvrg> grpPriorCvrgs;

	// bi-directional many-to-one association to GrpRtMthd
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpRtMthd> grpRtMthds;

	// bi-directional many-to-one association to GrpSize
	@JsonIgnore
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpSize> grpSizes;

	// bi-directional many-to-one association to GrpSpclInstrctn
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpSpclInstrctn> grpSpclInstrctns;

	// bi-directional many-to-one association to GrpSprtAsgnmnt
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpSprtAsgnmnt> grpSprtAsgnmnts;

	// bi-directional many-to-one association to GrpTlphn
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpTlphn> grpTlphns;

	// bi-directional many-to-one association to GrpToGrpRltnshp
	@JsonIgnore
	@OneToMany(mappedBy = "grp1", cascade = CascadeType.ALL)
	private List<GrpToGrpRltnshp> grpToGrpRltnshps1;

	// bi-directional many-to-one association to GrpToGrpRltnshp
	@JsonIgnore
	@OneToMany(mappedBy = "grp2", cascade = CascadeType.ALL)
	private List<GrpToGrpRltnshp> grpToGrpRltnshps2;

	// bi-directional many-to-one association to LgcyGrpCf
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<LgcyGrpCf> lgcyGrpCfs;

	// bi-directional many-to-one association to GrpSize
	@JsonIgnore
	@OneToMany(mappedBy = "grp", cascade = CascadeType.ALL)
	private List<GrpRwnlDtl> grpRwnlDtls;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 0L;

	// bi-directional many-to-one association to GrpQuot
	@JsonIgnore
	@OneToMany(mappedBy = "grp")
	private List<GrpQuot> grpQuots;

	public Grp() {
	}

	public Long getGrpId() {
		return this.grpId;
	}

	public void setGrpId(Long grpId) {
		this.grpId = grpId;
	}

	public String getBeTypeCd() {
		return this.beTypeCd;
	}

	public void setBeTypeCd(String beTypeCd) {
		this.beTypeCd = beTypeCd;
	}

	public String getClmRptgCd() {
		return this.clmRptgCd;
	}

	public void setClmRptgCd(String clmRptgCd) {
		this.clmRptgCd = clmRptgCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCtgryCd() {
		return this.ctgryCd;
	}

	public void setCtgryCd(String ctgryCd) {
		this.ctgryCd = ctgryCd;
	}

	public Date getCtgryCdEfctvDt() {
		return this.ctgryCdEfctvDt;
	}

	public void setCtgryCdEfctvDt(Date ctgryCdEfctvDt) {
		this.ctgryCdEfctvDt = ctgryCdEfctvDt;
	}

	public String getEmpOutsdUsaIndCd() {
		return this.empOutsdUsaIndCd;
	}

	public void setEmpOutsdUsaIndCd(String empOutsdUsaIndCd) {
		this.empOutsdUsaIndCd = empOutsdUsaIndCd;
	}

	public String getEmplrIdfctnNbr() {
		return this.emplrIdfctnNbr;
	}

	public void setEmplrIdfctnNbr(String emplrIdfctnNbr) {
		this.emplrIdfctnNbr = emplrIdfctnNbr;
	}

	public String getGhiCtgryCd() {
		return this.ghiCtgryCd;
	}

	public void setGhiCtgryCd(String ghiCtgryCd) {
		this.ghiCtgryCd = ghiCtgryCd;
	}

	public Date getGrpAprvlDt() {
		return this.grpAprvlDt;
	}

	public void setGrpAprvlDt(Date grpAprvlDt) {
		this.grpAprvlDt = grpAprvlDt;
	}

	public String getGrpClsCd() {
		return this.grpClsCd;
	}

	public void setGrpClsCd(String grpClsCd) {
		this.grpClsCd = grpClsCd;
	}

	public String getGrpCnvrsnCd() {
		return this.grpCnvrsnCd;
	}

	public void setGrpCnvrsnCd(String grpCnvrsnCd) {
		this.grpCnvrsnCd = grpCnvrsnCd;
	}

	public Date getGrpCnvrsnDt() {
		return this.grpCnvrsnDt;
	}

	public void setGrpCnvrsnDt(Date grpCnvrsnDt) {
		this.grpCnvrsnDt = grpCnvrsnDt;
	}

	public Date getGrpEfctvDt() {
		return this.grpEfctvDt;
	}

	public void setGrpEfctvDt(Date grpEfctvDt) {
		this.grpEfctvDt = grpEfctvDt;
	}

	public String getGrpNm() {
		return this.grpNm;
	}

	public void setGrpNm(String grpNm) {
		this.grpNm = grpNm;
	}

	public String getGrpNmSndxTxt() {
		return this.grpNmSndxTxt;
	}

	public void setGrpNmSndxTxt(String grpNmSndxTxt) {
		this.grpNmSndxTxt = grpNmSndxTxt;
	}

	public Date getGrpOrgnlEfctvDt() {
		return this.grpOrgnlEfctvDt;
	}

	public void setGrpOrgnlEfctvDt(Date grpOrgnlEfctvDt) {
		this.grpOrgnlEfctvDt = grpOrgnlEfctvDt;
	}

	public String getGrpPrchsRsnCd() {
		return this.grpPrchsRsnCd;
	}

	public void setGrpPrchsRsnCd(String grpPrchsRsnCd) {
		this.grpPrchsRsnCd = grpPrchsRsnCd;
	}

	public String getGrpPrchsRsnTypeCntrlCd() {
		return this.grpPrchsRsnTypeCntrlCd;
	}

	public void setGrpPrchsRsnTypeCntrlCd(String grpPrchsRsnTypeCntrlCd) {
		this.grpPrchsRsnTypeCntrlCd = grpPrchsRsnTypeCntrlCd;
	}

	public String getGrpPrspctNbr() {
		return this.grpPrspctNbr;
	}

	public void setGrpPrspctNbr(String grpPrspctNbr) {
		this.grpPrspctNbr = grpPrspctNbr;
	}

	public String getGrpSetupCmpltdCd() {
		return this.grpSetupCmpltdCd;
	}

	public void setGrpSetupCmpltdCd(String grpSetupCmpltdCd) {
		this.grpSetupCmpltdCd = grpSetupCmpltdCd;
	}

	public String getGrpSttsCd() {
		return this.grpSttsCd;
	}

	public void setGrpSttsCd(String grpSttsCd) {
		this.grpSttsCd = grpSttsCd;
	}

	public Date getGrpTrmntnDt() {
		return this.grpTrmntnDt;
	}

	public void setGrpTrmntnDt(Date grpTrmntnDt) {
		this.grpTrmntnDt = grpTrmntnDt;
	}

	public Date getGrpTrmntnPrcsDt() {
		return this.grpTrmntnPrcsDt;
	}

	public void setGrpTrmntnPrcsDt(Date grpTrmntnPrcsDt) {
		this.grpTrmntnPrcsDt = grpTrmntnPrcsDt;
	}

	public String getGrpTrmntnRsnCd() {
		return this.grpTrmntnRsnCd;
	}

	public void setGrpTrmntnRsnCd(String grpTrmntnRsnCd) {
		this.grpTrmntnRsnCd = grpTrmntnRsnCd;
	}

	public String getGrpTypeCd() {
		return this.grpTypeCd;
	}

	public void setGrpTypeCd(String grpTypeCd) {
		this.grpTypeCd = grpTypeCd;
	}

	public String getHcIdSrcCd() {
		return this.hcIdSrcCd;
	}

	public void setHcIdSrcCd(String hcIdSrcCd) {
		this.hcIdSrcCd = hcIdSrcCd;
	}

	public String getInitWrkrsCmpnstnCd() {
		return this.initWrkrsCmpnstnCd;
	}

	public void setInitWrkrsCmpnstnCd(String initWrkrsCmpnstnCd) {
		this.initWrkrsCmpnstnCd = initWrkrsCmpnstnCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Date getLctnCdEfctvDt() {
		return this.lctnCdEfctvDt;
	}

	public void setLctnCdEfctvDt(Date lctnCdEfctvDt) {
		this.lctnCdEfctvDt = lctnCdEfctvDt;
	}

	public String getLctnStCd() {
		return this.lctnStCd;
	}

	public void setLctnStCd(String lctnStCd) {
		this.lctnStCd = lctnStCd;
	}

	public String getLgcyGrpNbr() {
		return this.lgcyGrpNbr;
	}

	public void setLgcyGrpNbr(String lgcyGrpNbr) {
		this.lgcyGrpNbr = lgcyGrpNbr;
	}

	public String getLocation() {
		
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMdclLoaCd() {
		return this.mdclLoaCd;
	}

	public void setMdclLoaCd(String mdclLoaCd) {
		this.mdclLoaCd = mdclLoaCd;
	}

	public String getMedicareInd() {
		return medicareInd;
	}

	public void setMedicareInd(String medicareInd) {
		this.medicareInd = medicareInd;
	}

	public String getMrktCd() {
		return this.mrktCd;
	}

	public void setMrktCd(String mrktCd) {
		this.mrktCd = mrktCd;
	}

	public String getMrktSgmntCd() {
		return this.mrktSgmntCd;
	}

	public void setMrktSgmntCd(String mrktSgmntCd) {
		this.mrktSgmntCd = mrktSgmntCd;
	}

	public String getMrktTypeCd() {
		return this.mrktTypeCd;
	}

	public void setMrktTypeCd(String mrktTypeCd) {
		this.mrktTypeCd = mrktTypeCd;
	}

	public String getNatlAcctCd() {
		return this.natlAcctCd;
	}

	public void setNatlAcctCd(String natlAcctCd) {
		this.natlAcctCd = natlAcctCd;
	}

	public String getPrmryGrpIndCd() {
		return this.prmryGrpIndCd;
	}

	public void setPrmryGrpIndCd(String prmryGrpIndCd) {
		this.prmryGrpIndCd = prmryGrpIndCd;
	}

	public String getPrsnlLoaCd() {
		return this.prsnlLoaCd;
	}

	public void setPrsnlLoaCd(String prsnlLoaCd) {
		this.prsnlLoaCd = prsnlLoaCd;
	}

	public BigDecimal getRenewalYear() {
		return this.renewalYear;
	}

	public void setRenewalYear(BigDecimal renewalYear) {
		this.renewalYear = renewalYear;
	}

	public String getRiskAreaCd() {
		return this.riskAreaCd;
	}

	public void setRiskAreaCd(String riskAreaCd) {
		this.riskAreaCd = riskAreaCd;
	}

	public String getRiskCtgryCd() {
		return this.riskCtgryCd;
	}

	public void setRiskCtgryCd(String riskCtgryCd) {
		this.riskCtgryCd = riskCtgryCd;
	}

	public Date getRiskCtgryEfctvDt() {
		return this.riskCtgryEfctvDt;
	}

	public void setRiskCtgryEfctvDt(Date riskCtgryEfctvDt) {
		this.riskCtgryEfctvDt = riskCtgryEfctvDt;
	}

	public String getRiskPoolCd() {
		return this.riskPoolCd;
	}

	public void setRiskPoolCd(String riskPoolCd) {
		this.riskPoolCd = riskPoolCd;
	}

	public String getSicCd() {
		return this.sicCd;
	}

	public void setSicCd(String sicCd) {
		this.sicCd = sicCd;
	}

	public String getSrcOneCd() {
		return this.srcOneCd;
	}

	public void setSrcOneCd(String srcOneCd) {
		this.srcOneCd = srcOneCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public String getWrkrCmpnstnCmsnRtNbr() {
		return this.wrkrCmpnstnCmsnRtNbr;
	}

	public void setWrkrCmpnstnCmsnRtNbr(String wrkrCmpnstnCmsnRtNbr) {
		this.wrkrCmpnstnCmsnRtNbr = wrkrCmpnstnCmsnRtNbr;
	}

	public String getWrkrCmpnstnPlcyNbr() {
		return this.wrkrCmpnstnPlcyNbr;
	}

	public void setWrkrCmpnstnPlcyNbr(String wrkrCmpnstnPlcyNbr) {
		this.wrkrCmpnstnPlcyNbr = wrkrCmpnstnPlcyNbr;
	}

	public List<Brkr> getBrkrs() {
		return this.brkrs;
	}

	public void setBrkrs(List<Brkr> brkrs) {
		this.brkrs = brkrs;
	}

	public Brkr addBrkr(Brkr brkr) {
		getBrkrs().add(brkr);
		brkr.setGrp(this);

		return brkr;
	}

	public Brkr removeBrkr(Brkr brkr) {
		getBrkrs().remove(brkr);
		brkr.setGrp(null);

		return brkr;
	}

	public List<Cntrct> getCntrcts() {
		return this.cntrcts;
	}

	public void setCntrcts(List<Cntrct> cntrcts) {
		this.cntrcts = cntrcts;
	}

	public Cntrct addCntrct(Cntrct cntrct) {
		getCntrcts().add(cntrct);
		cntrct.setGrp(this);

		return cntrct;
	}

	public Cntrct removeCntrct(Cntrct cntrct) {
		getCntrcts().remove(cntrct);
		cntrct.setGrp(null);

		return cntrct;
	}

	public List<GrpAdr> getGrpAdrs() {
		return this.grpAdrs;
	}

	public void setGrpAdrs(List<GrpAdr> grpAdrs) {
		this.grpAdrs = grpAdrs;
	}

	public GrpAdr addGrpAdr(GrpAdr grpAdr) {
		getGrpAdrs().add(grpAdr);
		grpAdr.setGrp(this);

		return grpAdr;
	}

	public GrpAdr removeGrpAdr(GrpAdr grpAdr) {
		getGrpAdrs().remove(grpAdr);
		grpAdr.setGrp(null);

		return grpAdr;
	}

	public List<GrpCntctPrsn> getGrpCntctPrsns() {
		return this.grpCntctPrsns;
	}

	public void setGrpCntctPrsns(List<GrpCntctPrsn> grpCntctPrsns) {
		this.grpCntctPrsns = grpCntctPrsns;
	}

	public GrpCntctPrsn addGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		getGrpCntctPrsns().add(grpCntctPrsn);
		grpCntctPrsn.setGrp(this);

		return grpCntctPrsn;
	}

	public GrpCntctPrsn removeGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		getGrpCntctPrsns().remove(grpCntctPrsn);
		grpCntctPrsn.setGrp(null);

		return grpCntctPrsn;
	}

	public List<GrpCntrctPrvsn> getGrpCntrctPrvsns() {
		return this.grpCntrctPrvsns;
	}

	public void setGrpCntrctPrvsns(List<GrpCntrctPrvsn> grpCntrctPrvsns) {
		this.grpCntrctPrvsns = grpCntrctPrvsns;
	}

	public GrpCntrctPrvsn addGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
		getGrpCntrctPrvsns().add(grpCntrctPrvsn);
		grpCntrctPrvsn.setGrp(this);

		return grpCntrctPrvsn;
	}

	public GrpCntrctPrvsn removeGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
		getGrpCntrctPrvsns().remove(grpCntrctPrvsn);
		grpCntrctPrvsn.setGrp(null);

		return grpCntrctPrvsn;
	}

	public List<GrpEmailAdr> getGrpEmailAdrs() {
		return this.grpEmailAdrs;
	}

	public void setGrpEmailAdrs(List<GrpEmailAdr> grpEmailAdrs) {
		this.grpEmailAdrs = grpEmailAdrs;
	}

	public GrpEmailAdr addGrpEmailAdr(GrpEmailAdr grpEmailAdr) {
		getGrpEmailAdrs().add(grpEmailAdr);
		grpEmailAdr.setGrp(this);

		return grpEmailAdr;
	}

	public GrpEmailAdr removeGrpEmailAdr(GrpEmailAdr grpEmailAdr) {
		getGrpEmailAdrs().remove(grpEmailAdr);
		grpEmailAdr.setGrp(null);

		return grpEmailAdr;
	}

	public List<GrpHc> getGrpHcs() {
		return this.grpHcs;
	}

	public void setGrpHcs(List<GrpHc> grpHcs) {
		this.grpHcs = grpHcs;
	}

	public GrpHc addGrpHc(GrpHc grpHc) {
		getGrpHcs().add(grpHc);
		grpHc.setGrp(this);

		return grpHc;
	}

	public GrpHc removeGrpHc(GrpHc grpHc) {
		getGrpHcs().remove(grpHc);
		grpHc.setGrp(null);

		return grpHc;
	}

	public List<GrpIndctv> getGrpIndctvs() {
		return this.grpIndctvs;
	}

	public void setGrpIndctvs(List<GrpIndctv> grpIndctvs) {
		this.grpIndctvs = grpIndctvs;
	}

	public GrpIndctv addGrpIndctv(GrpIndctv grpIndctv) {
		getGrpIndctvs().add(grpIndctv);
		grpIndctv.setGrp(this);

		return grpIndctv;
	}

	public GrpIndctv removeGrpIndctv(GrpIndctv grpIndctv) {
		getGrpIndctvs().remove(grpIndctv);
		grpIndctv.setGrp(null);

		return grpIndctv;
	}

	public List<GrpLang> getGrpLangs() {
		return this.grpLangs;
	}

	public void setGrpLangs(List<GrpLang> grpLangs) {
		this.grpLangs = grpLangs;
	}

	public GrpLang addGrpLang(GrpLang grpLang) {
		getGrpLangs().add(grpLang);
		grpLang.setGrp(this);

		return grpLang;
	}

	public GrpLang removeGrpLang(GrpLang grpLang) {
		getGrpLangs().remove(grpLang);
		grpLang.setGrp(null);

		return grpLang;
	}

	public List<GrpMnthlyCntrbtn> getGrpMnthlyCntrbtns() {
		return this.grpMnthlyCntrbtns;
	}

	public void setGrpMnthlyCntrbtns(List<GrpMnthlyCntrbtn> grpMnthlyCntrbtns) {
		this.grpMnthlyCntrbtns = grpMnthlyCntrbtns;
	}

	public GrpMnthlyCntrbtn addGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		getGrpMnthlyCntrbtns().add(grpMnthlyCntrbtn);
		grpMnthlyCntrbtn.setGrp(this);

		return grpMnthlyCntrbtn;
	}

	public GrpMnthlyCntrbtn removeGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		getGrpMnthlyCntrbtns().remove(grpMnthlyCntrbtn);
		grpMnthlyCntrbtn.setGrp(null);

		return grpMnthlyCntrbtn;
	}

	public List<GrpNote> getGrpNotes() {
		return this.grpNotes;
	}

	public void setGrpNotes(List<GrpNote> grpNotes) {
		this.grpNotes = grpNotes;
	}

	public GrpNote addGrpNote(GrpNote grpNote) {
		getGrpNotes().add(grpNote);
		grpNote.setGrp(this);

		return grpNote;
	}

	public GrpNote removeGrpNote(GrpNote grpNote) {
		getGrpNotes().remove(grpNote);
		grpNote.setGrp(null);

		return grpNote;
	}

	public List<GrpPrbtnPrd> getGrpPrbtnPrds() {
		return this.grpPrbtnPrds;
	}

	public void setGrpPrbtnPrds(List<GrpPrbtnPrd> grpPrbtnPrds) {
		this.grpPrbtnPrds = grpPrbtnPrds;
	}

	public GrpPrbtnPrd addGrpPrbtnPrd(GrpPrbtnPrd grpPrbtnPrd) {
		getGrpPrbtnPrds().add(grpPrbtnPrd);
		grpPrbtnPrd.setGrp(this);

		return grpPrbtnPrd;
	}

	public GrpPrbtnPrd removeGrpPrbtnPrd(GrpPrbtnPrd grpPrbtnPrd) {
		getGrpPrbtnPrds().remove(grpPrbtnPrd);
		grpPrbtnPrd.setGrp(null);

		return grpPrbtnPrd;
	}

	public List<GrpPriorCvrg> getGrpPriorCvrgs() {
		return this.grpPriorCvrgs;
	}

	public void setGrpPriorCvrgs(List<GrpPriorCvrg> grpPriorCvrgs) {
		this.grpPriorCvrgs = grpPriorCvrgs;
	}

	public GrpPriorCvrg addGrpPriorCvrg(GrpPriorCvrg grpPriorCvrg) {
		getGrpPriorCvrgs().add(grpPriorCvrg);
		grpPriorCvrg.setGrp(this);

		return grpPriorCvrg;
	}

	public GrpPriorCvrg removeGrpPriorCvrg(GrpPriorCvrg grpPriorCvrg) {
		getGrpPriorCvrgs().remove(grpPriorCvrg);
		grpPriorCvrg.setGrp(null);

		return grpPriorCvrg;
	}

	public List<GrpRtMthd> getGrpRtMthds() {
		return this.grpRtMthds;
	}

	public void setGrpRtMthds(List<GrpRtMthd> grpRtMthds) {
		this.grpRtMthds = grpRtMthds;
	}

	public GrpRtMthd addGrpRtMthd(GrpRtMthd grpRtMthd) {
		getGrpRtMthds().add(grpRtMthd);
		grpRtMthd.setGrp(this);

		return grpRtMthd;
	}

	public GrpRtMthd removeGrpRtMthd(GrpRtMthd grpRtMthd) {
		getGrpRtMthds().remove(grpRtMthd);
		grpRtMthd.setGrp(null);

		return grpRtMthd;
	}

	public List<GrpSize> getGrpSizes() {
		return this.grpSizes;
	}

	public void setGrpSizes(List<GrpSize> grpSizes) {
		this.grpSizes = grpSizes;
	}

	public GrpSize addGrpSize(GrpSize grpSize) {
		getGrpSizes().add(grpSize);
		grpSize.setGrp(this);

		return grpSize;
	}

	public GrpSize removeGrpSize(GrpSize grpSize) {
		getGrpSizes().remove(grpSize);
		grpSize.setGrp(null);

		return grpSize;
	}

	public List<GrpSpclInstrctn> getGrpSpclInstrctns() {
		return this.grpSpclInstrctns;
	}

	public void setGrpSpclInstrctns(List<GrpSpclInstrctn> grpSpclInstrctns) {
		this.grpSpclInstrctns = grpSpclInstrctns;
	}

	public GrpSpclInstrctn addGrpSpclInstrctn(GrpSpclInstrctn grpSpclInstrctn) {
		getGrpSpclInstrctns().add(grpSpclInstrctn);
		grpSpclInstrctn.setGrp(this);

		return grpSpclInstrctn;
	}

	public GrpSpclInstrctn removeGrpSpclInstrctn(GrpSpclInstrctn grpSpclInstrctn) {
		getGrpSpclInstrctns().remove(grpSpclInstrctn);
		grpSpclInstrctn.setGrp(null);

		return grpSpclInstrctn;
	}

	public List<GrpSprtAsgnmnt> getGrpSprtAsgnmnts() {
		return this.grpSprtAsgnmnts;
	}

	public void setGrpSprtAsgnmnts(List<GrpSprtAsgnmnt> grpSprtAsgnmnts) {
		this.grpSprtAsgnmnts = grpSprtAsgnmnts;
	}

	public GrpSprtAsgnmnt addGrpSprtAsgnmnt(GrpSprtAsgnmnt grpSprtAsgnmnt) {
		getGrpSprtAsgnmnts().add(grpSprtAsgnmnt);
		grpSprtAsgnmnt.setGrp(this);

		return grpSprtAsgnmnt;
	}

	public GrpSprtAsgnmnt removeGrpSprtAsgnmnt(GrpSprtAsgnmnt grpSprtAsgnmnt) {
		getGrpSprtAsgnmnts().remove(grpSprtAsgnmnt);
		grpSprtAsgnmnt.setGrp(null);

		return grpSprtAsgnmnt;
	}

	public List<GrpTlphn> getGrpTlphns() {
		return this.grpTlphns;
	}

	public void setGrpTlphns(List<GrpTlphn> grpTlphns) {
		this.grpTlphns = grpTlphns;
	}

	public GrpTlphn addGrpTlphn(GrpTlphn grpTlphn) {
		getGrpTlphns().add(grpTlphn);
		grpTlphn.setGrp(this);

		return grpTlphn;
	}

	public GrpTlphn removeGrpTlphn(GrpTlphn grpTlphn) {
		getGrpTlphns().remove(grpTlphn);
		grpTlphn.setGrp(null);

		return grpTlphn;
	}

	public List<GrpToGrpRltnshp> getGrpToGrpRltnshps1() {
		return this.grpToGrpRltnshps1;
	}

	public void setGrpToGrpRltnshps1(List<GrpToGrpRltnshp> grpToGrpRltnshps1) {
		this.grpToGrpRltnshps1 = grpToGrpRltnshps1;
	}

	public GrpToGrpRltnshp addGrpToGrpRltnshps1(GrpToGrpRltnshp grpToGrpRltnshps1) {
		getGrpToGrpRltnshps1().add(grpToGrpRltnshps1);
		grpToGrpRltnshps1.setGrp1(this);

		return grpToGrpRltnshps1;
	}

	public GrpToGrpRltnshp removeGrpToGrpRltnshps1(GrpToGrpRltnshp grpToGrpRltnshps1) {
		getGrpToGrpRltnshps1().remove(grpToGrpRltnshps1);
		grpToGrpRltnshps1.setGrp1(null);

		return grpToGrpRltnshps1;
	}

	public List<GrpToGrpRltnshp> getGrpToGrpRltnshps2() {
		return this.grpToGrpRltnshps2;
	}

	public void setGrpToGrpRltnshps2(List<GrpToGrpRltnshp> grpToGrpRltnshps2) {
		this.grpToGrpRltnshps2 = grpToGrpRltnshps2;
	}

	public GrpToGrpRltnshp addGrpToGrpRltnshps2(GrpToGrpRltnshp grpToGrpRltnshps2) {
		getGrpToGrpRltnshps2().add(grpToGrpRltnshps2);
		grpToGrpRltnshps2.setGrp2(this);

		return grpToGrpRltnshps2;
	}

	public GrpToGrpRltnshp removeGrpToGrpRltnshps2(GrpToGrpRltnshp grpToGrpRltnshps2) {
		getGrpToGrpRltnshps2().remove(grpToGrpRltnshps2);
		grpToGrpRltnshps2.setGrp2(null);

		return grpToGrpRltnshps2;
	}

	public List<LgcyGrpCf> getLgcyGrpCfs() {
		return this.lgcyGrpCfs;
	}

	public void setLgcyGrpCfs(List<LgcyGrpCf> lgcyGrpCfs) {
		this.lgcyGrpCfs = lgcyGrpCfs;
	}

	public LgcyGrpCf addLgcyGrpCf(LgcyGrpCf lgcyGrpCf) {
		getLgcyGrpCfs().add(lgcyGrpCf);
		lgcyGrpCf.setGrp(this);

		return lgcyGrpCf;
	}

	public LgcyGrpCf removeLgcyGrpCf(LgcyGrpCf lgcyGrpCf) {
		getLgcyGrpCfs().remove(lgcyGrpCf);
		lgcyGrpCf.setGrp(null);

		return lgcyGrpCf;
	}

	public List<GrpQuot> getGrpQuots() {
		return this.grpQuots;
	}

	public void setGrpQuots(List<GrpQuot> grpQuots) {
		this.grpQuots = grpQuots;
	}

	public GrpQuot addGrpQuot(GrpQuot grpQuot) {
		getGrpQuots().add(grpQuot);
		grpQuot.setGrp(this);

		return grpQuot;
	}

	public GrpQuot removeGrpQuot(GrpQuot grpQuot) {
		getGrpQuots().remove(grpQuot);
		grpQuot.setGrp(null);

		return grpQuot;
	}

	public List<GrpRwnlDtl> getGrpRwnlDtls() {
		return grpRwnlDtls;
	}

	public void setGrpRwnlDtls(List<GrpRwnlDtl> grpRwnlDtls) {
		this.grpRwnlDtls = grpRwnlDtls;
	}

	public String getPersonId() {
		return personId;
	}

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	public String getGcustId() {
		return gcustId;
	}

	public void setGcustId(String gcustId) {
		this.gcustId = gcustId;
	}

	/**
	 * @return the migrationGrp
	 */
	public String getMigrationGrp() {
		return migrationGrp;
	}

	/**
	 * @param migrationGrp the migrationGrp to set
	 */
	public void setMigrationGrp(String migrationGrp) {
		this.migrationGrp = migrationGrp;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "Grp [grpId=" + grpId + ", beTypeCd=" + beTypeCd + ", clmRptgCd=" + clmRptgCd + ", ctgryCd=" + ctgryCd
				+ ", ctgryCdEfctvDt=" + ctgryCdEfctvDt + ", empOutsdUsaIndCd=" + empOutsdUsaIndCd + ", emplrIdfctnNbr="
				+ emplrIdfctnNbr + ", ghiCtgryCd=" + ghiCtgryCd + ", grpAprvlDt="
				+ (grpAprvlDt != null ? formatter.format(grpAprvlDt) : null) + ", grpClsCd=" + grpClsCd
				+ ", grpCnvrsnCd=" + grpCnvrsnCd + ", grpCnvrsnDt="
				+ (grpCnvrsnDt != null ? formatter.format(grpCnvrsnDt) : null) + ", grpEfctvDt="
				+ (grpEfctvDt != null ? formatter.format(grpEfctvDt) : null) + ", grpNm=" + grpNm + ", grpNmSndxTxt="
				+ grpNmSndxTxt + ", grpOrgnlEfctvDt="
				+ (grpOrgnlEfctvDt != null ? formatter.format(grpOrgnlEfctvDt) : null) + ", grpPrchsRsnCd="
				+ grpPrchsRsnCd + ", grpPrchsRsnTypeCntrlCd=" + grpPrchsRsnTypeCntrlCd + ", grpPrspctNbr="
				+ grpPrspctNbr + ", grpSetupCmpltdCd=" + grpSetupCmpltdCd + ", grpSttsCd=" + grpSttsCd
				+ ", grpTrmntnDt=" + (grpTrmntnDt != null ? formatter.format(grpTrmntnDt) : null) + ", grpTrmntnPrcsDt="
				+ (grpTrmntnPrcsDt != null ? formatter.format(grpTrmntnPrcsDt) : null) + ", grpTrmntnRsnCd="
				+ grpTrmntnRsnCd + ", grpTypeCd=" + grpTypeCd + ", hcIdSrcCd=" + hcIdSrcCd + ", initWrkrsCmpnstnCd="
				+ initWrkrsCmpnstnCd + ", lctnCdEfctvDt="
				+ (lctnCdEfctvDt != null ? formatter.format(lctnCdEfctvDt) : null) + ", lctnStCd=" + lctnStCd
				+ ", lgcyGrpNbr=" + lgcyGrpNbr + ", location=" + location + ", mdclLoaCd=" + mdclLoaCd
				+ ", medicareInd=" + medicareInd + ", mrktCd=" + mrktCd + ", mrktSgmntCd=" + mrktSgmntCd
				+ ", mrktTypeCd=" + mrktTypeCd + ", natlAcctCd=" + natlAcctCd + ", prmryGrpIndCd=" + prmryGrpIndCd
				+ ", prsnlLoaCd=" + prsnlLoaCd + ", renewalYear=" + renewalYear + ", riskAreaCd=" + riskAreaCd
				+ ", riskCtgryCd=" + riskCtgryCd + ", riskCtgryEfctvDt="
				+ (riskCtgryEfctvDt != null ? formatter.format(riskCtgryEfctvDt) : null) + ", riskPoolCd=" + riskPoolCd
				+ ", sicCd=" + sicCd + ", srcOneCd=" + srcOneCd + ", wrkrCmpnstnCmsnRtNbr=" + wrkrCmpnstnCmsnRtNbr
				+ ", wrkrCmpnstnPlcyNbr=" + wrkrCmpnstnPlcyNbr + ", personId=" + personId + ", gcustId=" + gcustId
				+ ", migrationGrp=" + migrationGrp + ", vrsnNbr=" + vrsnNbr + "]";
	}

}