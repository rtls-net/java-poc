package com.anthem.enrollment.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.anthem.enrollment.oracle.domain.Cntrct;

@Service
public interface PrdctService {
	
	public List<Cntrct> getCntrctdetails(Long grpId,String cvrgTypCd);
}
