package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the MGRTN_LOG_LOAD database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="MGRTN_LOG_LOAD")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MgrtnLogLoad implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOG_ID")
	private long logId;

	@Lob
	@Column(name="GSM_DOCUMENT")
	private String gsmDocument;

	@Column(name="REQ_PAYLOAD_TEXT")
	private String reqPayloadText;

	//bi-directional one-to-one association to MgrtnLog
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LOG_ID")
	private MgrtnLog mgrtnLog;

	public MgrtnLogLoad() {
	}

	public long getLogId() {
		return this.logId;
	}

	public void setLogId(long logId) {
		this.logId = logId;
	}

	public String getGsmDocument() {
		return this.gsmDocument;
	}

	public void setGsmDocument(String gsmDocument) {
		this.gsmDocument = gsmDocument;
	}

	public String getReqPayloadText() {
		return this.reqPayloadText;
	}

	public void setReqPayloadText(String reqPayloadText) {
		this.reqPayloadText = reqPayloadText;
	}

	public MgrtnLog getMgrtnLog() {
		return this.mgrtnLog;
	}

	public void setMgrtnLog(MgrtnLog mgrtnLog) {
		this.mgrtnLog = mgrtnLog;
	}

}