package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the GRP_RWNL_DTLS database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_RWNL_DTLS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpRwnlDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_RWNL_DTLS_ID")
	private long grpRwnlDtlsId;

	@CreatedBy
	@Column(name="CREATED_BY_USER_ID")
	private String createdByUserId;

	@CreatedDate
	@Column(name="CREATED_DTM")
	private Date createdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="EFCTV_DATE")
	private Date efctvDate;

	@Column(name="GRP_SETUP_CMPLTD_CD")
	private String grpSetupCmpltdCd;

	@LastModifiedBy
	@Column(name="LAST_UPDT_BY_USER_ID")
	private String lastUpdtByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDT_DTM")
	private Date lastUpdtDtm;

	@Column(name="RNWL_YR_NBR")
	private BigDecimal rnwlYrNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="TRMNTN_DT")
	private Date trmntnDt;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpRwnlDtl() {
	}

	public long getGrpRwnlDtlsId() {
		return this.grpRwnlDtlsId;
	}

	public void setGrpRwnlDtlsId(long grpRwnlDtlsId) {
		this.grpRwnlDtlsId = grpRwnlDtlsId;
	}

	public String getCreatedByUserId() {
		return this.createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public Date getCreatedDtm() {
		return this.createdDtm;
	}

	public void setCreatedDtm(Date createdDtm) {
		this.createdDtm = createdDtm;
	}

	public Date getEfctvDate() {
		return this.efctvDate;
	}

	public void setEfctvDate(Date efctvDate) {
		this.efctvDate = efctvDate;
	}

	public String getGrpSetupCmpltdCd() {
		return this.grpSetupCmpltdCd;
	}

	public void setGrpSetupCmpltdCd(String grpSetupCmpltdCd) {
		this.grpSetupCmpltdCd = grpSetupCmpltdCd;
	}

	public String getLastUpdtByUserId() {
		return this.lastUpdtByUserId;
	}

	public void setLastUpdtByUserId(String lastUpdtByUserId) {
		this.lastUpdtByUserId = lastUpdtByUserId;
	}

	public Date getLastUpdtDtm() {
		return this.lastUpdtDtm;
	}

	public void setLastUpdtDtm(Date lastUpdtDtm) {
		this.lastUpdtDtm = lastUpdtDtm;
	}

	public BigDecimal getRnwlYrNbr() {
		return this.rnwlYrNbr;
	}

	public void setRnwlYrNbr(BigDecimal rnwlYrNbr) {
		this.rnwlYrNbr = rnwlYrNbr;
	}

	public Date getTrmntnDt() {
		return this.trmntnDt;
	}

	public void setTrmntnDt(Date trmntnDt) {
		this.trmntnDt = trmntnDt;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

}