package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CNTRCT_PLAN_RT_SMRY database table.
 * 
 */
@Entity
@Table(name="CNTRCT_PLAN_RT_SMRY")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctPlanRtSmry implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CNTRCT_PLAN_RT_SMRY_ID")
	private Long cntrctPlanRtSmryId;

	@Column(name="AGE_GNDR_RATG_TYPE_CD")
	private String ageGndrRatgTypeCd;
	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;
	
	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="RAL_DESC")
	private String ralDesc;

	@Column(name="REINSRNC_KEY")
	private String reinsrncKey;

	@Column(name="RT_AGE_BRKT")
	private String rtAgeBrkt;

	@Column(name="RT_GUARTE")
	private String rtGuarte;

	@Temporal(TemporalType.DATE)
	@Column(name="RT_GUARTE_END_DT")
	private Date rtGuarteEndDt;

	@Column(name="RT_LCHD")
	private String rtLchd;

	@Column(name="RT_LDEP")
	private String rtLdep;

	@Column(name="RT_LSPS")
	private String rtLsps;

	@Column(name="RT_LSUB")
	private String rtLsub;

	@Column(name="TOTL_CNTRCT_TYPE01")
	private String totlCntrctType01;

	@Column(name="TOTL_CNTRCT_TYPE02")
	private String totlCntrctType02;

	@Column(name="TOTL_CNTRCT_TYPE03")
	private String totlCntrctType03;

	@Column(name="TOTL_CNTRCT_TYPE04")
	private String totlCntrctType04;

	@Column(name="TOTL_CNTRCT_TYPE05")
	private String totlCntrctType05;

	@Column(name="TOTL_CNTRCT_TYPE06")
	private String totlCntrctType06;

	@Column(name="TOTL_CNTRCT_TYPE07")
	private String totlCntrctType07;

	@Column(name="TOTL_CNTRCT_TYPE08")
	private String totlCntrctType08;

	@Column(name="TOTL_CNTRCT_TYPE09")
	private String totlCntrctType09;

	@Column(name="TOTL_CNTRCT_TYPE10")
	private String totlCntrctType10;

	@Column(name="TOTL_CNTRCT_TYPE11")
	private String totlCntrctType11;

	@Column(name="TOTL_CNTRCT_TYPE12")
	private String totlCntrctType12;

	@Column(name="TOTL_CNTRCT_TYPE13")
	private String totlCntrctType13;

	@Column(name="TOTL_CNTRCT_TYPE14")
	private String totlCntrctType14;

	@Column(name="TOTL_CNTRCT_TYPE15")
	private String totlCntrctType15;

	@Column(name="TOTL_RT_AMT01")
	private BigDecimal totlRtAmt01;

	@Column(name="TOTL_RT_AMT02")
	private BigDecimal totlRtAmt02;

	@Column(name="TOTL_RT_AMT03")
	private BigDecimal totlRtAmt03;

	@Column(name="TOTL_RT_AMT04")
	private BigDecimal totlRtAmt04;

	@Column(name="TOTL_RT_AMT05")
	private BigDecimal totlRtAmt05;

	@Column(name="TOTL_RT_AMT06")
	private BigDecimal totlRtAmt06;

	@Column(name="TOTL_RT_AMT07")
	private BigDecimal totlRtAmt07;

	@Column(name="TOTL_RT_AMT08")
	private BigDecimal totlRtAmt08;

	@Column(name="TOTL_RT_AMT09")
	private BigDecimal totlRtAmt09;

	@Column(name="TOTL_RT_AMT10")
	private BigDecimal totlRtAmt10;

	@Column(name="TOTL_RT_AMT11")
	private BigDecimal totlRtAmt11;

	@Column(name="TOTL_RT_AMT12")
	private BigDecimal totlRtAmt12;

	@Column(name="TOTL_RT_AMT13")
	private BigDecimal totlRtAmt13;

	@Column(name="TOTL_RT_AMT14")
	private BigDecimal totlRtAmt14;

	@Column(name="TOTL_RT_AMT15")
	private BigDecimal totlRtAmt15;

	//@Temporal(TemporalType.DATE)
	@Column(name="TOTL_RT_EFCTV_DT")
	private Date totlRtEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="TOTL_RT_TRMNTN_DT")
	private Date totlRtTrmntnDt;

	@Column(name="TOTL_RT_TYPE")
	private String totlRtType;

	@Column(name="TOTL_WASH_CUTOFF")
	private String totlWashCutoff;
	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String updtdByUserId;
	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date updtdDtm;
	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to CntrctPlanRtDtl
	@OneToMany(mappedBy="cntrctPlanRtSmry",cascade = {CascadeType.ALL})
	private List<CntrctPlanRtDtl> cntrctPlanRtDtls;

	//bi-directional many-to-one association to CntrctPlanRt
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CNTRCT_PLAN_RT_ID")
	private CntrctPlanRt cntrctPlanRt;
	
	@Transient
    private Long cntrctPlanRtId;

	public Long getCntrctPlanRtId() {
		return cntrctPlanRtId;
	}

	public void setCntrctPlanRtId(Long cntrctPlanRtId) {
		this.cntrctPlanRtId = cntrctPlanRtId;
	}

	public CntrctPlanRtSmry() {
	}

	public Long getCntrctPlanRtSmryId() {
		return this.cntrctPlanRtSmryId;
	}

	public void setCntrctPlanRtSmryId(Long cntrctPlanRtSmryId) {
		this.cntrctPlanRtSmryId = cntrctPlanRtSmryId;
	}

	public String getAgeGndrRatgTypeCd() {
		return this.ageGndrRatgTypeCd;
	}

	public void setAgeGndrRatgTypeCd(String ageGndrRatgTypeCd) {
		this.ageGndrRatgTypeCd = ageGndrRatgTypeCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getRalDesc() {
		return this.ralDesc;
	}

	public void setRalDesc(String ralDesc) {
		this.ralDesc = ralDesc;
	}

	public String getReinsrncKey() {
		return this.reinsrncKey;
	}

	public void setReinsrncKey(String reinsrncKey) {
		this.reinsrncKey = reinsrncKey;
	}

	public String getRtAgeBrkt() {
		return this.rtAgeBrkt;
	}

	public void setRtAgeBrkt(String rtAgeBrkt) {
		this.rtAgeBrkt = rtAgeBrkt;
	}

	public String getRtGuarte() {
		return this.rtGuarte;
	}

	public void setRtGuarte(String rtGuarte) {
		this.rtGuarte = rtGuarte;
	}

	public Date getRtGuarteEndDt() {
		return this.rtGuarteEndDt;
	}

	public void setRtGuarteEndDt(Date rtGuarteEndDt) {
		this.rtGuarteEndDt = rtGuarteEndDt;
	}

	public String getRtLchd() {
		return this.rtLchd;
	}

	public void setRtLchd(String rtLchd) {
		this.rtLchd = rtLchd;
	}

	public String getRtLdep() {
		return this.rtLdep;
	}

	public void setRtLdep(String rtLdep) {
		this.rtLdep = rtLdep;
	}

	public String getRtLsps() {
		return this.rtLsps;
	}

	public void setRtLsps(String rtLsps) {
		this.rtLsps = rtLsps;
	}

	public String getRtLsub() {
		return this.rtLsub;
	}

	public void setRtLsub(String rtLsub) {
		this.rtLsub = rtLsub;
	}

	public String getTotlCntrctType01() {
		return this.totlCntrctType01;
	}

	public void setTotlCntrctType01(String totlCntrctType01) {
		this.totlCntrctType01 = totlCntrctType01;
	}

	public String getTotlCntrctType02() {
		return this.totlCntrctType02;
	}

	public void setTotlCntrctType02(String totlCntrctType02) {
		this.totlCntrctType02 = totlCntrctType02;
	}

	public String getTotlCntrctType03() {
		return this.totlCntrctType03;
	}

	public void setTotlCntrctType03(String totlCntrctType03) {
		this.totlCntrctType03 = totlCntrctType03;
	}

	public String getTotlCntrctType04() {
		return this.totlCntrctType04;
	}

	public void setTotlCntrctType04(String totlCntrctType04) {
		this.totlCntrctType04 = totlCntrctType04;
	}

	public String getTotlCntrctType05() {
		return this.totlCntrctType05;
	}

	public void setTotlCntrctType05(String totlCntrctType05) {
		this.totlCntrctType05 = totlCntrctType05;
	}

	public String getTotlCntrctType06() {
		return this.totlCntrctType06;
	}

	public void setTotlCntrctType06(String totlCntrctType06) {
		this.totlCntrctType06 = totlCntrctType06;
	}

	public String getTotlCntrctType07() {
		return this.totlCntrctType07;
	}

	public void setTotlCntrctType07(String totlCntrctType07) {
		this.totlCntrctType07 = totlCntrctType07;
	}

	public String getTotlCntrctType08() {
		return this.totlCntrctType08;
	}

	public void setTotlCntrctType08(String totlCntrctType08) {
		this.totlCntrctType08 = totlCntrctType08;
	}

	public String getTotlCntrctType09() {
		return this.totlCntrctType09;
	}

	public void setTotlCntrctType09(String totlCntrctType09) {
		this.totlCntrctType09 = totlCntrctType09;
	}

	public String getTotlCntrctType10() {
		return this.totlCntrctType10;
	}

	public void setTotlCntrctType10(String totlCntrctType10) {
		this.totlCntrctType10 = totlCntrctType10;
	}

	public String getTotlCntrctType11() {
		return this.totlCntrctType11;
	}

	public void setTotlCntrctType11(String totlCntrctType11) {
		this.totlCntrctType11 = totlCntrctType11;
	}

	public String getTotlCntrctType12() {
		return this.totlCntrctType12;
	}

	public void setTotlCntrctType12(String totlCntrctType12) {
		this.totlCntrctType12 = totlCntrctType12;
	}

	public String getTotlCntrctType13() {
		return this.totlCntrctType13;
	}

	public void setTotlCntrctType13(String totlCntrctType13) {
		this.totlCntrctType13 = totlCntrctType13;
	}

	public String getTotlCntrctType14() {
		return this.totlCntrctType14;
	}

	public void setTotlCntrctType14(String totlCntrctType14) {
		this.totlCntrctType14 = totlCntrctType14;
	}

	public String getTotlCntrctType15() {
		return this.totlCntrctType15;
	}

	public void setTotlCntrctType15(String totlCntrctType15) {
		this.totlCntrctType15 = totlCntrctType15;
	}

	public BigDecimal getTotlRtAmt01() {
		return this.totlRtAmt01;
	}

	public void setTotlRtAmt01(BigDecimal totlRtAmt01) {
		this.totlRtAmt01 = totlRtAmt01;
	}

	public BigDecimal getTotlRtAmt02() {
		return this.totlRtAmt02;
	}

	public void setTotlRtAmt02(BigDecimal totlRtAmt02) {
		this.totlRtAmt02 = totlRtAmt02;
	}

	public BigDecimal getTotlRtAmt03() {
		return this.totlRtAmt03;
	}

	public void setTotlRtAmt03(BigDecimal totlRtAmt03) {
		this.totlRtAmt03 = totlRtAmt03;
	}

	public BigDecimal getTotlRtAmt04() {
		return this.totlRtAmt04;
	}

	public void setTotlRtAmt04(BigDecimal totlRtAmt04) {
		this.totlRtAmt04 = totlRtAmt04;
	}

	public BigDecimal getTotlRtAmt05() {
		return this.totlRtAmt05;
	}

	public void setTotlRtAmt05(BigDecimal totlRtAmt05) {
		this.totlRtAmt05 = totlRtAmt05;
	}

	public BigDecimal getTotlRtAmt06() {
		return this.totlRtAmt06;
	}

	public void setTotlRtAmt06(BigDecimal totlRtAmt06) {
		this.totlRtAmt06 = totlRtAmt06;
	}

	public BigDecimal getTotlRtAmt07() {
		return this.totlRtAmt07;
	}

	public void setTotlRtAmt07(BigDecimal totlRtAmt07) {
		this.totlRtAmt07 = totlRtAmt07;
	}

	public BigDecimal getTotlRtAmt08() {
		return this.totlRtAmt08;
	}

	public void setTotlRtAmt08(BigDecimal totlRtAmt08) {
		this.totlRtAmt08 = totlRtAmt08;
	}

	public BigDecimal getTotlRtAmt09() {
		return this.totlRtAmt09;
	}

	public void setTotlRtAmt09(BigDecimal totlRtAmt09) {
		this.totlRtAmt09 = totlRtAmt09;
	}

	public BigDecimal getTotlRtAmt10() {
		return this.totlRtAmt10;
	}

	public void setTotlRtAmt10(BigDecimal totlRtAmt10) {
		this.totlRtAmt10 = totlRtAmt10;
	}

	public BigDecimal getTotlRtAmt11() {
		return this.totlRtAmt11;
	}

	public void setTotlRtAmt11(BigDecimal totlRtAmt11) {
		this.totlRtAmt11 = totlRtAmt11;
	}

	public BigDecimal getTotlRtAmt12() {
		return this.totlRtAmt12;
	}

	public void setTotlRtAmt12(BigDecimal totlRtAmt12) {
		this.totlRtAmt12 = totlRtAmt12;
	}

	public BigDecimal getTotlRtAmt13() {
		return this.totlRtAmt13;
	}

	public void setTotlRtAmt13(BigDecimal totlRtAmt13) {
		this.totlRtAmt13 = totlRtAmt13;
	}

	public BigDecimal getTotlRtAmt14() {
		return this.totlRtAmt14;
	}

	public void setTotlRtAmt14(BigDecimal totlRtAmt14) {
		this.totlRtAmt14 = totlRtAmt14;
	}

	public BigDecimal getTotlRtAmt15() {
		return this.totlRtAmt15;
	}

	public void setTotlRtAmt15(BigDecimal totlRtAmt15) {
		this.totlRtAmt15 = totlRtAmt15;
	}

	public Date getTotlRtEfctvDt() {
		return this.totlRtEfctvDt;
	}

	public void setTotlRtEfctvDt(Date totlRtEfctvDt) {
		this.totlRtEfctvDt = totlRtEfctvDt;
	}

	public Date getTotlRtTrmntnDt() {
		return this.totlRtTrmntnDt;
	}

	public void setTotlRtTrmntnDt(Date totlRtTrmntnDt) {
		this.totlRtTrmntnDt = totlRtTrmntnDt;
	}

	public String getTotlRtType() {
		return this.totlRtType;
	}

	public void setTotlRtType(String totlRtType) {
		this.totlRtType = totlRtType;
	}

	public String getTotlWashCutoff() {
		return this.totlWashCutoff;
	}

	public void setTotlWashCutoff(String totlWashCutoff) {
		this.totlWashCutoff = totlWashCutoff;
	}

	public String getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(String updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Date getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Date updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public List<CntrctPlanRtDtl> getCntrctPlanRtDtls() {
		return this.cntrctPlanRtDtls;
	}

	public void setCntrctPlanRtDtls(List<CntrctPlanRtDtl> cntrctPlanRtDtls) {
		this.cntrctPlanRtDtls = cntrctPlanRtDtls;
	}

	public CntrctPlanRtDtl addCntrctPlanRtDtl(CntrctPlanRtDtl cntrctPlanRtDtl) {
		getCntrctPlanRtDtls().add(cntrctPlanRtDtl);
		cntrctPlanRtDtl.setCntrctPlanRtSmry(this);

		return cntrctPlanRtDtl;
	}

	public CntrctPlanRtDtl removeCntrctPlanRtDtl(CntrctPlanRtDtl cntrctPlanRtDtl) {
		getCntrctPlanRtDtls().remove(cntrctPlanRtDtl);
		cntrctPlanRtDtl.setCntrctPlanRtSmry(null);

		return cntrctPlanRtDtl;
	}

	public CntrctPlanRt getCntrctPlanRt() {
		return this.cntrctPlanRt;
	}

	public void setCntrctPlanRt(CntrctPlanRt cntrctPlanRt) {
		this.cntrctPlanRt = cntrctPlanRt;
	}

}