package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the GRP_CNTCT_PRSN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_CNTCT_PRSN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpCntctPrsn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_CNTCT_PRSN_ID")
	private Long grpCntctPrsnId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	//@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_EFCTV_DT")
	private Date grpCntctPrsnEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_TRMNTN_DT")
	private Date grpCntctPrsnTrmntnDt;

	@Column(name="GRP_CNTCT_TYPE_CD")
	private String grpCntctTypeCd;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	//bi-directional many-to-one association to CntctPrsn
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="CNTCT_PRSN_ID")
	private CntctPrsn cntctPrsn;

	//bi-directional many-to-one association to GrpCntctPrsnAdr
	@JsonIgnore
	@OneToMany(mappedBy="grpCntctPrsn")
	private List<GrpCntctPrsnAdr> grpCntctPrsnAdrs;

	//bi-directional many-to-one association to GrpCntctPrsnAdrsTlphn
	@JsonIgnore
	@OneToMany(mappedBy="grpCntctPrsn")
	private List<GrpCntctPrsnAdrsTlphn> grpCntctPrsnAdrsTlphns;

	//bi-directional many-to-one association to GrpCntctPrsnEmailAdr
	@JsonIgnore
	@OneToMany(mappedBy="grpCntctPrsn")
	private List<GrpCntctPrsnEmailAdr> grpCntctPrsnEmailAdrs;

	//bi-directional many-to-one association to GrpCntctPrsnLang
	@JsonIgnore
	@OneToMany(mappedBy="grpCntctPrsn")
	private List<GrpCntctPrsnLang> grpCntctPrsnLangs;

	//bi-directional many-to-one association to GrpCntctPrsnTlphn
	@JsonIgnore
	@OneToMany(mappedBy="grpCntctPrsn")
	private List<GrpCntctPrsnTlphn> grpCntctPrsnTlphns;

	public GrpCntctPrsn() {
	}

	public Long getGrpCntctPrsnId() {
		return this.grpCntctPrsnId;
	}

	public void setGrpCntctPrsnId(Long grpCntctPrsnId) {
		this.grpCntctPrsnId = grpCntctPrsnId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpCntctPrsnEfctvDt() {
		return this.grpCntctPrsnEfctvDt;
	}

	public void setGrpCntctPrsnEfctvDt(Date grpCntctPrsnEfctvDt) {
		this.grpCntctPrsnEfctvDt = grpCntctPrsnEfctvDt;
	}

	public Date getGrpCntctPrsnTrmntnDt() {
		return this.grpCntctPrsnTrmntnDt;
	}

	public void setGrpCntctPrsnTrmntnDt(Date grpCntctPrsnTrmntnDt) {
		this.grpCntctPrsnTrmntnDt = grpCntctPrsnTrmntnDt;
	}

	public String getGrpCntctTypeCd() {
		return this.grpCntctTypeCd;
	}

	public void setGrpCntctTypeCd(String grpCntctTypeCd) {
		this.grpCntctTypeCd = grpCntctTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	public CntctPrsn getCntctPrsn() {
		return this.cntctPrsn;
	}

	public void setCntctPrsn(CntctPrsn cntctPrsn) {
		this.cntctPrsn = cntctPrsn;
	}

	public List<GrpCntctPrsnAdr> getGrpCntctPrsnAdrs() {
		return this.grpCntctPrsnAdrs;
	}

	public void setGrpCntctPrsnAdrs(List<GrpCntctPrsnAdr> grpCntctPrsnAdrs) {
		this.grpCntctPrsnAdrs = grpCntctPrsnAdrs;
	}

	public GrpCntctPrsnAdr addGrpCntctPrsnAdr(GrpCntctPrsnAdr grpCntctPrsnAdr) {
		getGrpCntctPrsnAdrs().add(grpCntctPrsnAdr);
		grpCntctPrsnAdr.setGrpCntctPrsn(this);

		return grpCntctPrsnAdr;
	}

	public GrpCntctPrsnAdr removeGrpCntctPrsnAdr(GrpCntctPrsnAdr grpCntctPrsnAdr) {
		getGrpCntctPrsnAdrs().remove(grpCntctPrsnAdr);
		grpCntctPrsnAdr.setGrpCntctPrsn(null);

		return grpCntctPrsnAdr;
	}

	public List<GrpCntctPrsnAdrsTlphn> getGrpCntctPrsnAdrsTlphns() {
		return this.grpCntctPrsnAdrsTlphns;
	}

	public void setGrpCntctPrsnAdrsTlphns(List<GrpCntctPrsnAdrsTlphn> grpCntctPrsnAdrsTlphns) {
		this.grpCntctPrsnAdrsTlphns = grpCntctPrsnAdrsTlphns;
	}

	public GrpCntctPrsnAdrsTlphn addGrpCntctPrsnAdrsTlphn(GrpCntctPrsnAdrsTlphn grpCntctPrsnAdrsTlphn) {
		getGrpCntctPrsnAdrsTlphns().add(grpCntctPrsnAdrsTlphn);
		grpCntctPrsnAdrsTlphn.setGrpCntctPrsn(this);

		return grpCntctPrsnAdrsTlphn;
	}

	public GrpCntctPrsnAdrsTlphn removeGrpCntctPrsnAdrsTlphn(GrpCntctPrsnAdrsTlphn grpCntctPrsnAdrsTlphn) {
		getGrpCntctPrsnAdrsTlphns().remove(grpCntctPrsnAdrsTlphn);
		grpCntctPrsnAdrsTlphn.setGrpCntctPrsn(null);

		return grpCntctPrsnAdrsTlphn;
	}

	public List<GrpCntctPrsnEmailAdr> getGrpCntctPrsnEmailAdrs() {
		return this.grpCntctPrsnEmailAdrs;
	}

	public void setGrpCntctPrsnEmailAdrs(List<GrpCntctPrsnEmailAdr> grpCntctPrsnEmailAdrs) {
		this.grpCntctPrsnEmailAdrs = grpCntctPrsnEmailAdrs;
	}

	public GrpCntctPrsnEmailAdr addGrpCntctPrsnEmailAdr(GrpCntctPrsnEmailAdr grpCntctPrsnEmailAdr) {
		getGrpCntctPrsnEmailAdrs().add(grpCntctPrsnEmailAdr);
		grpCntctPrsnEmailAdr.setGrpCntctPrsn(this);

		return grpCntctPrsnEmailAdr;
	}

	public GrpCntctPrsnEmailAdr removeGrpCntctPrsnEmailAdr(GrpCntctPrsnEmailAdr grpCntctPrsnEmailAdr) {
		getGrpCntctPrsnEmailAdrs().remove(grpCntctPrsnEmailAdr);
		grpCntctPrsnEmailAdr.setGrpCntctPrsn(null);

		return grpCntctPrsnEmailAdr;
	}

	public List<GrpCntctPrsnLang> getGrpCntctPrsnLangs() {
		return this.grpCntctPrsnLangs;
	}

	public void setGrpCntctPrsnLangs(List<GrpCntctPrsnLang> grpCntctPrsnLangs) {
		this.grpCntctPrsnLangs = grpCntctPrsnLangs;
	}

	public GrpCntctPrsnLang addGrpCntctPrsnLang(GrpCntctPrsnLang grpCntctPrsnLang) {
		getGrpCntctPrsnLangs().add(grpCntctPrsnLang);
		grpCntctPrsnLang.setGrpCntctPrsn(this);

		return grpCntctPrsnLang;
	}

	public GrpCntctPrsnLang removeGrpCntctPrsnLang(GrpCntctPrsnLang grpCntctPrsnLang) {
		getGrpCntctPrsnLangs().remove(grpCntctPrsnLang);
		grpCntctPrsnLang.setGrpCntctPrsn(null);

		return grpCntctPrsnLang;
	}

	public List<GrpCntctPrsnTlphn> getGrpCntctPrsnTlphns() {
		return this.grpCntctPrsnTlphns;
	}

	public void setGrpCntctPrsnTlphns(List<GrpCntctPrsnTlphn> grpCntctPrsnTlphns) {
		this.grpCntctPrsnTlphns = grpCntctPrsnTlphns;
	}

	public GrpCntctPrsnTlphn addGrpCntctPrsnTlphn(GrpCntctPrsnTlphn grpCntctPrsnTlphn) {
		getGrpCntctPrsnTlphns().add(grpCntctPrsnTlphn);
		grpCntctPrsnTlphn.setGrpCntctPrsn(this);

		return grpCntctPrsnTlphn;
	}

	public GrpCntctPrsnTlphn removeGrpCntctPrsnTlphn(GrpCntctPrsnTlphn grpCntctPrsnTlphn) {
		getGrpCntctPrsnTlphns().remove(grpCntctPrsnTlphn);
		grpCntctPrsnTlphn.setGrpCntctPrsn(null);

		return grpCntctPrsnTlphn;
	}

}