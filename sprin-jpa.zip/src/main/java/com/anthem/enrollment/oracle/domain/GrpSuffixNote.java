package com.anthem.enrollment.oracle.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "GRP_SUFFIX_NOTE")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class GrpSuffixNote {

	@Id
	// @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "GRP_SUFFIX_NOTE_ID")
	private Long grpSuffixNoteId;
	@Column(name = "GRP_SUFFIX_NOTE_TYPE_CD")
	private String noteTypeCd;
	@Column(name = "GRP_SUFFIX_NOTE_SQNC_NBR")
	private Long seqNo;
	@Version
	@Column(name = "VRSN_NBR")
	private Long versionNo;
	@Column(name = "TRMNTN_IND_CD")
	private String trmntnIndCd;
	@Column(name = "GRP_SUFFIX_NOTE_TXT")
	private String noteTxt;
	@Column(name = "MIG_NOTE_CREATD_BY_USER_ID")
	private String noteCrtdUsrId;
	
	//@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MIGRATION_NOTE_CREATD_DT")
	private Date noteCreatdDt;
	@Column(name = "IS_MLR_NOTES")
	private String isMlrNotes;
	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;
	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_ID")
	private Cntrct cntrctId;

	public Long getGrpSuffixNoteId() {
		return grpSuffixNoteId;
	}

	public void setGrpSuffixNoteId(Long grpSuffixNoteId) {
		this.grpSuffixNoteId = grpSuffixNoteId;
	}

	public String getNoteTypeCd() {
		return noteTypeCd;
	}

	public void setNoteTypeCd(String noteTypeCd) {
		this.noteTypeCd = noteTypeCd;
	}

	public Long getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}

	public Long getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Long versionNo) {
		this.versionNo = versionNo;
	}

	public String getTrmntnIndCd() {
		return trmntnIndCd;
	}

	public void setTrmntnIndCd(String trmntnIndCd) {
		this.trmntnIndCd = trmntnIndCd;
	}

	public String getNoteTxt() {
		return noteTxt;
	}

	public void setNoteTxt(String noteTxt) {
		this.noteTxt = noteTxt;
	}

	public String getNoteCrtdUsrId() {
		return noteCrtdUsrId;
	}

	public void setNoteCrtdUsrId(String noteCrtdUsrId) {
		this.noteCrtdUsrId = noteCrtdUsrId;
	}

	public Date getNoteCreatdDt() {
		return noteCreatdDt;
	}

	public void setNoteCreatdDt(Date noteCreatdDt) {
		this.noteCreatdDt = noteCreatdDt;
	}

	public String getIsMlrNotes() {
		return isMlrNotes;
	}

	public void setIsMlrNotes(String isMlrNotes) {
		this.isMlrNotes = isMlrNotes;
	}

	public String getCreatdByUserId() {
		return creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getCreatdDtm() {
		return creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Cntrct getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Cntrct cntrctId) {
		this.cntrctId = cntrctId;
	}

	
	
	

}
