package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the CNTRCT_PLAN_RT_DTLS database table.
 * 
 */
@Entity
@Table(name = "CNTRCT_PLAN_RT_DTLS")
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class CntrctPlanRtDtlDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "CNTRCT_PLAN_RT_DTLS_ID")
	private Long cntrctPlanRtDtlsId;
	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;
	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "LOC_CD")
	private BigDecimal locCd;

	@Column(name = "LOC_CNTRCT_TYPE01")
	private String locCntrctType01;

	@Column(name = "LOC_CNTRCT_TYPE02")
	private String locCntrctType02;

	@Column(name = "LOC_CNTRCT_TYPE03")
	private String locCntrctType03;

	@Column(name = "LOC_CNTRCT_TYPE04")
	private String locCntrctType04;

	@Column(name = "LOC_CNTRCT_TYPE05")
	private String locCntrctType05;

	@Column(name = "LOC_CNTRCT_TYPE06")
	private String locCntrctType06;

	@Column(name = "LOC_CNTRCT_TYPE07")
	private String locCntrctType07;

	@Column(name = "LOC_CNTRCT_TYPE08")
	private String locCntrctType08;

	@Column(name = "LOC_CNTRCT_TYPE09")
	private String locCntrctType09;

	@Column(name = "LOC_CNTRCT_TYPE10")
	private String locCntrctType10;

	@Column(name = "LOC_CNTRCT_TYPE11")
	private String locCntrctType11;

	@Column(name = "LOC_CNTRCT_TYPE12")
	private String locCntrctType12;

	@Column(name = "LOC_CNTRCT_TYPE13")
	private String locCntrctType13;

	@Column(name = "LOC_CNTRCT_TYPE14")
	private String locCntrctType14;

	@Column(name = "LOC_CNTRCT_TYPE15")
	private String locCntrctType15;

	@Column(name = "LOC_MSCITM")
	private String locMscitm;

	@Column(name = "LOC_RT_AMT01")
	private BigDecimal locRtAmt01;

	@Column(name = "LOC_RT_AMT02")
	private BigDecimal locRtAmt02;

	@Column(name = "LOC_RT_AMT03")
	private BigDecimal locRtAmt03;

	@Column(name = "LOC_RT_AMT04")
	private BigDecimal locRtAmt04;

	@Column(name = "LOC_RT_AMT05")
	private BigDecimal locRtAmt05;

	@Column(name = "LOC_RT_AMT06")
	private BigDecimal locRtAmt06;

	@Column(name = "LOC_RT_AMT07")
	private BigDecimal locRtAmt07;

	@Column(name = "LOC_RT_AMT08")
	private BigDecimal locRtAmt08;

	@Column(name = "LOC_RT_AMT09")
	private BigDecimal locRtAmt09;

	@Column(name = "LOC_RT_AMT10")
	private BigDecimal locRtAmt10;

	@Column(name = "LOC_RT_AMT11")
	private BigDecimal locRtAmt11;

	@Column(name = "LOC_RT_AMT12")
	private BigDecimal locRtAmt12;

	@Column(name = "LOC_RT_AMT13")
	private BigDecimal locRtAmt13;

	@Column(name = "LOC_RT_AMT14")
	private BigDecimal locRtAmt14;

	@Column(name = "LOC_RT_AMT15")
	private BigDecimal locRtAmt15;
	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String updtdByUserId;
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date updtdDtm;
	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	// bi-directional many-to-one association to CntrctPlanRtSmry
	/*@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "CNTRCT_PLAN_RT_SMRY_ID")
	private CntrctPlanRtSmry cntrctPlanRtSmry;*/

	@Column(name = "CNTRCT_PLAN_RT_SMRY_ID")
	private Long cntrctPlanRtSmryId;
	

	public Long getCntrctPlanRtSmryId() {
		return cntrctPlanRtSmryId;
	}

	public void setCntrctPlanRtSmryId(Long cntrctPlanRtSmryId) {
		this.cntrctPlanRtSmryId = cntrctPlanRtSmryId;
	}

	public Long getCntrctPlanRtDtlsId() {
		return this.cntrctPlanRtDtlsId;
	}

	public void setCntrctPlanRtDtlsId(Long cntrctPlanRtDtlsId) {
		this.cntrctPlanRtDtlsId = cntrctPlanRtDtlsId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public BigDecimal getLocCd() {
		return this.locCd;
	}

	public void setLocCd(BigDecimal locCd) {
		this.locCd = locCd;
	}

	public String getLocCntrctType01() {
		return this.locCntrctType01;
	}

	public void setLocCntrctType01(String locCntrctType01) {
		this.locCntrctType01 = locCntrctType01;
	}

	public String getLocCntrctType02() {
		return this.locCntrctType02;
	}

	public void setLocCntrctType02(String locCntrctType02) {
		this.locCntrctType02 = locCntrctType02;
	}

	public String getLocCntrctType03() {
		return this.locCntrctType03;
	}

	public void setLocCntrctType03(String locCntrctType03) {
		this.locCntrctType03 = locCntrctType03;
	}

	public String getLocCntrctType04() {
		return this.locCntrctType04;
	}

	public void setLocCntrctType04(String locCntrctType04) {
		this.locCntrctType04 = locCntrctType04;
	}

	public String getLocCntrctType05() {
		return this.locCntrctType05;
	}

	public void setLocCntrctType05(String locCntrctType05) {
		this.locCntrctType05 = locCntrctType05;
	}

	public String getLocCntrctType06() {
		return this.locCntrctType06;
	}

	public void setLocCntrctType06(String locCntrctType06) {
		this.locCntrctType06 = locCntrctType06;
	}

	public String getLocCntrctType07() {
		return this.locCntrctType07;
	}

	public void setLocCntrctType07(String locCntrctType07) {
		this.locCntrctType07 = locCntrctType07;
	}

	public String getLocCntrctType08() {
		return this.locCntrctType08;
	}

	public void setLocCntrctType08(String locCntrctType08) {
		this.locCntrctType08 = locCntrctType08;
	}

	public String getLocCntrctType09() {
		return this.locCntrctType09;
	}

	public void setLocCntrctType09(String locCntrctType09) {
		this.locCntrctType09 = locCntrctType09;
	}

	public String getLocCntrctType10() {
		return this.locCntrctType10;
	}

	public void setLocCntrctType10(String locCntrctType10) {
		this.locCntrctType10 = locCntrctType10;
	}

	public String getLocCntrctType11() {
		return this.locCntrctType11;
	}

	public void setLocCntrctType11(String locCntrctType11) {
		this.locCntrctType11 = locCntrctType11;
	}

	public String getLocCntrctType12() {
		return this.locCntrctType12;
	}

	public void setLocCntrctType12(String locCntrctType12) {
		this.locCntrctType12 = locCntrctType12;
	}

	public String getLocCntrctType13() {
		return this.locCntrctType13;
	}

	public void setLocCntrctType13(String locCntrctType13) {
		this.locCntrctType13 = locCntrctType13;
	}

	public String getLocCntrctType14() {
		return this.locCntrctType14;
	}

	public void setLocCntrctType14(String locCntrctType14) {
		this.locCntrctType14 = locCntrctType14;
	}

	public String getLocCntrctType15() {
		return this.locCntrctType15;
	}

	public void setLocCntrctType15(String locCntrctType15) {
		this.locCntrctType15 = locCntrctType15;
	}

	public String getLocMscitm() {
		return this.locMscitm;
	}

	public void setLocMscitm(String locMscitm) {
		this.locMscitm = locMscitm;
	}

	public BigDecimal getLocRtAmt01() {
		return this.locRtAmt01;
	}

	public void setLocRtAmt01(BigDecimal locRtAmt01) {
		this.locRtAmt01 = locRtAmt01;
	}

	public BigDecimal getLocRtAmt02() {
		return this.locRtAmt02;
	}

	public void setLocRtAmt02(BigDecimal locRtAmt02) {
		this.locRtAmt02 = locRtAmt02;
	}

	public BigDecimal getLocRtAmt03() {
		return this.locRtAmt03;
	}

	public void setLocRtAmt03(BigDecimal locRtAmt03) {
		this.locRtAmt03 = locRtAmt03;
	}

	public BigDecimal getLocRtAmt04() {
		return this.locRtAmt04;
	}

	public void setLocRtAmt04(BigDecimal locRtAmt04) {
		this.locRtAmt04 = locRtAmt04;
	}

	public BigDecimal getLocRtAmt05() {
		return this.locRtAmt05;
	}

	public void setLocRtAmt05(BigDecimal locRtAmt05) {
		this.locRtAmt05 = locRtAmt05;
	}

	public BigDecimal getLocRtAmt06() {
		return this.locRtAmt06;
	}

	public void setLocRtAmt06(BigDecimal locRtAmt06) {
		this.locRtAmt06 = locRtAmt06;
	}

	public BigDecimal getLocRtAmt07() {
		return this.locRtAmt07;
	}

	public void setLocRtAmt07(BigDecimal locRtAmt07) {
		this.locRtAmt07 = locRtAmt07;
	}

	public BigDecimal getLocRtAmt08() {
		return this.locRtAmt08;
	}

	public void setLocRtAmt08(BigDecimal locRtAmt08) {
		this.locRtAmt08 = locRtAmt08;
	}

	public BigDecimal getLocRtAmt09() {
		return this.locRtAmt09;
	}

	public void setLocRtAmt09(BigDecimal locRtAmt09) {
		this.locRtAmt09 = locRtAmt09;
	}

	public BigDecimal getLocRtAmt10() {
		return this.locRtAmt10;
	}

	public void setLocRtAmt10(BigDecimal locRtAmt10) {
		this.locRtAmt10 = locRtAmt10;
	}

	public BigDecimal getLocRtAmt11() {
		return this.locRtAmt11;
	}

	public void setLocRtAmt11(BigDecimal locRtAmt11) {
		this.locRtAmt11 = locRtAmt11;
	}

	public BigDecimal getLocRtAmt12() {
		return this.locRtAmt12;
	}

	public void setLocRtAmt12(BigDecimal locRtAmt12) {
		this.locRtAmt12 = locRtAmt12;
	}

	public BigDecimal getLocRtAmt13() {
		return this.locRtAmt13;
	}

	public void setLocRtAmt13(BigDecimal locRtAmt13) {
		this.locRtAmt13 = locRtAmt13;
	}

	public BigDecimal getLocRtAmt14() {
		return this.locRtAmt14;
	}

	public void setLocRtAmt14(BigDecimal locRtAmt14) {
		this.locRtAmt14 = locRtAmt14;
	}

	public BigDecimal getLocRtAmt15() {
		return this.locRtAmt15;
	}

	public void setLocRtAmt15(BigDecimal locRtAmt15) {
		this.locRtAmt15 = locRtAmt15;
	}

	public String getUpdtdByUserId() {
		return this.updtdByUserId;
	}

	public void setUpdtdByUserId(String updtdByUserId) {
		this.updtdByUserId = updtdByUserId;
	}

	public Date getUpdtdDtm() {
		return this.updtdDtm;
	}

	public void setUpdtdDtm(Date updtdDtm) {
		this.updtdDtm = updtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	/*public CntrctPlanRtSmry getCntrctPlanRtSmry() {
		return this.cntrctPlanRtSmry;
	}

	public void setCntrctPlanRtSmry(CntrctPlanRtSmry cntrctPlanRtSmry) {
		this.cntrctPlanRtSmry = cntrctPlanRtSmry;
	}*/

}