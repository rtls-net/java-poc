package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the CNCRNCY_LOCK database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNCRNCY_LOCK")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CncrncyLock implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CNCRNCY_LOCK_ID")
	private long cncrncyLockId;

	@Column(name="CASE_NBR")
	private String caseNbr;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name="SCRN_ID")
	private String scrnId;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	public CncrncyLock() {
	}

	public long getCncrncyLockId() {
		return this.cncrncyLockId;
	}

	public void setCncrncyLockId(long cncrncyLockId) {
		this.cncrncyLockId = cncrncyLockId;
	}

	public String getCaseNbr() {
		return this.caseNbr;
	}

	public void setCaseNbr(String caseNbr) {
		this.caseNbr = caseNbr;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getScrnId() {
		return this.scrnId;
	}

	public void setScrnId(String scrnId) {
		this.scrnId = scrnId;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

}