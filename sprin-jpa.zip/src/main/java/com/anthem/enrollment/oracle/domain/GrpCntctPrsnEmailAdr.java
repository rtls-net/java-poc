package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the GRP_CNTCT_PRSN_EMAIL_ADRS database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_CNTCT_PRSN_EMAIL_ADRS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpCntctPrsnEmailAdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_CNTCT_PRSN_EMAIL_ADRS_ID")
	private long grpCntctPrsnEmailAdrsId;

	@Column(name="CNTCT_PRSN_ID")
	private BigDecimal cntctPrsnId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_EFCTV_DT")
	private Date grpCntctPrsnEfctvDt;

	@Column(name="GRP_CNTCT_PRSN_EMAIL_ADRS_TXT")
	private String grpCntctPrsnEmailAdrsTxt;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_EMAIL_EFCTV_DT")
	private Date grpCntctPrsnEmailEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_EMAIL_TRMNTN_DT")
	private Date grpCntctPrsnEmailTrmntnDt;

	@Column(name="GRP_CNTCT_PRSN_EMAIL_TYPE_CD")
	private String grpCntctPrsnEmailTypeCd;

	@Column(name="GRP_CNTCT_TYPE_CD")
	private String grpCntctTypeCd;

	@Column(name="GRP_ID")
	private BigDecimal grpId;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to GrpCntctPrsn
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_CNTCT_PRSN_ID")
	private GrpCntctPrsn grpCntctPrsn;

	public GrpCntctPrsnEmailAdr() {
	}

	public long getGrpCntctPrsnEmailAdrsId() {
		return this.grpCntctPrsnEmailAdrsId;
	}

	public void setGrpCntctPrsnEmailAdrsId(long grpCntctPrsnEmailAdrsId) {
		this.grpCntctPrsnEmailAdrsId = grpCntctPrsnEmailAdrsId;
	}

	public BigDecimal getCntctPrsnId() {
		return this.cntctPrsnId;
	}

	public void setCntctPrsnId(BigDecimal cntctPrsnId) {
		this.cntctPrsnId = cntctPrsnId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpCntctPrsnEfctvDt() {
		return this.grpCntctPrsnEfctvDt;
	}

	public void setGrpCntctPrsnEfctvDt(Date grpCntctPrsnEfctvDt) {
		this.grpCntctPrsnEfctvDt = grpCntctPrsnEfctvDt;
	}

	public String getGrpCntctPrsnEmailAdrsTxt() {
		return this.grpCntctPrsnEmailAdrsTxt;
	}

	public void setGrpCntctPrsnEmailAdrsTxt(String grpCntctPrsnEmailAdrsTxt) {
		this.grpCntctPrsnEmailAdrsTxt = grpCntctPrsnEmailAdrsTxt;
	}

	public Date getGrpCntctPrsnEmailEfctvDt() {
		return this.grpCntctPrsnEmailEfctvDt;
	}

	public void setGrpCntctPrsnEmailEfctvDt(Date grpCntctPrsnEmailEfctvDt) {
		this.grpCntctPrsnEmailEfctvDt = grpCntctPrsnEmailEfctvDt;
	}

	public Date getGrpCntctPrsnEmailTrmntnDt() {
		return this.grpCntctPrsnEmailTrmntnDt;
	}

	public void setGrpCntctPrsnEmailTrmntnDt(Date grpCntctPrsnEmailTrmntnDt) {
		this.grpCntctPrsnEmailTrmntnDt = grpCntctPrsnEmailTrmntnDt;
	}

	public String getGrpCntctPrsnEmailTypeCd() {
		return this.grpCntctPrsnEmailTypeCd;
	}

	public void setGrpCntctPrsnEmailTypeCd(String grpCntctPrsnEmailTypeCd) {
		this.grpCntctPrsnEmailTypeCd = grpCntctPrsnEmailTypeCd;
	}

	public String getGrpCntctTypeCd() {
		return this.grpCntctTypeCd;
	}

	public void setGrpCntctTypeCd(String grpCntctTypeCd) {
		this.grpCntctTypeCd = grpCntctTypeCd;
	}

	public BigDecimal getGrpId() {
		return this.grpId;
	}

	public void setGrpId(BigDecimal grpId) {
		this.grpId = grpId;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public GrpCntctPrsn getGrpCntctPrsn() {
		return this.grpCntctPrsn;
	}

	public void setGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		this.grpCntctPrsn = grpCntctPrsn;
	}

}