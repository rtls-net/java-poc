package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.util.CollectionUtils;

import java.io.Serializable;
import java.util.*;

/**
 * GroupInfo - This class wraps all domain objects related to Group.
 * 
 * @author Deloitte
 * @version 1.0
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class GroupInfo implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The group. */
	private Grp group;
	
	/** The lgcy grp chart field. */
	private LgcyGrpCf lgcyGrpChartField;
	
	/** The grp health card. */
	private GrpHc grpHealthCard;
	
	/** The contract. */
	private Cntrct contract;

	/** The grp indctv. */
	private GrpIndctv grpIndctv;

	/** The grp spcl instrctn. */
	private GrpSpclInstrctn grpSpclInstrctn;

	/** The num of emp grp size. */
	private GrpSize numOfEmpGrpSize;

	/** The medical grp size. */
	private GrpSize medicalGrpSize;

	/** The dental grp size. */
	private GrpSize dentalGrpSize;

	/** The vision grp size. */
	private GrpSize visionGrpSize;

	/** The lifen di grp size. */
	private GrpSize lifenDiGrpSize;

	/** The case efctv dt. */
	private transient Date caseEfctvDt;

	/** The lgcy group id list. */
	private transient List<String> lgcyGroupIdList;

	/** The group map. */
	private transient Map<String,Grp> groupMap;

	/** The grp cntrct prvsn. */
	private GrpCntrctPrvsn grpCntrctPrvsn;

	/** The grp note. */
	private GrpNote grpNote;

	/** The error exists new grp. */
	private boolean errorExistsNewGrp;

	/** Case Number */
	private String caseNumber;

	private GrpToGrpRltnshp grpToGrpRltnshp;


	/**
	 * Constructs GroupInfo with default member values.
	 */
	/*public GroupInfo(){
		group = new Grp();
		lgcyGrpChartField = new LgcyGrpCf();
		grpHealthCard = new GrpHc();
		contract = new Cntrct();
		grpCntrctPrvsn = new GrpCntrctPrvsn();
		grpIndctv = new GrpIndctv();
  	    grpSpclInstrctn = new GrpSpclInstrctn();
  	    numOfEmpGrpSize = new GrpSize();
  	    medicalGrpSize = new GrpSize();
  	    dentalGrpSize = new GrpSize();
  	    visionGrpSize = new GrpSize();
  	    lifenDiGrpSize = new GrpSize();
  	    grpNote = new GrpNote();
	} */

	public GroupInfo(){

	}

	/**
	 * Gets the group.
	 *
	 * @return Grp
	 */
	public Grp getGroup() {
		return group;
	}

	/**
	 * Sets the group.
	 *
	 * @param group the new group
	 */
	public void setGroup(Grp group) {
		this.group = group;
	}

	/**
	 * Gets the lgcy group chart field.
	 *
	 * @return LgcyGrpCf
	 */
	public LgcyGrpCf getLgcyGrpChartField() {
		return lgcyGrpChartField;
	}

	/**
	 * Sets the lgcy group chart field.
	 *
	 * @param lgcyGrpChartField the new lgcy group chart field
	 */
	public void setLgcyGrpChartField(LgcyGrpCf lgcyGrpChartField) {
		this.lgcyGrpChartField = lgcyGrpChartField;
	}

	/**
	 * Gets the group health card.
	 *
	 * @return GrpHc
	 */
	public GrpHc getGrpHealthCard() {
		return grpHealthCard;
	}

	/**
	 * Sets the group health card.
	 *
	 * @param grpHealthCard the new group health card
	 */
	public void setGrpHealthCard(GrpHc grpHealthCard) {
		this.grpHealthCard = grpHealthCard;
	}

	/**
	 * Gets the contract.
	 *
	 * @return Cntrct
	 */
	public Cntrct getContract() {
		return contract;
	}

	/**
	 * Sets the contract.
	 *
	 * @param contract the new contract
	 */
	public void setContract(Cntrct contract) {
		this.contract = contract;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return long
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * Gets the group indctv.
	 *
	 * @return GrpIndctv
	 */
	public GrpIndctv getGrpIndctv() {
		return grpIndctv;
	}

	/**
	 * Sets the group indctv.
	 *
	 * @param grpIndctv the new group indctv
	 */
	public void setGrpIndctv(GrpIndctv grpIndctv) {
		this.grpIndctv = grpIndctv;
	}

	/**
	 * Gets the group spcl instrctn.
	 *
	 * @return GrpSpclInstrctn
	 */
	public GrpSpclInstrctn getGrpSpclInstrctn() {
		return grpSpclInstrctn;
	}

	/**
	 * Sets the group spcl instrctn.
	 *
	 * @param grpSpclInstrctn the new group spcl instrctn
	 */
	public void setGrpSpclInstrctn(GrpSpclInstrctn grpSpclInstrctn) {
		this.grpSpclInstrctn = grpSpclInstrctn;
	}

	/**
	 * Gets the num of emp group size.
	 *
	 * @return GrpSize
	 */
	public GrpSize getNumOfEmpGrpSize() {
		return numOfEmpGrpSize;
	}

	/**
	 * Sets the num of emp group size.
	 *
	 * @param numOfEmpGrpSize the new num of emp group size
	 */
	public void setNumOfEmpGrpSize(GrpSize numOfEmpGrpSize) {
		this.numOfEmpGrpSize = numOfEmpGrpSize;
	}

	/**
	 * Gets the medical group size.
	 *
	 * @return GrpSize
	 */
	public GrpSize getMedicalGrpSize() {
		return medicalGrpSize;
	}

	/**
	 * Sets the medical group size.
	 *
	 * @param medicalGrpSize the new medical group size
	 */
	public void setMedicalGrpSize(GrpSize medicalGrpSize) {
		this.medicalGrpSize = medicalGrpSize;
	}

	/**
	 * Gets the dental group size.
	 *
	 * @return GrpSize
	 */
	public GrpSize getDentalGrpSize() {
		return dentalGrpSize;
	}

	/**
	 * Sets the dental group size.
	 *
	 * @param dentalGrpSize the new dental group size
	 */
	public void setDentalGrpSize(GrpSize dentalGrpSize) {
		this.dentalGrpSize = dentalGrpSize;
	}

	/**
	 * Gets the vision group size.
	 *
	 * @return GrpSize
	 */
	public GrpSize getVisionGrpSize() {
		return visionGrpSize;
	}

	/**
	 * Sets the vision group size.
	 *
	 * @param visionGrpSize the new vision group size
	 */
	public void setVisionGrpSize(GrpSize visionGrpSize) {
		this.visionGrpSize = visionGrpSize;
	}

	/**
	 * Gets the lifen di group size.
	 *
	 * @return GrpSize
	 */
	public GrpSize getLifenDiGrpSize() {
		return lifenDiGrpSize;
	}

	/**
	 * Sets the lifen di group size.
	 *
	 * @param lifenDiGrpSize the new lifen di group size
	 */
	public void setLifenDiGrpSize(GrpSize lifenDiGrpSize) {
		this.lifenDiGrpSize = lifenDiGrpSize;
	}

	/**
	 * Gets the case efctv date.
	 *
	 * @return Date
	 */
	public Date getCaseEfctvDt() {
		return caseEfctvDt != null ? new Date(caseEfctvDt.getTime()) : null;
	}

	/**
	 * Sets the case efctv date.
	 *
	 * @param caseEfctvDt the new case efctv date
	 */
	public void setCaseEfctvDt(Date caseEfctvDt) {
		this.caseEfctvDt = caseEfctvDt;
	}

	/**
	 * Gets the lgcy group id list.
	 *
	 * @return List<String>
	 */
	public List<String> getLgcyGroupIdList() {
		if(CollectionUtils.isEmpty(lgcyGroupIdList)){
			lgcyGroupIdList = new ArrayList<String>();
		}
		return lgcyGroupIdList;
	}

	/**
	 * Gets the group map.
	 *
	 * @return Map<String,Grp>
	 */
	public Map<String, Grp> getGroupMap() {
		if(CollectionUtils.isEmpty(groupMap)){
			groupMap = new LinkedHashMap<String, Grp>();
		}
		return groupMap;
	}

	/**
	 * Sets the group map.
	 *
	 * @param groupMap the group map
	 */
	public void setGroupMap(Map<String, Grp> groupMap) {
		this.groupMap = groupMap;
	}

	/**
	 * Sets the lgcy group id list.
	 *
	 * @param lgcyGroupIdList the new lgcy group id list
	 */
	public void setLgcyGroupIdList(List<String> lgcyGroupIdList) {
		this.lgcyGroupIdList = lgcyGroupIdList;
	}

	/**
	 * Gets the group cntrct prvsn.
	 *
	 * @return GrpCntrctPrvsn
	 */
	public GrpCntrctPrvsn getGrpCntrctPrvsn() {
		return grpCntrctPrvsn;
	}

	/**
	 * Sets the group cntrct prvsn.
	 *
	 * @param grpCntrctPrvsn the new group cntrct prvsn
	 */
	public void setGrpCntrctPrvsn(GrpCntrctPrvsn grpCntrctPrvsn) {
		this.grpCntrctPrvsn = grpCntrctPrvsn;
	}

	/**
	 * Gets the group note.
	 *
	 * @return GrpNote
	 */
	public GrpNote getGrpNote() {
		return grpNote;
	}

	/**
	 * Sets the group note.
	 *
	 * @param grpNote the new group note
	 */
	public void setGrpNote(GrpNote grpNote) {
		this.grpNote = grpNote;
	}

	/**
	 * Checks if is error exists new group.
	 *
	 * @return boolean
	 */
	public boolean isErrorExistsNewGrp() {
		return errorExistsNewGrp;
	}

	/**
	 * Sets the error exists new group.
	 *
	 * @param errorExistsNewGrp the new error exists new group
	 */
	public void setErrorExistsNewGrp(boolean errorExistsNewGrp) {
		this.errorExistsNewGrp = errorExistsNewGrp;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public GrpToGrpRltnshp getGrpToGrpRltnshp() {
		return grpToGrpRltnshp;
	}

	public void setGrpToGrpRltnshp(GrpToGrpRltnshp grpToGrpRltnshp) {
		this.grpToGrpRltnshp = grpToGrpRltnshp;
	}
}
