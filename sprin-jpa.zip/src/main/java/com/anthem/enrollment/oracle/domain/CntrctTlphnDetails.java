package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTRCT_TLPHN")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctTlphnDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CNTRCT_TLPHN_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctTlphnId;
	
	//@Column(name="CNTRCT_ID")
	//private long cntrctId;
	
	@Column(name="CNTRCT_TLPHN_TYPE_CD")
	private String cntrctTlphnTypeCd;
	
	@Column(name="CNTRCT_TLPHN_NBR")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctTlphnNbr;
	
	@Column(name="CNTRCT_TLPHN_CNTRY_CD")
	private String cntrctTlphnCntryCd;
	
	@Column(name="CNTRCT_TLPHN_EXT_NBR")
	private String cntrctTlphnExtNbr;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_TLPHN_EFCTV_DT")
	private java.util.Date cntrctTlphnEfctvDt;
	
	@Temporal(TemporalType.DATE)
	@Column(name="CNTRCT_TLPHN_TRMNTN_DT")
	private java.util.Date cntrctTlphnTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to Cntrct Plan
	/* @JsonIgnore
	 @OneToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	 @JoinColumn(name="CNTRCT_ID") 
	 private Cntrct cntrct;*/
	 
	@Column(name="CNTRCT_ID")
	private Long cntrctId;
	 
	

	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	public Long getCntrctTlphnId() {
		return cntrctTlphnId;
	}

	public void setCntrctTlphnId(Long cntrctTlphnId) {
		this.cntrctTlphnId = cntrctTlphnId;
	}

	public String getCntrctTlphnTypeCd() {
		return cntrctTlphnTypeCd;
	}

	public void setCntrctTlphnTypeCd(String cntrctTlphnTypeCd) {
		this.cntrctTlphnTypeCd = cntrctTlphnTypeCd;
	}

	public Long getCntrctTlphnNbr() {
		return cntrctTlphnNbr;
	}

	public void setCntrctTlphnNbr(Long cntrctTlphnNbr) {
		this.cntrctTlphnNbr = cntrctTlphnNbr;
	}

	public String getCntrctTlphnCntryCd() {
		return cntrctTlphnCntryCd;
	}

	public void setCntrctTlphnCntryCd(String cntrctTlphnCntryCd) {
		this.cntrctTlphnCntryCd = cntrctTlphnCntryCd;
	}

	public java.util.Date getCntrctTlphnEfctvDt() {
		return cntrctTlphnEfctvDt;
	}

	public void setCntrctTlphnEfctvDt(java.util.Date cntrctTlphnEfctvDt) {
		this.cntrctTlphnEfctvDt = cntrctTlphnEfctvDt;
	}

	public java.util.Date getCntrctTlphnTrmntnDt() {
		return cntrctTlphnTrmntnDt;
	}

	public void setCntrctTlphnTrmntnDt(java.util.Date cntrctTlphnTrmntnDt) {
		this.cntrctTlphnTrmntnDt = cntrctTlphnTrmntnDt;
	}

	public String getCreatdByUserId() {
		return creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	/*public Cntrct getCntrct() {
		return cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}*/

	public String getCntrctTlphnExtNbr() {
		return cntrctTlphnExtNbr;
	}

	public void setCntrctTlphnExtNbr(String cntrctTlphnExtNbr) {
		this.cntrctTlphnExtNbr = cntrctTlphnExtNbr;
	}

	
	 
}