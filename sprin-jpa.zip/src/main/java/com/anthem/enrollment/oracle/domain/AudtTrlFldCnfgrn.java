package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;


/**
 * The persistent class for the AUDT_TRL_FLD_CNFGRN database table.
 * @author Deloitte.
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="AUDT_TRL_FLD_CNFGRN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AudtTrlFldCnfgrn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="AUDT_TRL_FLD_CNFGRN_ID")
	private Long audtTrlFldCnfgrnId;

	@Column(name="AUDIT_FLG")
	private String auditFlg;

	@Column(name="AUDT_TRL_CNFGRN_ID")
	private BigDecimal audtTrlCnfgrnId;

	@Column(name="ENTITY_NM")
	private String entityNm;

	@Column(name="FLD_CD")
	private String fldCd;

	@Column(name="FLD_NM")
	private String fldNm;

	@Column(name="LOB_CD")
	private String lobCd;

	@Column(name="ST_CD")
	private String stCd;

	public AudtTrlFldCnfgrn() {
	}

	public Long getAudtTrlFldCnfgrnId() {
		return this.audtTrlFldCnfgrnId;
	}

	public void setAudtTrlFldCnfgrnId(Long audtTrlFldCnfgrnId) {
		this.audtTrlFldCnfgrnId = audtTrlFldCnfgrnId;
	}

	public String getAuditFlg() {
		return this.auditFlg;
	}

	public void setAuditFlg(String auditFlg) {
		this.auditFlg = auditFlg;
	}

	public BigDecimal getAudtTrlCnfgrnId() {
		return this.audtTrlCnfgrnId;
	}

	public void setAudtTrlCnfgrnId(BigDecimal audtTrlCnfgrnId) {
		this.audtTrlCnfgrnId = audtTrlCnfgrnId;
	}

	public String getEntityNm() {
		return this.entityNm;
	}

	public void setEntityNm(String entityNm) {
		this.entityNm = entityNm;
	}

	public String getFldCd() {
		return this.fldCd;
	}

	public void setFldCd(String fldCd) {
		this.fldCd = fldCd;
	}

	public String getFldNm() {
		return this.fldNm;
	}

	public void setFldNm(String fldNm) {
		this.fldNm = fldNm;
	}

	public String getLobCd() {
		return this.lobCd;
	}

	public void setLobCd(String lobCd) {
		this.lobCd = lobCd;
	}

	public String getStCd() {
		return this.stCd;
	}

	public void setStCd(String stCd) {
		this.stCd = stCd;
	}

}