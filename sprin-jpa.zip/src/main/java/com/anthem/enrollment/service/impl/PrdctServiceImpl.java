package com.anthem.enrollment.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.anthem.enrollment.oracle.dao.CntrctDAO;
import com.anthem.enrollment.oracle.dao.CntrctDetailsDAO;
import com.anthem.enrollment.oracle.domain.Adrs;
import com.anthem.enrollment.oracle.domain.AdrsDetails;
import com.anthem.enrollment.oracle.domain.BillgEnty;
import com.anthem.enrollment.oracle.domain.BillgEntyDetails;
import com.anthem.enrollment.oracle.domain.Cntrct;
import com.anthem.enrollment.oracle.domain.CntrctAdrs;
import com.anthem.enrollment.oracle.domain.CntrctAdrsDetails;
import com.anthem.enrollment.oracle.domain.CntrctBillgEnty;
import com.anthem.enrollment.oracle.domain.CntrctBillgEntyDetails;
import com.anthem.enrollment.oracle.domain.CntrctDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlan;
import com.anthem.enrollment.oracle.domain.CntrctPlanDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanProvNtwk;
import com.anthem.enrollment.oracle.domain.CntrctPlanProvNtwkDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRt;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtDtl;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtDtlDetails;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtSmry;
import com.anthem.enrollment.oracle.domain.CntrctPlanRtSmryDetails;
import com.anthem.enrollment.oracle.domain.CntrctTlphn;
import com.anthem.enrollment.oracle.domain.CntrctTlphnDetails;
import com.anthem.enrollment.oracle.domain.GrpCntrctPrvsn;
import com.anthem.enrollment.oracle.domain.GrpCntrctPrvsnDetails;
import com.anthem.enrollment.oracle.domain.GrpHc;
import com.anthem.enrollment.oracle.domain.GrpHcDetails;
import com.anthem.enrollment.oracle.domain.GrpMnthlyCntrbtn;
import com.anthem.enrollment.oracle.domain.GrpMnthlyCntrbtnDetails;
import com.anthem.enrollment.oracle.domain.GrpPrbtnPrd;
import com.anthem.enrollment.service.PrdctService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
@Transactional(rollbackFor = Exception.class)
public class PrdctServiceImpl implements PrdctService {
	
	@Autowired
	private CntrctDAO cntrctDAO;
	
	@Autowired
	private CntrctDetailsDAO cntrctDetailsDAO;

	@Autowired
	private ObjectMapper objectMapper;



	@Override
	public List<Cntrct> getCntrctdetails(Long grpId,String cvrgTypCd) {
		List<Cntrct>  cntrctdtlsLst = null;
		try {
		//cntrcts = cntrctDAO.findByGrpGrpId(grpId);
		Long start = System.currentTimeMillis();
		//List<CntrctDetails>  cntrcts1 = cntrctDetailsDAO.getCntrctDetails(grpId,org.springframework.data.domain.Pageable.ofSize(100000));
		CompletableFuture<List<Cntrct>> cntrctDetails = CompletableFuture.supplyAsync(() -> {
		     List<CntrctDetails>  cntrctslst = cntrctDetailsDAO.getCntrctDetails(grpId);
		     return  objectMapper.convertValue(cntrctslst,new TypeReference<List<Cntrct>>() {});
			 //String str = objectMapper.writeValueAsString(cntrctslst);
			 //objectMapper.readValue(str, TypeReference.)
			 //return cntrctDetailsDAO.getCntrctDetails(grpId);
		});
		CompletableFuture<Map<Long,CntrctPlan>> cntrctPlanDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanDetails> planlst =  cntrctDetailsDAO.getCntrctPlanDetails(grpId);
			List<CntrctPlan> cntrctPlanLst = objectMapper.convertValue(planlst,new TypeReference<List<CntrctPlan>>() {});
			Map<Long,CntrctPlan> planMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanLst)) {
				planMap = cntrctPlanLst.stream().collect(Collectors.toMap(CntrctPlan::getCntrctId, Function.identity()));
			}
			return planMap;
		});
		
		CompletableFuture<Map<Long,CntrctAdrs>> cntrctAdrsDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctAdrsDetails> cntrctAdrsDetailslst =  cntrctDetailsDAO.getCntrctAdrsDetails(grpId);
			List<CntrctAdrs> cntrctAdrsLst = objectMapper.convertValue(cntrctAdrsDetailslst,new TypeReference<List<CntrctAdrs>>() {});
			Map<Long,CntrctAdrs> cntrctAdrsMap = null;
			if(!CollectionUtils.isEmpty(cntrctAdrsLst)) {
				cntrctAdrsMap = cntrctAdrsLst.stream().collect(Collectors.toMap(CntrctAdrs::getCntrctId, Function.identity()));
			}
			return cntrctAdrsMap;
		});
		
		CompletableFuture<Map<Long,CntrctBillgEnty>> cntrcBillgEntityDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctBillgEntyDetails> cntrctBillgDetailslst =  cntrctDetailsDAO.getCntrctBillgEntityDetails(grpId);
			List<CntrctBillgEnty> cntrctBillgLst = objectMapper.convertValue(cntrctBillgDetailslst,new TypeReference<List<CntrctBillgEnty>>() {});
			Map<Long,CntrctBillgEnty> cntrctBillgsMap = null;
			if(!CollectionUtils.isEmpty(cntrctBillgLst)) {
				cntrctBillgsMap = cntrctBillgLst.stream().collect(Collectors.toMap(CntrctBillgEnty::getCntrctId, Function.identity()));
			}
			return cntrctBillgsMap;
		});
		
		CompletableFuture<Map<Long,Adrs>> adrsDetails = CompletableFuture.supplyAsync(() -> {
			List<AdrsDetails> adrsDetailslst =  cntrctDetailsDAO.getAdrsDetails(grpId);
			List<Adrs> adrsLst = objectMapper.convertValue(adrsDetailslst,new TypeReference<List<Adrs>>() {});
			Map<Long,Adrs> adrsMap = null;
			if(!CollectionUtils.isEmpty(adrsLst)) {
				adrsMap = adrsLst.stream().collect(Collectors.toMap(Adrs::getAdrsId, Function.identity()));
			}
			return adrsMap;
		});
		
		CompletableFuture<Map<Long,CntrctTlphn>> cntrctTlphnDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctTlphnDetails> cntrctTlphnsDetailslst =  cntrctDetailsDAO.getCntrctTlphnDetails(grpId);
			List<CntrctTlphn> cntrctTlphnLst = objectMapper.convertValue(cntrctTlphnsDetailslst,new TypeReference<List<CntrctTlphn>>() {});
			Map<Long,CntrctTlphn> cntrctTlphnMap = null;
			if(!CollectionUtils.isEmpty(cntrctTlphnLst)) {
				cntrctTlphnMap = cntrctTlphnLst.stream().collect(Collectors.toMap(CntrctTlphn::getCntrctId, Function.identity()));
			}
			return cntrctTlphnMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanProvNtwk>> cntrctPlanProvNtwkDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanProvNtwkDetails> cntrctPlanProvNtwkDetailslst =  cntrctDetailsDAO.getCntrctPlanProvNtwkDetails(grpId);
			List<CntrctPlanProvNtwk> cntrctTlphnLst = objectMapper.convertValue(cntrctPlanProvNtwkDetailslst,new TypeReference<List<CntrctPlanProvNtwk>>() {});
			Map<Long,CntrctPlanProvNtwk> cntrctPlanProvNtwkMap = null;
			if(!CollectionUtils.isEmpty(cntrctTlphnLst)) {
				cntrctPlanProvNtwkMap = cntrctTlphnLst.stream().collect(Collectors.toMap(CntrctPlanProvNtwk::getCntrctId, Function.identity()));
			}
			return cntrctPlanProvNtwkMap;
		});
		
		CompletableFuture<Map<Long,GrpCntrctPrvsn>> grpCntrctPrvsnDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpCntrctPrvsnDetails> grpCntrctPrvsnDetailslst =  cntrctDetailsDAO.getGrpCntrctPrvsnDetails(grpId);
			List<GrpCntrctPrvsn> grpCntrctPrvsnLst = objectMapper.convertValue(grpCntrctPrvsnDetailslst,new TypeReference<List<GrpCntrctPrvsn>>() {});
			Map<Long,GrpCntrctPrvsn> grpCntrctPrvsnDetailsMap = null;
			if(!CollectionUtils.isEmpty(grpCntrctPrvsnLst)) {
				grpCntrctPrvsnDetailsMap = grpCntrctPrvsnLst.stream().collect(Collectors.toMap(GrpCntrctPrvsn::getCntrctId, Function.identity()));
			}
			return grpCntrctPrvsnDetailsMap;
		});
		
		CompletableFuture<Map<Long,GrpHc>> grpHCDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpHcDetails> grpHcDetailslst =  cntrctDetailsDAO.getGrpHCDetails(grpId);
			List<GrpHc> grpHcLst = objectMapper.convertValue(grpHcDetailslst,new TypeReference<List<GrpHc>>() {});
			Map<Long,GrpHc> grpHcLstMap = null;
			if(!CollectionUtils.isEmpty(grpHcLst)) {
				grpHcLstMap = grpHcLst.stream().collect(Collectors.toMap(GrpHc::getCntrctPlanId, Function.identity()));
			}
			return grpHcLstMap;
		});
		CompletableFuture<Map<Long,GrpMnthlyCntrbtn>> grpMnthlyCntrbtnDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpMnthlyCntrbtnDetails> grpMcDetailslst =  cntrctDetailsDAO.getGrpMnthlyCntrbtnDetails(grpId);
			List<GrpMnthlyCntrbtn> grpMcLst = objectMapper.convertValue(grpMcDetailslst,new TypeReference<List<GrpMnthlyCntrbtn>>() {});
			Map<Long,GrpMnthlyCntrbtn> grpMcLstMap = null;
			if(!CollectionUtils.isEmpty(grpMcLst)) {
				grpMcLstMap = grpMcLst.stream().collect(Collectors.toMap(GrpMnthlyCntrbtn::getCntrctId, Function.identity()));
			}
			return grpMcLstMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanRt>> cntrctPlanRtDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtDetails> cntrctPlanRtDeailslst =  cntrctDetailsDAO.getCntrctPlanRtDetails(grpId,cvrgTypCd);
			List<CntrctPlanRt> cntrctPlanRtlst = objectMapper.convertValue(cntrctPlanRtDeailslst,new TypeReference<List<CntrctPlanRt>>() {});
			Map<Long,CntrctPlanRt> cntrctPlanRtMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtlst)) {
				cntrctPlanRtMap = cntrctPlanRtlst.stream().collect(Collectors.toMap(CntrctPlanRt::getCntrctPlanId, Function.identity()));
			}
			return cntrctPlanRtMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanRtSmry>> cntrctPlanRtSmryDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtSmryDetails> cntrctPlanRtSmryDeailslst =  cntrctDetailsDAO.getCntrctPlanRtSmryDetails(grpId,cvrgTypCd);
			List<CntrctPlanRtSmry> cntrctPlanRtSmrylst = objectMapper.convertValue(cntrctPlanRtSmryDeailslst,new TypeReference<List<CntrctPlanRtSmry>>() {});
			Map<Long,CntrctPlanRtSmry> cntrctPlanRtSmryMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtSmrylst)) {
				cntrctPlanRtSmryMap = cntrctPlanRtSmrylst.stream().collect(Collectors.toMap(CntrctPlanRtSmry::getCntrctPlanRtId, Function.identity()));
			}
			return cntrctPlanRtSmryMap;
		});
		
		CompletableFuture<Map<Long,List<CntrctPlanRtDtl>>> cntrctPlanRtDtlDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtDtlDetails> cntrctPlanRtDtlDeailslst =  cntrctDetailsDAO.getCntrctPlanRtDtlDetails(grpId,cvrgTypCd);
			List<CntrctPlanRtDtl> cntrctPlanRtDtllst = objectMapper.convertValue(cntrctPlanRtDtlDeailslst,new TypeReference<List<CntrctPlanRtDtl>>() {});
			Map<Long,List<CntrctPlanRtDtl>> cntrctPlanRtDtlMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtDtllst)) {
				//cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.toMap(groupingBy(CntrctPlanRtDtl::getCntrctPlanRtSmryId, Function.identity())));
				cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.groupingBy(CntrctPlanRtDtl::getCntrctPlanRtSmryId));
			}
			return cntrctPlanRtDtlMap;
		});
		
		CompletableFuture<Map<Long,BillgEnty>> billgEntyDetails = CompletableFuture.supplyAsync(() -> {
			List<BillgEntyDetails> billgEntylstDetailslst =  cntrctDetailsDAO.getbillgEntyDetails(grpId);
			List<BillgEnty> billgEntylst = objectMapper.convertValue(billgEntylstDetailslst,new TypeReference<List<BillgEnty>>() {});
			Map<Long,BillgEnty> billgEntylstMap = null;
			if(!CollectionUtils.isEmpty(billgEntylst)) {
				billgEntylstMap = billgEntylst.stream().collect(Collectors.toMap(BillgEnty::getBillgEntyId,Function.identity()));
			}
			return billgEntylstMap;
		});
		/*CompletableFuture<Map<Long,List<BillgEnty>>> billgEntyDetails = CompletableFuture.supplyAsync(() -> {
			List<BillgEntyDetails> billgEntylstDetailslst =  cntrctDetailsDAO.getbillgEntyDetails(grpId);
			List<BillgEnty> billgEntylst = objectMapper.convertValue(billgEntylstDetailslst,new TypeReference<List<BillgEnty>>() {});
			Map<Long,List<BillgEnty>> billgEntylstMap = null;
			if(!CollectionUtils.isEmpty(billgEntylst)) {
				billgEntylstMap = billgEntylst.stream().collect(Collectors.groupingBy(BillgEnty::getBillgEntyId));
			}
			return billgEntylstMap;
		});*/
		
		/*CompletableFuture<Map<Long,List<GrpPrbtnPrd>>> grpPrbtnPrdDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpPrbtnPrdDetails> grpPrbtnPrdDetailslst =  cntrctDetailsDAO.getGrpPrbtnPrdDetails(grpId,cvrgTypCd);
			List<GrpPrbtnPrd> cntrctPlanRtDtllst = objectMapper.convertValue(grpPrbtnPrdDetailslst,new TypeReference<List<GrpPrbtnPrd>>() {});
			Map<Long,List<GrpPrbtnPrd>> cntrctPlanRtDtlMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtDtllst)) {
				cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.groupingBy(GrpPrbtnPrd::getCntrctId));
			}
			return cntrctPlanRtDtlMap;
		});*/
		
		CompletableFuture<Void> finalCompletableFuture = CompletableFuture.allOf(cntrctDetails, cntrctPlanDetails,cntrctAdrsDetails,cntrcBillgEntityDetails,adrsDetails,
				cntrctTlphnDetails,cntrctPlanProvNtwkDetails,grpCntrctPrvsnDetails,grpHCDetails,grpMnthlyCntrbtnDetails,cntrctPlanRtDetails,cntrctPlanRtSmryDetails,
				cntrctPlanRtDtlDetails,billgEntyDetails);
		finalCompletableFuture.join();
		cntrctdtlsLst = cntrctDetails!=null?cntrctDetails.get():null;
		Map<Long,CntrctPlan>  cntrctPlandtlsMap = cntrctPlanDetails!=null?cntrctPlanDetails.get():null;
		Map<Long,CntrctAdrs> cntrctAdrsMap = cntrctAdrsDetails!=null?cntrctAdrsDetails.get():null;
		Map<Long,CntrctBillgEnty> cntrctBillgsMap = cntrcBillgEntityDetails!=null?cntrcBillgEntityDetails.get():null;
		Map<Long,Adrs> adrsMap = adrsDetails!=null?adrsDetails.get():null;
		Map<Long,CntrctTlphn> cntrctTlphnDetailsMap =cntrctTlphnDetails!=null?cntrctTlphnDetails.get():null;
		Map<Long,CntrctPlanProvNtwk> cntrctPlanProvNtwkDetailsMap = cntrctPlanProvNtwkDetails!=null?cntrctPlanProvNtwkDetails.get():null;
		Map<Long,GrpCntrctPrvsn> grpCntrctPrvsnMap = grpCntrctPrvsnDetails!=null?grpCntrctPrvsnDetails.get():null;
		Map<Long,GrpHc>grpHCMap = grpHCDetails!=null?grpHCDetails.get():null;
		Map<Long,GrpMnthlyCntrbtn>grpMCMap = grpMnthlyCntrbtnDetails!=null?grpMnthlyCntrbtnDetails.get():null;
		Map<Long,CntrctPlanRt>cntrctPlanRTMap = cntrctPlanRtDetails!=null?cntrctPlanRtDetails.get():null;
		Map<Long,CntrctPlanRtSmry>cntrctPlanRTSmryMap = cntrctPlanRtSmryDetails!=null?cntrctPlanRtSmryDetails.get():null;
		Map<Long,List<CntrctPlanRtDtl>> cntrctPlanRTDtlMap = cntrctPlanRtDtlDetails!=null?cntrctPlanRtDtlDetails.get():null;
//		Map<Long,List<BillgEnty>> billgEntityMap = billgEntyDetails!=null?billgEntyDetails.get():null;
		Map<Long,BillgEnty> billgEntityMap = billgEntyDetails!=null?billgEntyDetails.get():null;
		if(!CollectionUtils.isEmpty(cntrctdtlsLst)) {
			cntrctdtlsLst.parallelStream().forEach(cntrct->{
				cntrct.setCntrctPlan(cntrctPlandtlsMap!=null?cntrctPlandtlsMap.get(cntrct.getCntrctId()):null);
				cntrct.setCntrctAdrs(cntrctAdrsMap!=null?cntrctAdrsMap.get(cntrct.getCntrctId()):null);
				cntrct.setCntrctBillgEnties(cntrctBillgsMap!=null?Arrays.asList(cntrctBillgsMap.get(cntrct.getCntrctId())):null);
				if (!CollectionUtils.isEmpty(cntrct.getCntrctBillgEnties())) {
						List<CntrctBillgEnty> cntrctBillgEntyListCurrent = cntrct.getCntrctBillgEnties().stream().filter(cbe -> cbe.getCntrctBillgEntyTrmntnDt() == null).collect(Collectors.toList());
						if (!CollectionUtils.isEmpty(cntrctBillgEntyListCurrent)) {
							 cntrctBillgEntyListCurrent.stream().forEach(cbe->cbe.setBillgEnty(billgEntityMap!=null?billgEntityMap.get(cbe.getBillgEntyId()):null));
						}
				}
				if(cntrct.getCntrctAdrs()!=null) {
				  cntrct.getCntrctAdrs().setAdrs(adrsMap!=null?adrsMap.get(cntrct.getCntrctAdrs().getAdrsId()):null);
				}
				cntrct.setCntrctTlphn(cntrctTlphnDetailsMap!=null?cntrctTlphnDetailsMap.get(cntrct.getCntrctId()):null);
				if(cntrct.getCntrctPlan()!=null) {
					cntrct.getCntrctPlan().setCntrctPlanProvNtwk(cntrctPlanProvNtwkDetailsMap!=null?cntrctPlanProvNtwkDetailsMap.get(cntrct.getCntrctId()):null);
					cntrct.getCntrctPlan().setGrpHc(grpHCMap!=null?grpHCMap.get(cntrct.getCntrctPlan().getCntrctPlanId()):null);
					cntrct.getCntrctPlan().setCntrctPlanRt(cntrctPlanRTMap!=null?cntrctPlanRTMap.get(cntrct.getCntrctPlan().getCntrctPlanId()):null);
					if(cntrct.getCntrctPlan().getCntrctPlanRt()!=null) {
						cntrct.getCntrctPlan().getCntrctPlanRt().setCntrctPlanRtSmries(cntrctPlanRTSmryMap!=null?Arrays.asList(
								cntrctPlanRTSmryMap.get(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtId())):null);
						if(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries()!=null && cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().size()>0) {
							cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().get(0).setCntrctPlanRtDtls(cntrctPlanRTDtlMap!=null?
									cntrctPlanRTDtlMap.get(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().get(0).getCntrctPlanRtSmryId()):null);
						}
					}
				}
				cntrct.setGrpCntrctPrvsn(grpCntrctPrvsnMap!=null?grpCntrctPrvsnMap.get(cntrct.getCntrctId()):null);
				cntrct.setGrpMnthlyCntrbtn(grpMCMap!=null?grpMCMap.get(cntrct.getCntrctId()):null);
			});
		}
		
		
		Long end = System.currentTimeMillis();
		System.out.println("Total time took for : " +cntrctDetails.get().size()+" : "+(end-start));
		
		
	}catch(Exception e) {
		e.printStackTrace();
	}
		return cntrctdtlsLst;
	}
	
	//@Override
	public List<Cntrct> getCntrctdetails1(Long grpId,String cvrgTypCd) {
		List<Cntrct>  cntrctdtlsLst = null;
		try {
		//cntrcts = cntrctDAO.findByGrpGrpId(grpId);
		Long start = System.currentTimeMillis();
		//List<CntrctDetails>  cntrcts1 = cntrctDetailsDAO.getCntrctDetails(grpId,org.springframework.data.domain.Pageable.ofSize(100000));
		CompletableFuture<List<Cntrct>> cntrctDetails = CompletableFuture.supplyAsync(() -> {
		     List<CntrctDetails>  cntrctslst = cntrctDetailsDAO.getCntrctDetails(grpId);
		     return  objectMapper.convertValue(cntrctslst,new TypeReference<List<Cntrct>>() {});
			 //String str = objectMapper.writeValueAsString(cntrctslst);
			 //objectMapper.readValue(str, TypeReference.)
			 //return cntrctDetailsDAO.getCntrctDetails(grpId);
		});
		CompletableFuture<Map<Long,CntrctPlan>> cntrctPlanDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanDetails> planlst =  cntrctDetailsDAO.getCntrctPlanDetails(grpId);
			List<CntrctPlan> cntrctPlanLst = objectMapper.convertValue(planlst,new TypeReference<List<CntrctPlan>>() {});
			Map<Long,CntrctPlan> planMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanLst)) {
				planMap = cntrctPlanLst.stream().collect(Collectors.toMap(CntrctPlan::getCntrctId, Function.identity()));
			}
			return planMap;
		});
		
		CompletableFuture<Map<Long,CntrctAdrs>> cntrctAdrsDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctAdrsDetails> cntrctAdrsDetailslst =  cntrctDetailsDAO.getCntrctAdrsDetails(grpId);
			List<CntrctAdrs> cntrctAdrsLst = objectMapper.convertValue(cntrctAdrsDetailslst,new TypeReference<List<CntrctAdrs>>() {});
			Map<Long,CntrctAdrs> cntrctAdrsMap = null;
			if(!CollectionUtils.isEmpty(cntrctAdrsLst)) {
				cntrctAdrsMap = cntrctAdrsLst.stream().collect(Collectors.toMap(CntrctAdrs::getCntrctId, Function.identity()));
			}
			return cntrctAdrsMap;
		});
		
		CompletableFuture<Map<Long,CntrctBillgEnty>> cntrcBillgEntityDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctBillgEntyDetails> cntrctBillgDetailslst =  cntrctDetailsDAO.getCntrctBillgEntityDetails(grpId);
			List<CntrctBillgEnty> cntrctBillgLst = objectMapper.convertValue(cntrctBillgDetailslst,new TypeReference<List<CntrctBillgEnty>>() {});
			Map<Long,CntrctBillgEnty> cntrctBillgsMap = null;
			if(!CollectionUtils.isEmpty(cntrctBillgLst)) {
				cntrctBillgsMap = cntrctBillgLst.stream().collect(Collectors.toMap(CntrctBillgEnty::getCntrctId, Function.identity()));
			}
			return cntrctBillgsMap;
		});
		
		CompletableFuture<Map<Long,Adrs>> adrsDetails = CompletableFuture.supplyAsync(() -> {
			List<AdrsDetails> adrsDetailslst =  cntrctDetailsDAO.getAdrsDetails(grpId);
			List<Adrs> adrsLst = objectMapper.convertValue(adrsDetailslst,new TypeReference<List<Adrs>>() {});
			Map<Long,Adrs> adrsMap = null;
			if(!CollectionUtils.isEmpty(adrsLst)) {
				adrsMap = adrsLst.stream().collect(Collectors.toMap(Adrs::getAdrsId, Function.identity()));
			}
			return adrsMap;
		});
		
		CompletableFuture<Map<Long,CntrctTlphn>> cntrctTlphnDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctTlphnDetails> cntrctTlphnsDetailslst =  cntrctDetailsDAO.getCntrctTlphnDetails(grpId);
			List<CntrctTlphn> cntrctTlphnLst = objectMapper.convertValue(cntrctTlphnsDetailslst,new TypeReference<List<CntrctTlphn>>() {});
			Map<Long,CntrctTlphn> cntrctTlphnMap = null;
			if(!CollectionUtils.isEmpty(cntrctTlphnLst)) {
				cntrctTlphnMap = cntrctTlphnLst.stream().collect(Collectors.toMap(CntrctTlphn::getCntrctId, Function.identity()));
			}
			return cntrctTlphnMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanProvNtwk>> cntrctPlanProvNtwkDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanProvNtwkDetails> cntrctPlanProvNtwkDetailslst =  cntrctDetailsDAO.getCntrctPlanProvNtwkDetails(grpId);
			List<CntrctPlanProvNtwk> cntrctTlphnLst = objectMapper.convertValue(cntrctPlanProvNtwkDetailslst,new TypeReference<List<CntrctPlanProvNtwk>>() {});
			Map<Long,CntrctPlanProvNtwk> cntrctPlanProvNtwkMap = null;
			if(!CollectionUtils.isEmpty(cntrctTlphnLst)) {
				cntrctPlanProvNtwkMap = cntrctTlphnLst.stream().collect(Collectors.toMap(CntrctPlanProvNtwk::getCntrctId, Function.identity()));
			}
			return cntrctPlanProvNtwkMap;
		});
		
		CompletableFuture<Map<Long,GrpCntrctPrvsn>> grpCntrctPrvsnDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpCntrctPrvsnDetails> grpCntrctPrvsnDetailslst =  cntrctDetailsDAO.getGrpCntrctPrvsnDetails(grpId);
			List<GrpCntrctPrvsn> grpCntrctPrvsnLst = objectMapper.convertValue(grpCntrctPrvsnDetailslst,new TypeReference<List<GrpCntrctPrvsn>>() {});
			Map<Long,GrpCntrctPrvsn> grpCntrctPrvsnDetailsMap = null;
			if(!CollectionUtils.isEmpty(grpCntrctPrvsnLst)) {
				grpCntrctPrvsnDetailsMap = grpCntrctPrvsnLst.stream().collect(Collectors.toMap(GrpCntrctPrvsn::getCntrctId, Function.identity()));
			}
			return grpCntrctPrvsnDetailsMap;
		});
		
		CompletableFuture<Map<Long,GrpHc>> grpHCDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpHcDetails> grpHcDetailslst =  cntrctDetailsDAO.getGrpHCDetails(grpId);
			List<GrpHc> grpHcLst = objectMapper.convertValue(grpHcDetailslst,new TypeReference<List<GrpHc>>() {});
			Map<Long,GrpHc> grpHcLstMap = null;
			if(!CollectionUtils.isEmpty(grpHcLst)) {
				grpHcLstMap = grpHcLst.stream().collect(Collectors.toMap(GrpHc::getCntrctPlanId, Function.identity()));
			}
			return grpHcLstMap;
		});
		CompletableFuture<Map<Long,GrpMnthlyCntrbtn>> grpMnthlyCntrbtnDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpMnthlyCntrbtnDetails> grpMcDetailslst =  cntrctDetailsDAO.getGrpMnthlyCntrbtnDetails(grpId);
			List<GrpMnthlyCntrbtn> grpMcLst = objectMapper.convertValue(grpMcDetailslst,new TypeReference<List<GrpMnthlyCntrbtn>>() {});
			Map<Long,GrpMnthlyCntrbtn> grpMcLstMap = null;
			if(!CollectionUtils.isEmpty(grpMcLst)) {
				grpMcLstMap = grpMcLst.stream().collect(Collectors.toMap(GrpMnthlyCntrbtn::getCntrctId, Function.identity()));
			}
			return grpMcLstMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanRt>> cntrctPlanRtDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtDetails> cntrctPlanRtDeailslst =  cntrctDetailsDAO.getCntrctPlanRtDetails(grpId,cvrgTypCd);
			List<CntrctPlanRt> cntrctPlanRtlst = objectMapper.convertValue(cntrctPlanRtDeailslst,new TypeReference<List<CntrctPlanRt>>() {});
			Map<Long,CntrctPlanRt> cntrctPlanRtMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtlst)) {
				cntrctPlanRtMap = cntrctPlanRtlst.stream().collect(Collectors.toMap(CntrctPlanRt::getCntrctPlanId, Function.identity()));
			}
			return cntrctPlanRtMap;
		});
		
		CompletableFuture<Map<Long,CntrctPlanRtSmry>> cntrctPlanRtSmryDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtSmryDetails> cntrctPlanRtSmryDeailslst =  cntrctDetailsDAO.getCntrctPlanRtSmryDetails(grpId,cvrgTypCd);
			List<CntrctPlanRtSmry> cntrctPlanRtSmrylst = objectMapper.convertValue(cntrctPlanRtSmryDeailslst,new TypeReference<List<CntrctPlanRtSmry>>() {});
			Map<Long,CntrctPlanRtSmry> cntrctPlanRtSmryMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtSmrylst)) {
				cntrctPlanRtSmryMap = cntrctPlanRtSmrylst.stream().collect(Collectors.toMap(CntrctPlanRtSmry::getCntrctPlanRtId, Function.identity()));
			}
			return cntrctPlanRtSmryMap;
		});
		
		CompletableFuture<Map<Long,List<CntrctPlanRtDtl>>> cntrctPlanRtDtlDetails = CompletableFuture.supplyAsync(() -> {
			List<CntrctPlanRtDtlDetails> cntrctPlanRtDtlDeailslst =  cntrctDetailsDAO.getCntrctPlanRtDtlDetails(grpId,cvrgTypCd);
			List<CntrctPlanRtDtl> cntrctPlanRtDtllst = objectMapper.convertValue(cntrctPlanRtDtlDeailslst,new TypeReference<List<CntrctPlanRtDtl>>() {});
			Map<Long,List<CntrctPlanRtDtl>> cntrctPlanRtDtlMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtDtllst)) {
				//cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.toMap(groupingBy(CntrctPlanRtDtl::getCntrctPlanRtSmryId, Function.identity())));
				cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.groupingBy(CntrctPlanRtDtl::getCntrctPlanRtSmryId));
			}
			return cntrctPlanRtDtlMap;
		});
		
		CompletableFuture<Map<Long,BillgEnty>> billgEntyDetails = CompletableFuture.supplyAsync(() -> {
			List<BillgEntyDetails> billgEntylstDetailslst =  cntrctDetailsDAO.getbillgEntyDetails(grpId);
			List<BillgEnty> billgEntylst = objectMapper.convertValue(billgEntylstDetailslst,new TypeReference<List<BillgEnty>>() {});
			Map<Long,BillgEnty> billgEntylstMap = null;
			if(!CollectionUtils.isEmpty(billgEntylst)) {
				billgEntylstMap = billgEntylst.stream().collect(Collectors.toMap(BillgEnty::getBillgEntyId,Function.identity()));
			}
			return billgEntylstMap;
		});
		/*CompletableFuture<Map<Long,List<BillgEnty>>> billgEntyDetails = CompletableFuture.supplyAsync(() -> {
			List<BillgEntyDetails> billgEntylstDetailslst =  cntrctDetailsDAO.getbillgEntyDetails(grpId);
			List<BillgEnty> billgEntylst = objectMapper.convertValue(billgEntylstDetailslst,new TypeReference<List<BillgEnty>>() {});
			Map<Long,List<BillgEnty>> billgEntylstMap = null;
			if(!CollectionUtils.isEmpty(billgEntylst)) {
				billgEntylstMap = billgEntylst.stream().collect(Collectors.groupingBy(BillgEnty::getBillgEntyId));
			}
			return billgEntylstMap;
		});*/
		
		/*CompletableFuture<Map<Long,List<GrpPrbtnPrd>>> grpPrbtnPrdDetails = CompletableFuture.supplyAsync(() -> {
			List<GrpPrbtnPrdDetails> grpPrbtnPrdDetailslst =  cntrctDetailsDAO.getGrpPrbtnPrdDetails(grpId,cvrgTypCd);
			List<GrpPrbtnPrd> cntrctPlanRtDtllst = objectMapper.convertValue(grpPrbtnPrdDetailslst,new TypeReference<List<GrpPrbtnPrd>>() {});
			Map<Long,List<GrpPrbtnPrd>> cntrctPlanRtDtlMap = null;
			if(!CollectionUtils.isEmpty(cntrctPlanRtDtllst)) {
				cntrctPlanRtDtlMap = cntrctPlanRtDtllst.stream().collect(Collectors.groupingBy(GrpPrbtnPrd::getCntrctId));
			}
			return cntrctPlanRtDtlMap;
		});*/
		
		CompletableFuture<Void> finalCompletableFuture = CompletableFuture.allOf(cntrctDetails, cntrctPlanDetails,cntrctAdrsDetails,cntrcBillgEntityDetails,adrsDetails,
				cntrctTlphnDetails,cntrctPlanProvNtwkDetails,grpCntrctPrvsnDetails,grpHCDetails,grpMnthlyCntrbtnDetails,cntrctPlanRtDetails,cntrctPlanRtSmryDetails,
				cntrctPlanRtDtlDetails,billgEntyDetails);
		finalCompletableFuture.join();
		cntrctdtlsLst = cntrctDetails!=null?cntrctDetails.get():null;
		Map<Long,CntrctPlan>  cntrctPlandtlsMap = cntrctPlanDetails!=null?cntrctPlanDetails.get():null;
		Map<Long,CntrctAdrs> cntrctAdrsMap = cntrctAdrsDetails!=null?cntrctAdrsDetails.get():null;
		Map<Long,CntrctBillgEnty> cntrctBillgsMap = cntrcBillgEntityDetails!=null?cntrcBillgEntityDetails.get():null;
		Map<Long,Adrs> adrsMap = adrsDetails!=null?adrsDetails.get():null;
		Map<Long,CntrctTlphn> cntrctTlphnDetailsMap =cntrctTlphnDetails!=null?cntrctTlphnDetails.get():null;
		Map<Long,CntrctPlanProvNtwk> cntrctPlanProvNtwkDetailsMap = cntrctPlanProvNtwkDetails!=null?cntrctPlanProvNtwkDetails.get():null;
		Map<Long,GrpCntrctPrvsn> grpCntrctPrvsnMap = grpCntrctPrvsnDetails!=null?grpCntrctPrvsnDetails.get():null;
		Map<Long,GrpHc>grpHCMap = grpHCDetails!=null?grpHCDetails.get():null;
		Map<Long,GrpMnthlyCntrbtn>grpMCMap = grpMnthlyCntrbtnDetails!=null?grpMnthlyCntrbtnDetails.get():null;
		Map<Long,CntrctPlanRt>cntrctPlanRTMap = cntrctPlanRtDetails!=null?cntrctPlanRtDetails.get():null;
		Map<Long,CntrctPlanRtSmry>cntrctPlanRTSmryMap = cntrctPlanRtSmryDetails!=null?cntrctPlanRtSmryDetails.get():null;
		Map<Long,List<CntrctPlanRtDtl>> cntrctPlanRTDtlMap = cntrctPlanRtDtlDetails!=null?cntrctPlanRtDtlDetails.get():null;
//		Map<Long,List<BillgEnty>> billgEntityMap = billgEntyDetails!=null?billgEntyDetails.get():null;
		Map<Long,BillgEnty> billgEntityMap = billgEntyDetails!=null?billgEntyDetails.get():null;
		if(!CollectionUtils.isEmpty(cntrctdtlsLst)) {
			cntrctdtlsLst.forEach(cntrct->{
				cntrct.setCntrctPlan(cntrctPlandtlsMap!=null?cntrctPlandtlsMap.get(cntrct.getCntrctId()):null);
				cntrct.setCntrctAdrs(cntrctAdrsMap!=null?cntrctAdrsMap.get(cntrct.getCntrctId()):null);
				cntrct.setCntrctBillgEnties(cntrctBillgsMap!=null?Arrays.asList(cntrctBillgsMap.get(cntrct.getCntrctId())):null);
				if (!CollectionUtils.isEmpty(cntrct.getCntrctBillgEnties())) {
						List<CntrctBillgEnty> cntrctBillgEntyListCurrent = cntrct.getCntrctBillgEnties().stream().filter(cbe -> cbe.getCntrctBillgEntyTrmntnDt() == null).collect(Collectors.toList());
						if (!CollectionUtils.isEmpty(cntrctBillgEntyListCurrent)) {
							 cntrctBillgEntyListCurrent.stream().forEach(cbe->cbe.setBillgEnty(billgEntityMap!=null?billgEntityMap.get(cbe.getBillgEntyId()):null));
						}
				}
				if(cntrct.getCntrctAdrs()!=null) {
				  cntrct.getCntrctAdrs().setAdrs(adrsMap!=null?adrsMap.get(cntrct.getCntrctAdrs().getAdrsId()):null);
				}
				cntrct.setCntrctTlphn(cntrctTlphnDetailsMap!=null?cntrctTlphnDetailsMap.get(cntrct.getCntrctId()):null);
				if(cntrct.getCntrctPlan()!=null) {
					cntrct.getCntrctPlan().setCntrctPlanProvNtwk(cntrctPlanProvNtwkDetailsMap!=null?cntrctPlanProvNtwkDetailsMap.get(cntrct.getCntrctId()):null);
					cntrct.getCntrctPlan().setGrpHc(grpHCMap!=null?grpHCMap.get(cntrct.getCntrctPlan().getCntrctPlanId()):null);
					cntrct.getCntrctPlan().setCntrctPlanRt(cntrctPlanRTMap!=null?cntrctPlanRTMap.get(cntrct.getCntrctPlan().getCntrctPlanId()):null);
					if(cntrct.getCntrctPlan().getCntrctPlanRt()!=null) {
						cntrct.getCntrctPlan().getCntrctPlanRt().setCntrctPlanRtSmries(cntrctPlanRTSmryMap!=null?Arrays.asList(
								cntrctPlanRTSmryMap.get(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtId())):null);
						if(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries()!=null && cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().size()>0) {
							cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().get(0).setCntrctPlanRtDtls(cntrctPlanRTDtlMap!=null?
									cntrctPlanRTDtlMap.get(cntrct.getCntrctPlan().getCntrctPlanRt().getCntrctPlanRtSmries().get(0).getCntrctPlanRtSmryId()):null);
						}
					}
				}
				cntrct.setGrpCntrctPrvsn(grpCntrctPrvsnMap!=null?grpCntrctPrvsnMap.get(cntrct.getCntrctId()):null);
				cntrct.setGrpMnthlyCntrbtn(grpMCMap!=null?grpMCMap.get(cntrct.getCntrctId()):null);
			});
		}
		
		
		Long end = System.currentTimeMillis();
		System.out.println("Total time took for : " +cntrctDetails.get().size()+" : "+(end-start));
		
		
	}catch(Exception e) {
		e.printStackTrace();
	}
		return cntrctdtlsLst;
	}

}