package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * The persistent class for the BILLG_ENTY_TLPHN database table.
 * @author Deloitte
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="BILLG_ENTY_TLPHN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillgEntyTlphn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BILLG_ENTY_TLPHN_ID")
	private long billgEntyTlphnId;

	@Column(name="BILLG_ENTY_TLPHN_CNTRY_CD")
	private String billgEntyTlphnCntryCd;

	//@Temporal(TemporalType.DATE)
	@Column(name="BILLG_ENTY_TLPHN_EFCTV_DT")
	private Date billgEntyTlphnEfctvDt;

	@Column(name="BILLG_ENTY_TLPHN_NBR")
	private String billgEntyTlphnNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="BILLG_ENTY_TLPHN_TRMNTN_DT")
	private Date billgEntyTlphnTrmntnDt;

	@Column(name="BILLG_ENTY_TLPHN_TYPE_CD")
	private String billgEntyTlphnTypeCd;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to BillgEnty
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BILLG_ENTY_ID")
	private BillgEnty billgEnty;
	
	@Column(name="BILLG_ENTY_TLPHN_EXT_NBR")
	private String beTlphnExtNbr;

	public BillgEntyTlphn() {
	}

	public long getBillgEntyTlphnId() {
		return this.billgEntyTlphnId;
	}

	public void setBillgEntyTlphnId(long billgEntyTlphnId) {
		this.billgEntyTlphnId = billgEntyTlphnId;
	}

	public String getBillgEntyTlphnCntryCd() {
		return this.billgEntyTlphnCntryCd;
	}

	public void setBillgEntyTlphnCntryCd(String billgEntyTlphnCntryCd) {
		this.billgEntyTlphnCntryCd = billgEntyTlphnCntryCd;
	}

	public Date getBillgEntyTlphnEfctvDt() {
		return this.billgEntyTlphnEfctvDt;
	}

	public void setBillgEntyTlphnEfctvDt(Date billgEntyTlphnEfctvDt) {
		this.billgEntyTlphnEfctvDt = billgEntyTlphnEfctvDt;
	}

	public String getBillgEntyTlphnNbr() {
		
		return this.billgEntyTlphnNbr;
	}

	public void setBillgEntyTlphnNbr(String billgEntyTlphnNbr) {
		this.billgEntyTlphnNbr = billgEntyTlphnNbr;
	}

	public Date getBillgEntyTlphnTrmntnDt() {
		return this.billgEntyTlphnTrmntnDt;
	}

	public void setBillgEntyTlphnTrmntnDt(Date billgEntyTlphnTrmntnDt) {
		this.billgEntyTlphnTrmntnDt = billgEntyTlphnTrmntnDt;
	}

	public String getBillgEntyTlphnTypeCd() {
		return this.billgEntyTlphnTypeCd;
	}

	public void setBillgEntyTlphnTypeCd(String billgEntyTlphnTypeCd) {
		this.billgEntyTlphnTypeCd = billgEntyTlphnTypeCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public BillgEnty getBillgEnty() {
		return this.billgEnty;
	}

	public void setBillgEnty(BillgEnty billgEnty) {
		this.billgEnty = billgEnty;
	}

	public String getBeTlphnExtNbr() {
		return beTlphnExtNbr;
	}

	public void setBeTlphnExtNbr(String beTlphnExtNbr) {
		this.beTlphnExtNbr = beTlphnExtNbr;
	}
	
	

}