package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the GRP_CNTCT_PRSN_ADRS_TLPHN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_CNTCT_PRSN_ADRS_TLPHN")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpCntctPrsnAdrsTlphn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_CNTCT_PRSN_ADRS_TLPHN_ID")
	private long grpCntctPrsnAdrsTlphnId;

	@Column(name="ADRS_ID")
	private BigDecimal adrsId;

	@Column(name="CNTCT_PRSN_ID")
	private BigDecimal cntctPrsnId;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_ADRS_EFCTV_DT")
	private Date grpCntctAdrsEfctvDt;

	@Column(name="GRP_CNTCT_ADRS_TLPHN_CNTRY_CD")
	private String grpCntctAdrsTlphnCntryCd;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_ADRS_TLPHN_EFCTV_DT")
	private Date grpCntctAdrsTlphnEfctvDt;

	@Column(name="GRP_CNTCT_ADRS_TLPHN_EXT_NBR")
	private String grpCntctAdrsTlphnExtNbr;

	@Column(name="GRP_CNTCT_ADRS_TLPHN_NBR")
	private String grpCntctAdrsTlphnNbr;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_ADRS_TLPHN_TRMNTN_DT")
	private Date grpCntctAdrsTlphnTrmntnDt;

	@Column(name="GRP_CNTCT_ADRS_TLPHN_TYPE_CD")
	private String grpCntctAdrsTlphnTypeCd;

	@Column(name="GRP_CNTCT_ADRS_TYPE_CD")
	private String grpCntctAdrsTypeCd;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_CNTCT_PRSN_EFCTV_DT")
	private Date grpCntctPrsnEfctvDt;

	@Column(name="GRP_CNTCT_TYPE_CD")
	private String grpCntctTypeCd;

	@Column(name="GRP_ID")
	private BigDecimal grpId;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to GrpCntctPrsn
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_CNTCT_PRSN_ID")
	private GrpCntctPrsn grpCntctPrsn;

	public GrpCntctPrsnAdrsTlphn() {
	}

	public long getGrpCntctPrsnAdrsTlphnId() {
		return this.grpCntctPrsnAdrsTlphnId;
	}

	public void setGrpCntctPrsnAdrsTlphnId(long grpCntctPrsnAdrsTlphnId) {
		this.grpCntctPrsnAdrsTlphnId = grpCntctPrsnAdrsTlphnId;
	}

	public BigDecimal getAdrsId() {
		return this.adrsId;
	}

	public void setAdrsId(BigDecimal adrsId) {
		this.adrsId = adrsId;
	}

	public BigDecimal getCntctPrsnId() {
		return this.cntctPrsnId;
	}

	public void setCntctPrsnId(BigDecimal cntctPrsnId) {
		this.cntctPrsnId = cntctPrsnId;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpCntctAdrsEfctvDt() {
		return this.grpCntctAdrsEfctvDt;
	}

	public void setGrpCntctAdrsEfctvDt(Date grpCntctAdrsEfctvDt) {
		this.grpCntctAdrsEfctvDt = grpCntctAdrsEfctvDt;
	}

	public String getGrpCntctAdrsTlphnCntryCd() {
		return this.grpCntctAdrsTlphnCntryCd;
	}

	public void setGrpCntctAdrsTlphnCntryCd(String grpCntctAdrsTlphnCntryCd) {
		this.grpCntctAdrsTlphnCntryCd = grpCntctAdrsTlphnCntryCd;
	}

	public Date getGrpCntctAdrsTlphnEfctvDt() {
		return this.grpCntctAdrsTlphnEfctvDt;
	}

	public void setGrpCntctAdrsTlphnEfctvDt(Date grpCntctAdrsTlphnEfctvDt) {
		this.grpCntctAdrsTlphnEfctvDt = grpCntctAdrsTlphnEfctvDt;
	}

	public String getGrpCntctAdrsTlphnExtNbr() {
		return this.grpCntctAdrsTlphnExtNbr;
	}

	public void setGrpCntctAdrsTlphnExtNbr(String grpCntctAdrsTlphnExtNbr) {
		this.grpCntctAdrsTlphnExtNbr = grpCntctAdrsTlphnExtNbr;
	}

	public String getGrpCntctAdrsTlphnNbr() {
		return this.grpCntctAdrsTlphnNbr;
	}

	public void setGrpCntctAdrsTlphnNbr(String grpCntctAdrsTlphnNbr) {
		this.grpCntctAdrsTlphnNbr = grpCntctAdrsTlphnNbr;
	}

	public Date getGrpCntctAdrsTlphnTrmntnDt() {
		return this.grpCntctAdrsTlphnTrmntnDt;
	}

	public void setGrpCntctAdrsTlphnTrmntnDt(Date grpCntctAdrsTlphnTrmntnDt) {
		this.grpCntctAdrsTlphnTrmntnDt = grpCntctAdrsTlphnTrmntnDt;
	}

	public String getGrpCntctAdrsTlphnTypeCd() {
		return this.grpCntctAdrsTlphnTypeCd;
	}

	public void setGrpCntctAdrsTlphnTypeCd(String grpCntctAdrsTlphnTypeCd) {
		this.grpCntctAdrsTlphnTypeCd = grpCntctAdrsTlphnTypeCd;
	}

	public String getGrpCntctAdrsTypeCd() {
		return this.grpCntctAdrsTypeCd;
	}

	public void setGrpCntctAdrsTypeCd(String grpCntctAdrsTypeCd) {
		this.grpCntctAdrsTypeCd = grpCntctAdrsTypeCd;
	}

	public Date getGrpCntctPrsnEfctvDt() {
		return this.grpCntctPrsnEfctvDt;
	}

	public void setGrpCntctPrsnEfctvDt(Date grpCntctPrsnEfctvDt) {
		this.grpCntctPrsnEfctvDt = grpCntctPrsnEfctvDt;
	}

	public String getGrpCntctTypeCd() {
		return this.grpCntctTypeCd;
	}

	public void setGrpCntctTypeCd(String grpCntctTypeCd) {
		this.grpCntctTypeCd = grpCntctTypeCd;
	}

	public BigDecimal getGrpId() {
		return this.grpId;
	}

	public void setGrpId(BigDecimal grpId) {
		this.grpId = grpId;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public GrpCntctPrsn getGrpCntctPrsn() {
		return this.grpCntctPrsn;
	}

	public void setGrpCntctPrsn(GrpCntctPrsn grpCntctPrsn) {
		this.grpCntctPrsn = grpCntctPrsn;
	}

}