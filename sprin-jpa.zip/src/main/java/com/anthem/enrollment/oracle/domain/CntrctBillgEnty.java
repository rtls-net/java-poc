package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * The persistent class for the CNTRCT_BILLG_ENTY database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTRCT_BILLG_ENTY")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctBillgEnty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CNTRCT_PLAN_BILLG_ENTY_ID")
	private long cntrctPlanBillgEntyId;

	@Column(name="BILL_ENTY_STTS")
	private String billEntyStts;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Column(name="CNTRCT_BILLG_ENTY_EFCTV_DT")
	private Date cntrctBillgEntyEfctvDt;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd",timezone="PST")
	@Column(name="CNTRCT_BILLG_ENTY_TRMNTN_DT")
	private Date cntrctBillgEntyTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to BillgEnty
	@ManyToOne(fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="BILLG_ENTY_ID")
	private BillgEnty billgEnty;

	//bi-directional many-to-one association to Cntrct
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="CNTRCT_ID")
//	@JsonIgnore
	private Cntrct cntrct;
	
	@Column(name="BSRC_TERM_DTE")
	private Date bsrcTermDte;
	
	
	
	@Transient
	private Long cntrctId;
	
	@Transient
	private Long billgEntyId;
	
	

	public Long getBillgEntyId() {
		return billgEntyId;
	}

	public void setBillgEntyId(Long billgEntyId) {
		this.billgEntyId = billgEntyId;
	}

	public CntrctBillgEnty() {
	}

	public long getCntrctPlanBillgEntyId() {
		return this.cntrctPlanBillgEntyId;
	}

	public void setCntrctPlanBillgEntyId(long cntrctPlanBillgEntyId) {
		this.cntrctPlanBillgEntyId = cntrctPlanBillgEntyId;
	}

	public String getBillEntyStts() {
		return this.billEntyStts;
	}

	public void setBillEntyStts(String billEntyStts) {
		this.billEntyStts = billEntyStts;
	}

	public Date getCntrctBillgEntyEfctvDt() {
		return this.cntrctBillgEntyEfctvDt;
	}

	public void setCntrctBillgEntyEfctvDt(Date cntrctBillgEntyEfctvDt) {
		this.cntrctBillgEntyEfctvDt = cntrctBillgEntyEfctvDt;
	}

	public Date getCntrctBillgEntyTrmntnDt() {
		return this.cntrctBillgEntyTrmntnDt;
	}

	public void setCntrctBillgEntyTrmntnDt(Date cntrctBillgEntyTrmntnDt) {
		this.cntrctBillgEntyTrmntnDt = cntrctBillgEntyTrmntnDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public BillgEnty getBillgEnty() {
		return this.billgEnty;
	}

	public void setBillgEnty(BillgEnty billgEnty) {
		this.billgEnty = billgEnty;
	}

	public Cntrct getCntrct() {
		return this.cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}

	public Date getBsrcTermDte() {
		return bsrcTermDte;
	}

	public void setBsrcTermDte(Date bsrcTermDte) {
		this.bsrcTermDte = bsrcTermDte;
	}

	
	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "CntrctBillgEnty [cntrctPlanBillgEntyId=" + cntrctPlanBillgEntyId + ", billEntyStts=" + billEntyStts
				+ ", cntrctBillgEntyEfctvDt=" + (cntrctBillgEntyEfctvDt!=null?formatter.format(cntrctBillgEntyEfctvDt):null) + ", cntrctBillgEntyTrmntnDt="
				+ (cntrctBillgEntyTrmntnDt!=null?formatter.format(cntrctBillgEntyTrmntnDt):null) + ", creatdByUserId=" + creatdByUserId + ", creatdDtm=" + creatdDtm
				+ ", vrsnNbr=" + vrsnNbr + ", bsrcTermDte=" + (bsrcTermDte!=null?formatter.format(bsrcTermDte):null) + "]";
	}

	
}