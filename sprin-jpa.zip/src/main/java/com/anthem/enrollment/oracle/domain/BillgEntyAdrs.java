package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * The persistent class for the BILLG_ENTY_ADRS database table.
 * @author Deloitte
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="BILLG_ENTY_ADRS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillgEntyAdrs implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BILLG_ENTY_ADRS_ID")
	private long billgEntyAdrsId;

	@Column(name="ADRS_TYPE_CD")
	private String adrsTypeCd;

	//@Temporal(TemporalType.DATE)
	@Column(name="BILLG_ENTY_ADRS_EFCTV_DT")
	private Date billgEntyAdrsEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="BILLG_ENTY_ADRS_TRMNTN_DT")
	private Date billgEntyAdrsTrmntnDt;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 1L;

	//bi-directional many-to-one association to Adr
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ADRS_ID")
	private Adrs adrs;

	//bi-directional many-to-one association to BillgEnty
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BILLG_ENTY_ID")
	private BillgEnty billgEnty;

	public BillgEntyAdrs() {
	    //Default implementation ignored
	}

	public long getBillgEntyAdrsId() {
		return this.billgEntyAdrsId;
	}

	public void setBillgEntyAdrsId(long billgEntyAdrsId) {
		this.billgEntyAdrsId = billgEntyAdrsId;
	}

	public String getAdrsTypeCd() {
		return this.adrsTypeCd;
	}

	public void setAdrsTypeCd(String adrsTypeCd) {
		this.adrsTypeCd = adrsTypeCd;
	}

	public Date getBillgEntyAdrsEfctvDt() {
		return this.billgEntyAdrsEfctvDt;
	}

	public void setBillgEntyAdrsEfctvDt(Date billgEntyAdrsEfctvDt) {
		this.billgEntyAdrsEfctvDt = billgEntyAdrsEfctvDt;
	}

	public Date getBillgEntyAdrsTrmntnDt() {
		return this.billgEntyAdrsTrmntnDt;
	}

	public void setBillgEntyAdrsTrmntnDt(Date billgEntyAdrsTrmntnDt) {
		this.billgEntyAdrsTrmntnDt = billgEntyAdrsTrmntnDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Adrs getAdrs() {
		return this.adrs;
	}

	public void setAdrs(Adrs adrs) {
		this.adrs = adrs;
	}

	public BillgEnty getBillgEnty() {
		return this.billgEnty;
	}

	public void setBillgEnty(BillgEnty billgEnty) {
		this.billgEnty = billgEnty;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "BillgEntyAdrs [billgEntyAdrsId=" + billgEntyAdrsId + ", adrsTypeCd=" + adrsTypeCd
				+ ", billgEntyAdrsEfctvDt=" + (billgEntyAdrsEfctvDt!=null?formatter.format(billgEntyAdrsEfctvDt):null) + ", billgEntyAdrsTrmntnDt=" + (billgEntyAdrsTrmntnDt!=null?formatter.format(billgEntyAdrsTrmntnDt):null)
				+ ", creatdByUserId=" + creatdByUserId + ", creatdDtm=" + creatdDtm 
				+ ", vrsnNbr=" + vrsnNbr + "]";
	}

	
	
}