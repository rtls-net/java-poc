package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the WGS_PRFRNCS database table.
 *
 * @author Deloitte
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="WGS_PRFRNCS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WgsPrfrncs implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "WGS_PRFRNCS_ID")
    private long wgsPrfrncsId;

    @Column(name = "WGS_PRFRNCS_DESC")
    private String wgsPrfrncsDesc;

    @Column(name = "EFCTV_DT")
    private Timestamp efctvDt;

    @Column(name = "TRMNTN_DT")
    private Timestamp trmntnDt;

    @Column(name = "DB_NM")
    private String dbNm;

    @Column(name = "SGMNT_NM")
    private String sgmntNm;

    @Version
    @Column(name = "VRSN_NBR")
    private Long vrsnNbr = 1L;

    @CreatedBy
    @Column(name = "CREATD_BY")
    private String creatdBy;

    @LastModifiedBy
    @Column(name = "UPDTD_BY")
    private String updtdBy;

    @CreatedDate
    @Column(name = "CREATD_DTM")
    private Date creatdDtm;

    @LastModifiedDate
    @Column(name = "UPDTD_DTM")
    private Date updtdDtm;

    //bi-directional many-to-one association to WgsPrfrncDtls
    @JsonIgnore
    @OneToMany(mappedBy="wgsPrfrncs")
    private List<WgsPrfrncDtls> wgsPrfrncDtls;

    public WgsPrfrncs() {

    }

    public long getWgsPrfrncsId() {
        return wgsPrfrncsId;
    }

    public void setWgsPrfrncsId(long wgsPrfrncsId) {
        this.wgsPrfrncsId = wgsPrfrncsId;
    }

    public String getWgsPrfrncsDesc() {
        return wgsPrfrncsDesc;
    }

    public void setWgsPrfrncsDesc(String wgsPrfrncsDesc) {
        this.wgsPrfrncsDesc = wgsPrfrncsDesc;
    }

    public Timestamp getEfctvDt() {
        return efctvDt;
    }

    public void setEfctvDt(Timestamp efctvDt) {
        this.efctvDt = efctvDt;
    }

    public Timestamp getTrmntnDt() {
        return trmntnDt;
    }

    public void setTrmntnDt(Timestamp trmntnDt) {
        this.trmntnDt = trmntnDt;
    }

    public String getDbNm() {
        return dbNm;
    }

    public void setDbNm(String dbNm) {
        this.dbNm = dbNm;
    }

    public String getSgmntNm() {
        return sgmntNm;
    }

    public void setSgmntNm(String sgmntNm) {
        this.sgmntNm = sgmntNm;
    }

    public Long getVrsnNbr() {
        return vrsnNbr;
    }

    public void setVrsnNbr(Long vrsnNbr) {
        this.vrsnNbr = vrsnNbr;
    }

    public String getCreatdBy() {
        return creatdBy;
    }

    public void setCreatdBy(String creatdBy) {
        this.creatdBy = creatdBy;
    }

    public String getUpdtdBy() {
        return updtdBy;
    }

    public void setUpdtdBy(String updtdBy) {
        this.updtdBy = updtdBy;
    }

    public Date getCreatdDtm() {
        return creatdDtm;
    }

    public void setCreatdDtm(Date creatdDtm) {
        this.creatdDtm = creatdDtm;
    }

    public Date getUpdtdDtm() {
        return updtdDtm;
    }

    public void setUpdtdDtm(Date updtdDtm) {
        this.updtdDtm = updtdDtm;
    }

    public List<WgsPrfrncDtls> getWgsPrfrncDtls() {
        return wgsPrfrncDtls;
    }

    public void setWgsPrfrncDtls(List<WgsPrfrncDtls> wgsPrfrncDtls) {
        this.wgsPrfrncDtls = wgsPrfrncDtls;
    }

    public WgsPrfrncDtls addWgsPrfrncDtls(WgsPrfrncDtls wgsPrfrncDtls) {
        getWgsPrfrncDtls().add(wgsPrfrncDtls);
        wgsPrfrncDtls.setWgsPrfrncs(this);

        return wgsPrfrncDtls;
    }

    public WgsPrfrncDtls removeWgsPrfrncDtls(WgsPrfrncDtls wgsPrfrncDtls) {
        getWgsPrfrncDtls().remove(wgsPrfrncDtls);
        wgsPrfrncDtls.setWgsPrfrncs(null);

        return wgsPrfrncDtls;
    }
}
