package com.anthem.enrollment.oracle.domain;

import java.util.List;

public class GroupTapeEnrollment {

    private List<Long> grpIds;
    private String groupTapeEnrollmentCd;
    private String caseNumber;

    public List<Long> getGrpIds() {
        return grpIds;
    }

    public void setGrpIds(List<Long> grpIds) {
        this.grpIds = grpIds;
    }

    public String getGroupTapeEnrollmentCd() {
        return groupTapeEnrollmentCd;
    }

    public void setGroupTapeEnrollmentCd(String groupTapeEnrollmentCd) {
        this.groupTapeEnrollmentCd = groupTapeEnrollmentCd;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }
}
