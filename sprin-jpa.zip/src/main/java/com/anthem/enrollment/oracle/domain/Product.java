package com.anthem.enrollment.oracle.domain;

import java.util.ArrayList;
import java.util.List;

import com.anthem.enrollment.sheets.model.Rate;
import com.anthem.wgs.util.GSMAppConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class Product {

	/** The lgcycntrctcd. */
	private String lgcycntrctcd;

	/** The lgcygrpnbr. */
	private String lgcygrpnbr;

	/** The cntrctplannm. */
	private String cntrctplannm;

	/** The cntrct plan stts cd. */
	private String cntrctPlanSttsCd;

	/** The cntrctplanorgnldt. */
	private String cntrctplanorgnldt;

	/** The cntrctplantrmntndt. */
	private String cntrctplantrmntndt;
	
	private String cntrctEffDt;

	/** The plantypecd. */
	private String plantypecd;

	/** The product id. */
	private Long productId;

	/** The grp prbtn prd med. */
	private ArrayList<String> grpPrbtnPrdMed;

	/** The grp prbtn prd den. */
	private ArrayList<String> grpPrbtnPrdDen;

	/** The grp prbtn prd vis. */
	private ArrayList<String> grpPrbtnPrdVis;

	private String grpPrbtnPrdLnD;
	
	 private List<GrpPrbtnPrd> grpPrbtnPrdList;

	public List<GrpPrbtnPrd> getGrpPrbtnPrdList() {
		return grpPrbtnPrdList;
	}

	public void setGrpPrbtnPrdList(List<GrpPrbtnPrd> grpPrbtnPrdList) {
		this.grpPrbtnPrdList = grpPrbtnPrdList;
	}

	/** The product tied to BE. */
	private boolean productTiedToBE;

	private CntrctPlanRtSmry cntrctPlanRtSmry;

	public CntrctPlanRtSmry getCntrctPlanRtSmry() {
		return cntrctPlanRtSmry;
	}

	public void setCntrctPlanRtSmry(CntrctPlanRtSmry cntrctPlanRtSmry) {
		this.cntrctPlanRtSmry = cntrctPlanRtSmry;
	}

	private String fundingType;

	private String mmtoSuffix;

	private String billEntity;

	private String prdtStatus;

	/** The product tied to BE. */
	private String cntrctTiedToBE;

	/** The grp status cd. */
	private String grpStatusCd;

	/** The grp type cd. */
	private String grpTypeCd;

	/** The lctn st cd. */
	private String lctnStCd;

	private String wgsUpdate;

	/** The cntrct trmntn rsn cd. */
	/*
	 * LIT-3080 adding the contract termination reason code to product domain
	 * object, so that it can be fetched on the summary page
	 */
	private String cntrctTrmntnRsnCd;

	/* End LIT-3080 */
	/**
	 * Gets the lgcycntrctcd.
	 *
	 * @return the lgcycntrctcd
	 */
	public String getLgcycntrctcd() {
		return lgcycntrctcd;
	}

	/**
	 * Sets the lgcycntrctcd.
	 *
	 * @param lgcycntrctcd the lgcycntrctcd to set
	 */
	public void setLgcycntrctcd(String lgcycntrctcd) {
		this.lgcycntrctcd = lgcycntrctcd;
	}
	
	public String getCntrctEffDt() {
		return cntrctEffDt;
	}

	public void setCntrctEffDt(String cntrctEffDt) {
		this.cntrctEffDt = cntrctEffDt;
	}

	/**
	 * Gets the lgcygrpnbr.
	 *
	 * @return the lgcygrpnbr
	 */
	public String getLgcygrpnbr() {
		return lgcygrpnbr;
	}

	/**
	 * Sets the lgcygrpnbr.
	 *
	 * @param lgcygrpnbr the lgcygrpnbr to set
	 */
	public void setLgcygrpnbr(String lgcygrpnbr) {
		this.lgcygrpnbr = lgcygrpnbr;
	}

	/**
	 * Gets the cntrctplannm.
	 *
	 * @return the cntrctplannm
	 */
	public String getCntrctplannm() {
		return cntrctplannm;
	}

	/**
	 * Sets the cntrctplannm.
	 *
	 * @param cntrctplannm the cntrctplannm to set
	 */
	public void setCntrctplannm(String cntrctplannm) {
		this.cntrctplannm = cntrctplannm;
	}

	/**
	 * Gets the cntrctplanorgnldt.
	 *
	 * @return the cntrctplanorgnldt
	 */
	public String getCntrctplanorgnldt() {
		return cntrctplanorgnldt;
	}

	/**
	 * Sets the cntrctplanorgnldt.
	 *
	 * @param cntrctplanorgnldt the cntrctplanorgnldt to set
	 */
	public void setCntrctplanorgnldt(String cntrctplanorgnldt) {
		this.cntrctplanorgnldt = cntrctplanorgnldt;
	}

	/**
	 * Gets the cntrctplantrmntndt.
	 *
	 * @return the cntrctplantrmntndt
	 */
	public String getCntrctplantrmntndt() {
		return cntrctplantrmntndt;
	}

	/**
	 * Sets the cntrctplantrmntndt.
	 *
	 * @param cntrctplantrmntndt the cntrctplantrmntndt to set
	 */
	public void setCntrctplantrmntndt(String cntrctplantrmntndt) {
		this.cntrctplantrmntndt = cntrctplantrmntndt;
	}

	/**
	 * Gets the plantypecd.
	 *
	 * @return the plantypecd
	 */
	public String getPlantypecd() {
		return plantypecd;
	}

	/**
	 * Sets the plantypecd.
	 *
	 * @param plantypecd the plantypecd to set
	 */
	public void setPlantypecd(String plantypecd) {
		this.plantypecd = plantypecd;
	}

	/**
	 * Gets the product id.
	 *
	 * @return the productId
	 */
	public Long getProductId() {
		return productId;
	}

	/**
	 * Sets the product id.
	 *
	 * @param productId the productId to set
	 */
	public void setProductId(Long productId) {
		this.productId = productId;
	}

	/**
	 * Gets the group prbtn prd med.
	 *
	 * @return the group prbtn prd med
	 */
	public ArrayList<String> getGrpPrbtnPrdMed() {
		return grpPrbtnPrdMed;
	}

	/**
	 * Sets the group prbtn prd med.
	 *
	 * @param grpPrbtnPrdMed the new group prbtn prd med
	 */
	public void setGrpPrbtnPrdMed(ArrayList<String> grpPrbtnPrdMed) {
		this.grpPrbtnPrdMed = grpPrbtnPrdMed;
	}

	/**
	 * Gets the group prbtn prd den.
	 *
	 * @return the group prbtn prd den
	 */
	public ArrayList<String> getGrpPrbtnPrdDen() {
		return grpPrbtnPrdDen;
	}

	/**
	 * Sets the group prbtn prd den.
	 *
	 * @param grpPrbtnPrdDen the new group prbtn prd den
	 */
	public void setGrpPrbtnPrdDen(ArrayList<String> grpPrbtnPrdDen) {
		this.grpPrbtnPrdDen = grpPrbtnPrdDen;
	}

	/**
	 * Gets the group prbtn prd vis.
	 *
	 * @return the group prbtn prd vis
	 */
	public ArrayList<String> getGrpPrbtnPrdVis() {
		return grpPrbtnPrdVis;
	}

	/**
	 * Sets the group prbtn prd vis.
	 *
	 * @param grpPrbtnPrdVis the new group prbtn prd vis
	 */
	public void setGrpPrbtnPrdVis(ArrayList<String> grpPrbtnPrdVis) {
		this.grpPrbtnPrdVis = grpPrbtnPrdVis;
	}

	/**
	 * Gets the product tied to BE.
	 *
	 * @return the productTiedToBE
	 */
	public boolean getProductTiedToBE() {
		return productTiedToBE;
	}

	/**
	 * Sets the product tied to BE.
	 *
	 * @param productTiedToBE the productTiedToBE to set
	 */
	public void setProductTiedToBE(boolean productTiedToBE) {
		this.productTiedToBE = productTiedToBE;
	}

	/**
	 * Gets the group status cd.
	 *
	 * @return the group status cd
	 */
	public String getGrpStatusCd() {
		return grpStatusCd;
	}

	/**
	 * Sets the group status cd.
	 *
	 * @param grpStatusCd the new group status cd
	 */
	public void setGrpStatusCd(String grpStatusCd) {
		this.grpStatusCd = grpStatusCd;
	}

	/**
	 * Gets the group type cd.
	 *
	 * @return the group type cd
	 */
	public String getGrpTypeCd() {
		return grpTypeCd;
	}

	/**
	 * Sets the group type cd.
	 *
	 * @param grpTypeCd the new group type cd
	 */
	public void setGrpTypeCd(String grpTypeCd) {
		this.grpTypeCd = grpTypeCd;
	}

	/**
	 * Gets the cntrct plan stts cd.
	 *
	 * @return the cntrct plan stts cd
	 */
	public String getCntrctPlanSttsCd() {
		return cntrctPlanSttsCd;
	}

	/**
	 * Sets the cntrct plan stts cd.
	 *
	 * @param cntrctPlanSttsCd the new cntrct plan stts cd
	 */
	public void setCntrctPlanSttsCd(String cntrctPlanSttsCd) {
		this.cntrctPlanSttsCd = cntrctPlanSttsCd;
	}

	/**
	 * Gets the lctn st cd.
	 *
	 * @return the lctn st cd
	 */
	public String getLctnStCd() {
		return lctnStCd;
	}

	/**
	 * Sets the lctn st cd.
	 *
	 * @param lctnStCd the new lctn st cd
	 */
	public void setLctnStCd(String lctnStCd) {
		this.lctnStCd = lctnStCd;
	}

	/**
	 * Gets the cntrct trmntn rsn cd.
	 *
	 * @return the cntrct trmntn rsn cd
	 */
	/*
	 * LIT-3080 adding the contract termination reason code to product domain
	 * object, so that it can be fetched on the summary page
	 */
	public String getCntrctTrmntnRsnCd() {
		return cntrctTrmntnRsnCd;
	}

	/**
	 * Sets the cntrct trmntn rsn cd.
	 *
	 * @param cntrctTrmntnRsnCd the new cntrct trmntn rsn cd
	 */
	public void setCntrctTrmntnRsnCd(String cntrctTrmntnRsnCd) {
		this.cntrctTrmntnRsnCd = cntrctTrmntnRsnCd;
	}

	/* End LIT-3080 */
	/**
	 * USED IN THE BE screen to show group status .
	 *
	 * @return the group stus
	 */
//	public String getGroupStus(){
//		String groupStatus = GSMAppConstants.EMPTY_STRING;
//			if (FwConstants.LETTER_E.equals(getGrpTypeCd()) && GSMAppConstants.STATE_CODE_CA.equals(getLctnStCd())){
//				groupStatus = GSMAppConstants.CAL_COBRA;
//			}
//			else if (FwConstants.LETTER_E.equals(getGrpTypeCd()) && GSMAppConstants.STATE_CODE_CO.equals(getLctnStCd())){
//				groupStatus = GSMAppConstants.STATE_CONT;
//			}
//			else if(FwConstants.LETTER_A.equals(getGrpTypeCd())){
//				groupStatus = GSMAppConstants.ACTIVE;
//			}
//			else if(FwConstants.LETTER_C.equals(getGrpTypeCd())){
//				groupStatus = GSMAppConstants.COBRA;
//			}
//			else if(FwConstants.LETTER_R.equals(getGrpTypeCd())){
//				groupStatus = GSMAppConstants.RETIREE;
//			}
//			 return groupStatus;
//		}

	public String getGrpPrbtnPrdLnD() {
		return grpPrbtnPrdLnD;
	}

	public void setGrpPrbtnPrdLnD(String grpPrbtnPrdLnD) {
		this.grpPrbtnPrdLnD = grpPrbtnPrdLnD;
	}

	/**
	 * @return the cntrctTiedToBE
	 */
	public String getCntrctTiedToBE() {
		return cntrctTiedToBE;
	}

	/**
	 * @param cntrctTiedToBE the cntrctTiedToBE to set
	 */
	public void setCntrctTiedToBE(String cntrctTiedToBE) {
		this.cntrctTiedToBE = cntrctTiedToBE;
	}

	public String getFundingType() {
		return fundingType;
	}

	public void setFundingType(String fundingType) {
		this.fundingType = fundingType;
	}

	public String getMmtoSuffix() {
		return mmtoSuffix;
	}

	public void setMmtoSuffix(String mmtoSuffix) {
		this.mmtoSuffix = mmtoSuffix;
	}

	public String getBillEntity() {
		return billEntity;
	}

	public void setBillEntity(String billEntity) {
		this.billEntity = billEntity;
	}

	public String getPrdtStatus() {
		return prdtStatus;
	}

	public void setPrdtStatus(String prdtStatus) {
		this.prdtStatus = prdtStatus;
	}

	public String getWgsUpdate() {
		return wgsUpdate;
	}

	public void setWgsUpdate(String wgsUpdate) {
		this.wgsUpdate = wgsUpdate;
	}

}
