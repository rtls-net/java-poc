package com.anthem.enrollment.oracle.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.annotation.Version;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the CntrctPlanVndr database table.
 *
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="CNTRCT_PLAN_VNDR")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"}, ignoreUnknown = true)
public class CntrctPlanVndr {
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CNTRCT_PLAN_VNDR_ID")
	private Long cntrctPlanVndrId;
	/*
	@Column(name="CNTRCT_PLAN_ID")
	private Long contractPlanId;*/
	@Column(name="VND_VNDR_ID")
	private Long vendorVenId;
	@Column(name="VNDR_TYPE_CD")
	private String vendorTypCd;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CNTRCT_PLAN_VNDR_EFCTV_DT")
	private Date vendorEffDt;
	@Column(name="BNFT_CD")
	private String bnftCd;
	@Version
	@Column(name="VRSN_NBR")
	private Long versionNo;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CNTRCT_PLAN_VNDR_TRMNTN_DT")
	private Date vendorTrmntnDt;
	@Column(name="BNFT_PLAN_CD")
	private String bnftPlnCd;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="BNFT_EFCTV_DT")
	private Date bnftEffDt;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="BNFT_TRMNTN_DT")
	private Date bnftTrmntnDt;
	
	@Column(name="BNFT_CHLD_COMINGLE_CD")
	private String bnftChldCd;
	@Column(name="BNFT_ADLT_COMINGLE_CD")
	private String bnftAdltCd;
	@Column(name="PRFRD_DRUG_CD")
	private String prfrdDrgCd;
	@Column(name="VNDR_DVSN_ID")
	private String vndrDvsnId;
	@Column(name="VNDR_CLNT_ID")
	private String vndrClntId;
	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;
	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;
	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;
	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;
	@Column(name="BNFT_LVL_VAL_TXT")
	private String bnftLvlValTxt;
	@Column(name="CNTRCT_PLAN_VNDR_NOTE_TXT")
	private String cntrctPlnVndrNoteTxt;
	@Column(name="CNTRCT_ID")
	private Long contractId;
	@Column(name="CNTRCT_PLAN_CD")
	private String cntrctPlnCd;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CNTRCT_PLAN_EFCTV_DT")
	private Date cntrctPlanEffDt;
	@Column(name="VENDOR_DATA_1")
	private String vndrData1;
	@Column(name="VENDOR_DATA_2")
	private String vndrData2;
	@Column(name="VENDOR_DATA_3")
	private String vndrData3;
	@Column(name="VENDOR_DATA_4")
	private String vndrData4;
	@Column(name="PROCESS_DATE")
	private Date processDate;
	@Column(name="SUD_CD")
	private String sudCd;
	@Column(name="RX_ROLLOVER_ID")
	private String rxRollovrId;
	@Column(name="MANAGED_CARE_CD")
	private String managedCareCd;
	@Column(name="BUS_TYPE_CD")
	private String busTypCd;
	@Column(name="EYEMED_PLAN_CD")
	private String eyemedPlanCd;
	@Column(name="CO_CHLD_MET_CD")
	private String coChldMetCd;
	@Column(name="CO_CHLD_NOT_MET_CD")
	private String coChldNotMetCd;
	@Column(name="CO_ADLT_MET_CD")
	private String coAdltMetCd;
	@Column(name="CO_ADLT_NOT_MET_CD")
	private String coAdltNotMetCd;
	@Column(name="PLAN_TYPE")
	private String planType;
	@Column(name="NOTES")
	private String notes;
	@Column(name="CLIENT_ID")
	private String clientId;
	
	@Column(name="VNDR_CD")
	private String vndrCd;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CNTRCT_PLAN_ID")
    private CntrctPlan cntrctPlanId;
	
	
	public CntrctPlanVndr() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public CntrctPlan getCntrctPlanId() {
		return cntrctPlanId;
	}


	public void setCntrctPlanId(CntrctPlan cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}


	public Long getCntrctPlanVndrId() {
		return cntrctPlanVndrId;
	}
	public void setCntrctPlanVndrId(Long cntrctPlanVndrId) {
		this.cntrctPlanVndrId = cntrctPlanVndrId;
	} /*
	public Long getContractPlanId() {
		return contractPlanId;
	}
	public void setContractPlanId(Long contractPlanId) {
		this.contractPlanId = contractPlanId;
	} */
	public Long getVendorVenId() {
		return vendorVenId;
	}
	public void setVendorVenId(Long vendorVenId) {
		this.vendorVenId = vendorVenId;
	}
	public String getVendorTypCd() {
		return vendorTypCd;
	}
	public void setVendorTypCd(String vendorTypCd) {
		this.vendorTypCd = vendorTypCd;
	}
	public Date getVendorEffDt() {
		return vendorEffDt;
	}
	public void setVendorEffDt(Date vendorEffDt) {
		this.vendorEffDt = vendorEffDt;
	}
	public String getBnftCd() {
		return bnftCd;
	}
	public void setBnftCd(String bnftCd) {
		this.bnftCd = bnftCd;
	}
	public Long getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(Long versionNo) {
		this.versionNo = versionNo;
	}
	public Date getVendorTrmntnDt() {
		return vendorTrmntnDt;
	}
	public void setVendorTrmntnDt(Date vendorTrmntnDt) {
		this.vendorTrmntnDt = vendorTrmntnDt;
	}
	public String getBnftPlnCd() {
		return bnftPlnCd;
	}
	public void setBnftPlnCd(String bnftPlnCd) {
		this.bnftPlnCd = bnftPlnCd;
	}
	public Date getBnftEffDt() {
		return bnftEffDt;
	}
	public void setBnftEffDt(Date bnftEffDt) {
		this.bnftEffDt = bnftEffDt;
	}
	public Date getBnftTrmntnDt() {
		return bnftTrmntnDt;
	}
	public void setBnftTrmntnDt(Date bnftTrmntnDt) {
		this.bnftTrmntnDt = bnftTrmntnDt;
	}
	public String getBnftChldCd() {
		return bnftChldCd;
	}
	public void setBnftChldCd(String bnftChldCd) {
		this.bnftChldCd = bnftChldCd;
	}
	public String getBnftAdltCd() {
		return bnftAdltCd;
	}
	public void setBnftAdltCd(String bnftAdltCd) {
		this.bnftAdltCd = bnftAdltCd;
	}
	public String getPrfrdDrgCd() {
		return prfrdDrgCd;
	}
	public void setPrfrdDrgCd(String prfrdDrgCd) {
		this.prfrdDrgCd = prfrdDrgCd;
	}
	public String getVndrDvsnId() {
		return vndrDvsnId;
	}
	public void setVndrDvsnId(String vndrDvsnId) {
		this.vndrDvsnId = vndrDvsnId;
	}
	public String getVndrClntId() {
		return vndrClntId;
	}
	public void setVndrClntId(String vndrClntId) {
		this.vndrClntId = vndrClntId;
	}
	public String getCreatdByUserId() {
		return creatdByUserId;
	}
	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}
	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}
	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}
	public Date getCreatdDtm() {
		return creatdDtm;
	}
	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}
	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}
	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}
	public String getBnftLvlValTxt() {
		return bnftLvlValTxt;
	}
	public void setBnftLvlValTxt(String bnftLvlValTxt) {
		this.bnftLvlValTxt = bnftLvlValTxt;
	}
	public String getCntrctPlnVndrNoteTxt() {
		return cntrctPlnVndrNoteTxt;
	}
	public void setCntrctPlnVndrNoteTxt(String cntrctPlnVndrNoteTxt) {
		this.cntrctPlnVndrNoteTxt = cntrctPlnVndrNoteTxt;
	}
	public Long getContractId() {
		return contractId;
	}
	public void setContractId(Long contractId) {
		this.contractId = contractId;
	}
	public String getCntrctPlnCd() {
		return cntrctPlnCd;
	}
	public void setCntrctPlnCd(String cntrctPlnCd) {
		this.cntrctPlnCd = cntrctPlnCd;
	}
	public Date getCntrctPlanEffDt() {
		return cntrctPlanEffDt;
	}
	public void setCntrctPlanEffDt(Date cntrctPlanEffDt) {
		this.cntrctPlanEffDt = cntrctPlanEffDt;
	}
	public String getVndrData1() {
		return vndrData1;
	}
	public void setVndrData1(String vndrData1) {
		this.vndrData1 = vndrData1;
	}
	public String getVndrData2() {
		return vndrData2;
	}
	public void setVndrData2(String vndrData2) {
		this.vndrData2 = vndrData2;
	}
	public String getVndrData3() {
		return vndrData3;
	}
	public void setVndrData3(String vndrData3) {
		this.vndrData3 = vndrData3;
	}
	public String getVndrData4() {
		return vndrData4;
	}
	public void setVndrData4(String vndrData4) {
		this.vndrData4 = vndrData4;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
	public String getSudCd() {
		return sudCd;
	}
	public void setSudCd(String sudCd) {
		this.sudCd = sudCd;
	}
	public String getRxRollovrId() {
		return rxRollovrId;
	}
	public void setRxRollovrId(String rxRollovrId) {
		this.rxRollovrId = rxRollovrId;
	}
	public String getManagedCareCd() {
		return managedCareCd;
	}
	public void setManagedCareCd(String managedCareCd) {
		this.managedCareCd = managedCareCd;
	}
	public String getBusTypCd() {
		return busTypCd;
	}
	public void setBusTypCd(String busTypCd) {
		this.busTypCd = busTypCd;
	}
	public String getEyemedPlanCd() {
		return eyemedPlanCd;
	}
	public void setEyemedPlanCd(String eyemedPlanCd) {
		this.eyemedPlanCd = eyemedPlanCd;
	}
	public String getCoChldMetCd() {
		return coChldMetCd;
	}
	public void setCoChldMetCd(String coChldMetCd) {
		this.coChldMetCd = coChldMetCd;
	}
	public String getCoChldNotMetCd() {
		return coChldNotMetCd;
	}
	public void setCoChldNotMetCd(String coChldNotMetCd) {
		this.coChldNotMetCd = coChldNotMetCd;
	}
	public String getCoAdltMetCd() {
		return coAdltMetCd;
	}
	public void setCoAdltMetCd(String coAdltMetCd) {
		this.coAdltMetCd = coAdltMetCd;
	}
	public String getCoAdltNotMetCd() {
		return coAdltNotMetCd;
	}
	public void setCoAdltNotMetCd(String coAdltNotMetCd) {
		this.coAdltNotMetCd = coAdltNotMetCd;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public String getVndrCd() {
		return vndrCd;
	}


	public void setVndrCd(String vndrCd) {
		this.vndrCd = vndrCd;
	}
	
	
	

}
