package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the DELINQUENCY_STG database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="DELINQUENCY_STG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DelinquencyStg implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DELINQ_KEY")
	private long delinqKey;

	@Column(name="BILL_ENTY_NM")
	private String billEntyNm;

	@Column(name="\"CASE_NM \"")
	private String caseNm_;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Column(name="REASON_CD")
	private String reasonCd;

	@Column(name="STATUS_CD")
	private String statusCd;

	@Temporal(TemporalType.DATE)
	@Column(name="TERMINATION_DT")
	private Date terminationDt;

	public DelinquencyStg() {
	}

	public long getDelinqKey() {
		return this.delinqKey;
	}

	public void setDelinqKey(long delinqKey) {
		this.delinqKey = delinqKey;
	}

	public String getBillEntyNm() {
		return this.billEntyNm;
	}

	public void setBillEntyNm(String billEntyNm) {
		this.billEntyNm = billEntyNm;
	}

	public String getCaseNm_() {
		return this.caseNm_;
	}

	public void setCaseNm_(String caseNm_) {
		this.caseNm_ = caseNm_;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getReasonCd() {
		return this.reasonCd;
	}

	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public Date getTerminationDt() {
		return this.terminationDt;
	}

	public void setTerminationDt(Date terminationDt) {
		this.terminationDt = terminationDt;
	}

}