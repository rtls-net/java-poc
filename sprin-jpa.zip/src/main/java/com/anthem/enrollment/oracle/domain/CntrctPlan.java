package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.persistence.Version;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * The persistent class for the CNTRCT_PLAN database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name = "CNTRCT_PLAN")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" }, ignoreUnknown = true)
public class CntrctPlan implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "CNTRCT_PLAN_ID")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long cntrctPlanId;

	@Column(name = "CLM_PRCS_CD")
	private String clmPrcsCd;

	@Column(name = "CLM_RTE_NBR_CD")
	private String clmRteNbrCd;

	@Column(name = "CMPNY_SIZE_CTGRY_CD")
	private String cmpnySizeCtgryCd;

	@Column(name = "CNTRCT_PLAN_CD")
	private String cntrctPlanCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CNTRCT_PLAN_EFCTV_DT")
	private Date cntrctPlanEfctvDt;

	@Column(name = "CNTRCT_PLAN_NM")
	private String cntrctPlanNm;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "CNTRCT_PLAN_ORGNL_EFCTV_DT")
	private Date cntrctPlanOrgnlEfctvDt;

	@Column(name = "CNTRCT_PLAN_STTS_CD")
	private String cntrctPlanSttsCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "CNTRCT_PLAN_TRMNTN_DT")
	private Date cntrctPlanTrmntnDt;

	@Column(name = "CNTRCT_PLAN_TRMNTN_RSN_CD")
	private String cntrctPlanTrmntnRsnCd;

	@Column(name = "CNTRCT_PLAN_TYPE_CD")
	private String cntrctPlanTypeCd;

	@Column(name = "CNTRCT_PROD_TYPE_CD")
	private String cntrctProdTypeCd;

	@Column(name = "CRDT_CVRG_CD")
	private String crdtCvrgCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "CRDT_CVRG_EFCTV_DT")
	private Date crdtCvrgEfctvDt;

	@CreatedBy
	@Column(name = "CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name = "CREATD_DTM")
	private Date creatdDtm;

	@Column(name = "CVRG_TYPE_CD")
	private String cvrgTypeCd;

	@Column(name = "DLNQNT_GRP_IND_CD")
	private String dlnqntGrpIndCd;

	@Column(name = "DNTL_CVRG_CD")
	private String dntlCvrgCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Temporal(TemporalType.DATE)
	@Column(name = "EXCHNG_MNDTRY_EFCTV_DT")
	private Date exchngMndtryEfctvDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
//	@Temporal(TemporalType.DATE)
	@Column(name = "EXCHNG_MNDTRY_END_DT")
	private Date exchngMndtryEndDt;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "EXTRA_TRRTRL_CD_EFCTV_DT")
	private Date extraTrrtrlCdEfctvDt;

	@Column(name = "EXTRA_TRRTRL_IND_CD")
	private String extraTrrtrlIndCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "GRP_REINSTMN_EFCTV_DT")
	private Date grpReinstmnEfctvDt;

	@Column(name = "HIP_CD")
	private String hipCd;

	@Column(name = "HLTHCR_EXCHNG_TYPE_CD")
	private String hlthcrExchngTypeCd;

	@LastModifiedBy
	@Column(name = "LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@LastModifiedDate
	@Column(name = "LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Column(name = "MDCD_RT_CD")
	private String mdcdRtCd;

	@Column(name = "MDCL_CVRG_CD")
	private String mdclCvrgCd;

	@Column(name = "MH_SRVC_ADMNSTRN_SLL_CD")
	private String mhSrvcAdmnstrnSllCd;

	@Column(name = "MLN_OPTOUT_CD")
	private String mlnOptoutCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "PREM_PAID_TO_DT")
	private Date premPaidToDt;

	@Column(name = "PROD_CD")
	private String prodCd;

	@Column(name = "REOPN_FRQNCY_CD")
	private String reopnFrqncyCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "RT_EFCTV_DT")
	private Date rtEfctvDt;

	@Column(name = "RT_MTHD_CD")
	private String rtMthdCd;

//	@Temporal(TemporalType.DATE)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "RT_MTHD_CD_EFCTV_DT")
	private Date rtMthdCdEfctvDt;

	@Column(name = "RT_TYPE_CD")
	private String rtTypeCd;

	@Column(name = "SLRY_RQRMNT_IND_CD")
	private String slryRqrmntIndCd;

	@Column(name = "SRC_TYPE_CD")
	private String srcTypeCd;

	@Column(name = "MHSA_SLL_IND_CD")
	private String mhsasllIndCd;

	@Column(name = "ITS_HOME_PARN_IND_CD")
	private String itsHmPrtcIndCd;

	@Column(name = "RSN_CD")
	private String cntrctRsnCd;

	@Version
	@Column(name = "VRSN_NBR")
	private Long vrsnNbr = 1L;

	@Column(name = "EBF_IND_CD")
	private String ebfIndCode;

	@Column(name = "EYEMED_PLAN_CD")
	private String eyemedPlanCd;

	@Column(name = "EYEMED_BNFT_LVL")
	private String eyemedBenifitLvl;
	// LIT 6635 : BYCY Modular Start

	@Column(name = "BNFT_PRD_CD")
	private String bnftPrdCd;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "BNFT_PRD_CD_ASOF_DT")
	private java.util.Date bnftPrdCdAsofDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "BNFT_PRD_ACCUM_STRT_DT")
	private java.util.Date bnftPrdAccumStrtDt;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "BNFT_PRD_ACCUM_ASOF_DT")
	private java.util.Date bnftPrdAccumAsofDt;

	@Column(name = "COST_SHARE")
	private String dentalCostShareIndicator;

	@Column(name = "COPAY_AMT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long coPay;

	@Column(name = "COINSRNCE_PCT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long coInsurance;

	@Column(name = "DEDCTBLE_AMT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "%,d")
	private Long deductible;

	// CAIM-13512 -- add new field to Dental Cost Sharing
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "DNTL_CST_EFCTV_DT")
	private Date plnEffDt;

	// CAIM-27135 CHANGES
	@Column(name = "GRP_NAME")
	private String grpName;
	// END

	// CAIM-27204 CHANGES
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "PST")
	@Column(name = "ITS_PRFX_EFCTV_DT")
	private Date itsPrfxEffDt;
	
	@Transient
	private Long cntrctId;
	
	

	public Long getCntrctId() {
		return cntrctId;
	}

	public void setCntrctId(Long cntrctId) {
		this.cntrctId = cntrctId;
	}

	public Date getItsPrfxEffDt() {
		return itsPrfxEffDt;
	}

	public void setItsPrfxEffDt(Date itsPrfxEffDt) {
		this.itsPrfxEffDt = itsPrfxEffDt;
	}
	// end

	public String getDentalCostShareIndicator() {
		return dentalCostShareIndicator;
	}

	public String getGrpName() {
		return grpName;
	}

	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}

	public void setDentalCostShareIndicator(String dentalCostShareIndicator) {
		this.dentalCostShareIndicator = dentalCostShareIndicator;
	}

	public Long getCoPay() {
		return coPay;
	}

	public void setCoPay(Long coPay) {
		this.coPay = coPay;
	}

	public Long getCoInsurance() {
		return coInsurance;
	}

	public void setCoInsurance(Long coInsurance) {
		this.coInsurance = coInsurance;
	}

	public Long getDeductible() {
		return deductible;
	}

	public void setDeductible(Long deductible) {
		this.deductible = deductible;
	}

	// LIT 6635 : BYCY Modular End
	// bi-directional many-to-one association to Cntrct
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNTRCT_ID")
	private Cntrct cntrct;

	// bi-directional many-to-one association to CntrctPlanRt
	@JsonIgnore
	@OneToOne(mappedBy = "cntrctPlan", cascade = { CascadeType.ALL })
	private CntrctPlanRt cntrctPlanRt;

	// bi-directional many-to-one association to CntrctPlanRt
	@JsonIgnore
	@OneToOne(mappedBy = "cntrctPlan", cascade = { CascadeType.ALL })
	private CntrctPlanProvNtwk cntrctPlanProvNtwk;

	// bi-directional many-to-one association to CntrctPlanSpclty
	@JsonIgnore
	@OneToMany(mappedBy = "cntrctPlan")
	private List<CntrctPlanSpclty> cntrctPlanSpclties;

	// bi-directional many-to-one association to GrpMnthlyCntrbtn
	@JsonIgnore
	@OneToMany(mappedBy = "cntrctPlan", cascade = { CascadeType.ALL })
	private List<GrpMnthlyCntrbtn> grpMnthlyCntrbtns;

	@JsonIgnore
	@OneToOne(mappedBy = "cntrctPlan", cascade = { CascadeType.ALL })
	private GrpHc grpHc;

	@Column(name = "HLTH_SVNG_FMLY_SNGL_CD")
	private String hsf;

	public GrpHc getGrpHc() {
		return grpHc;
	}

	public void setGrpHc(GrpHc grpHc) {
		this.grpHc = grpHc;
	}

	public CntrctPlan() {
	}

	public Long getCntrctPlanId() {
		return this.cntrctPlanId;
	}

	public void setCntrctPlanId(Long cntrctPlanId) {
		this.cntrctPlanId = cntrctPlanId;
	}

	public String getHsf() {
		return hsf;
	}

	public void setHsf(String hsf) {
		this.hsf = hsf;
	}

	public String getClmPrcsCd() {
		
		return this.clmPrcsCd;
	}

	public void setClmPrcsCd(String clmPrcsCd) {
		this.clmPrcsCd = clmPrcsCd;
	}

	public String getClmRteNbrCd() {
		
		return this.clmRteNbrCd;
	}

	public void setClmRteNbrCd(String clmRteNbrCd) {
		this.clmRteNbrCd = clmRteNbrCd;
	}

	public String getCmpnySizeCtgryCd() {
		return this.cmpnySizeCtgryCd;
	}

	public void setCmpnySizeCtgryCd(String cmpnySizeCtgryCd) {
		this.cmpnySizeCtgryCd = cmpnySizeCtgryCd;
	}

	public String getCntrctPlanCd() {
		return this.cntrctPlanCd;
	}

	public void setCntrctPlanCd(String cntrctPlanCd) {
		this.cntrctPlanCd = cntrctPlanCd;
	}

	public Date getCntrctPlanEfctvDt() {
		return this.cntrctPlanEfctvDt;
	}

	public void setCntrctPlanEfctvDt(Date cntrctPlanEfctvDt) {
		this.cntrctPlanEfctvDt = cntrctPlanEfctvDt;
	}

	public String getCntrctPlanNm() {
		return this.cntrctPlanNm;
	}

	public void setCntrctPlanNm(String cntrctPlanNm) {
		this.cntrctPlanNm = cntrctPlanNm;
	}

	public Date getCntrctPlanOrgnlEfctvDt() {
		return this.cntrctPlanOrgnlEfctvDt;
	}

	public void setCntrctPlanOrgnlEfctvDt(Date cntrctPlanOrgnlEfctvDt) {
		this.cntrctPlanOrgnlEfctvDt = cntrctPlanOrgnlEfctvDt;
	}

	public String getCntrctPlanSttsCd() {
		return this.cntrctPlanSttsCd;
	}

	public void setCntrctPlanSttsCd(String cntrctPlanSttsCd) {
		this.cntrctPlanSttsCd = cntrctPlanSttsCd;
	}

	public Date getCntrctPlanTrmntnDt() {
		return this.cntrctPlanTrmntnDt;
	}

	public void setCntrctPlanTrmntnDt(Date cntrctPlanTrmntnDt) {
		this.cntrctPlanTrmntnDt = cntrctPlanTrmntnDt;
	}

	public String getCntrctPlanTrmntnRsnCd() {
		return this.cntrctPlanTrmntnRsnCd;
	}

	public void setCntrctPlanTrmntnRsnCd(String cntrctPlanTrmntnRsnCd) {
		this.cntrctPlanTrmntnRsnCd = cntrctPlanTrmntnRsnCd;
	}

	public String getCntrctPlanTypeCd() {
		return this.cntrctPlanTypeCd;
	}

	public void setCntrctPlanTypeCd(String cntrctPlanTypeCd) {
		this.cntrctPlanTypeCd = cntrctPlanTypeCd;
	}

	public String getCntrctProdTypeCd() {
		return this.cntrctProdTypeCd;
	}

	public void setCntrctProdTypeCd(String cntrctProdTypeCd) {
		this.cntrctProdTypeCd = cntrctProdTypeCd;
	}

	public String getCrdtCvrgCd() {
		return this.crdtCvrgCd;
	}

	public void setCrdtCvrgCd(String crdtCvrgCd) {
		this.crdtCvrgCd = crdtCvrgCd;
	}

	public Date getCrdtCvrgEfctvDt() {
		return this.crdtCvrgEfctvDt;
	}

	public void setCrdtCvrgEfctvDt(Date crdtCvrgEfctvDt) {
		this.crdtCvrgEfctvDt = crdtCvrgEfctvDt;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getCvrgTypeCd() {
		return this.cvrgTypeCd;
	}

	public void setCvrgTypeCd(String cvrgTypeCd) {
		this.cvrgTypeCd = cvrgTypeCd;
	}

	public String getDlnqntGrpIndCd() {
		return this.dlnqntGrpIndCd;
	}

	public void setDlnqntGrpIndCd(String dlnqntGrpIndCd) {
		this.dlnqntGrpIndCd = dlnqntGrpIndCd;
	}

	public String getDntlCvrgCd() {
		return this.dntlCvrgCd;
	}

	public void setDntlCvrgCd(String dntlCvrgCd) {
		this.dntlCvrgCd = dntlCvrgCd;
	}

	public Date getExchngMndtryEfctvDt() {
		return this.exchngMndtryEfctvDt;
	}

	public void setExchngMndtryEfctvDt(Date exchngMndtryEfctvDt) {
		this.exchngMndtryEfctvDt = exchngMndtryEfctvDt;
	}

	public Date getExchngMndtryEndDt() {
		return this.exchngMndtryEndDt;
	}

	public void setExchngMndtryEndDt(Date exchngMndtryEndDt) {
		this.exchngMndtryEndDt = exchngMndtryEndDt;
	}

	public Date getExtraTrrtrlCdEfctvDt() {
		return this.extraTrrtrlCdEfctvDt;
	}

	public void setExtraTrrtrlCdEfctvDt(Date extraTrrtrlCdEfctvDt) {
		this.extraTrrtrlCdEfctvDt = extraTrrtrlCdEfctvDt;
	}

	public String getExtraTrrtrlIndCd() {
		return this.extraTrrtrlIndCd;
	}

	public void setExtraTrrtrlIndCd(String extraTrrtrlIndCd) {
		this.extraTrrtrlIndCd = extraTrrtrlIndCd;
	}

	public Date getGrpReinstmnEfctvDt() {
		return this.grpReinstmnEfctvDt;
	}

	public void setGrpReinstmnEfctvDt(Date grpReinstmnEfctvDt) {
		this.grpReinstmnEfctvDt = grpReinstmnEfctvDt;
	}

	public String getHipCd() {
		return this.hipCd;
	}

	public void setHipCd(String hipCd) {
		this.hipCd = hipCd;
	}

	public String getHlthcrExchngTypeCd() {
		return this.hlthcrExchngTypeCd;
	}

	public void setHlthcrExchngTypeCd(String hlthcrExchngTypeCd) {
		this.hlthcrExchngTypeCd = hlthcrExchngTypeCd;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public String getMdcdRtCd() {
		return this.mdcdRtCd;
	}

	public void setMdcdRtCd(String mdcdRtCd) {
		this.mdcdRtCd = mdcdRtCd;
	}

	public String getMdclCvrgCd() {
		return this.mdclCvrgCd;
	}

	public void setMdclCvrgCd(String mdclCvrgCd) {
		this.mdclCvrgCd = mdclCvrgCd;
	}

	public String getMhSrvcAdmnstrnSllCd() {
		return this.mhSrvcAdmnstrnSllCd;
	}

	public void setMhSrvcAdmnstrnSllCd(String mhSrvcAdmnstrnSllCd) {
		this.mhSrvcAdmnstrnSllCd = mhSrvcAdmnstrnSllCd;
	}

	public String getMlnOptoutCd() {
		
		return this.mlnOptoutCd;
	}

	public void setMlnOptoutCd(String mlnOptoutCd) {
		this.mlnOptoutCd = mlnOptoutCd;
	}

	public Date getPremPaidToDt() {
		return this.premPaidToDt;
	}

	public void setPremPaidToDt(Date premPaidToDt) {
		this.premPaidToDt = premPaidToDt;
	}

	public String getProdCd() {
		return this.prodCd;
	}

	public void setProdCd(String prodCd) {
		this.prodCd = prodCd;
	}

	public String getReopnFrqncyCd() {
		return this.reopnFrqncyCd;
	}

	public void setReopnFrqncyCd(String reopnFrqncyCd) {
		this.reopnFrqncyCd = reopnFrqncyCd;
	}

	public Date getRtEfctvDt() {
		return this.rtEfctvDt;
	}

	public void setRtEfctvDt(Date rtEfctvDt) {
		this.rtEfctvDt = rtEfctvDt;
	}

	public String getRtMthdCd() {
		return this.rtMthdCd;
	}

	public void setRtMthdCd(String rtMthdCd) {
		this.rtMthdCd = rtMthdCd;
	}

	public Date getRtMthdCdEfctvDt() {
		return this.rtMthdCdEfctvDt;
	}

	public void setRtMthdCdEfctvDt(Date rtMthdCdEfctvDt) {
		this.rtMthdCdEfctvDt = rtMthdCdEfctvDt;
	}

	public String getRtTypeCd() {
		return this.rtTypeCd;
	}

	public void setRtTypeCd(String rtTypeCd) {
		this.rtTypeCd = rtTypeCd;
	}

	public String getSlryRqrmntIndCd() {
		return this.slryRqrmntIndCd;
	}

	public void setSlryRqrmntIndCd(String slryRqrmntIndCd) {
		this.slryRqrmntIndCd = slryRqrmntIndCd;
	}

	public String getSrcTypeCd() {
		return this.srcTypeCd;
	}

	public void setSrcTypeCd(String srcTypeCd) {
		this.srcTypeCd = srcTypeCd;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Cntrct getCntrct() {
		return this.cntrct;
	}

	public void setCntrct(Cntrct cntrct) {
		this.cntrct = cntrct;
	}

	public CntrctPlanRt getCntrctPlanRt() {
		return this.cntrctPlanRt;
	}

	public void setCntrctPlanRts(CntrctPlanRt cntrctPlanRt) {
		this.cntrctPlanRt = cntrctPlanRt;
	}

	public List<CntrctPlanSpclty> getCntrctPlanSpclties() {
		return this.cntrctPlanSpclties;
	}

	public void setCntrctPlanSpclties(List<CntrctPlanSpclty> cntrctPlanSpclties) {
		this.cntrctPlanSpclties = cntrctPlanSpclties;
	}

	public CntrctPlanSpclty addCntrctPlanSpclty(CntrctPlanSpclty cntrctPlanSpclty) {
		getCntrctPlanSpclties().add(cntrctPlanSpclty);
		cntrctPlanSpclty.setCntrctPlan(this);

		return cntrctPlanSpclty;
	}

	public CntrctPlanSpclty removeCntrctPlanSpclty(CntrctPlanSpclty cntrctPlanSpclty) {
		getCntrctPlanSpclties().remove(cntrctPlanSpclty);
		cntrctPlanSpclty.setCntrctPlan(null);

		return cntrctPlanSpclty;
	}

	public List<GrpMnthlyCntrbtn> getGrpMnthlyCntrbtns() {
		return this.grpMnthlyCntrbtns;
	}

	public void setGrpMnthlyCntrbtns(List<GrpMnthlyCntrbtn> grpMnthlyCntrbtns) {
		this.grpMnthlyCntrbtns = grpMnthlyCntrbtns;
	}

	public GrpMnthlyCntrbtn addGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		getGrpMnthlyCntrbtns().add(grpMnthlyCntrbtn);
		grpMnthlyCntrbtn.setCntrctPlan(this);

		return grpMnthlyCntrbtn;
	}

	public GrpMnthlyCntrbtn removeGrpMnthlyCntrbtn(GrpMnthlyCntrbtn grpMnthlyCntrbtn) {
		getGrpMnthlyCntrbtns().remove(grpMnthlyCntrbtn);
		grpMnthlyCntrbtn.setCntrctPlan(null);

		return grpMnthlyCntrbtn;
	}

	/**
	 * @param cntrctPlanRt the cntrctPlanRt to set
	 */
	public void setCntrctPlanRt(CntrctPlanRt cntrctPlanRt) {
		this.cntrctPlanRt = cntrctPlanRt;
	}

	public String getCntrctRsnCd() {
		
		return cntrctRsnCd;
	}

	public void setCntrctRsnCd(String cntrctRsnCd) {
		this.cntrctRsnCd = cntrctRsnCd;
	}

	public String getItsHmPrtcIndCd() {
		
		return itsHmPrtcIndCd;
	}

	public void setItsHmPrtcIndCd(String itsHmPrtcIndCd) {
		this.itsHmPrtcIndCd = itsHmPrtcIndCd;
	}

	public String getMhsasllIndCd() {
		return mhsasllIndCd;
	}

	public void setMhsasllIndCd(String mhsasllIndCd) {
		this.mhsasllIndCd = mhsasllIndCd;
	}

	public String getEbfIndCode() {
		return ebfIndCode;
	}

	public void setEbfIndCode(String ebfIndCode) {
		this.ebfIndCode = ebfIndCode;
	}

	public String getEyemedPlanCd() {
		
		return eyemedPlanCd;
	}

	public void setEyemedPlanCd(String eyemedPlanCd) {
		this.eyemedPlanCd = eyemedPlanCd;
	}

	public String getEyemedBenifitLvl() {
		
		return eyemedBenifitLvl;
	}

	public void setEyemedBenifitLvl(String eyemedBenifitLvl) {
		this.eyemedBenifitLvl = eyemedBenifitLvl;
	}

	public String getBnftPrdCd() {
		return bnftPrdCd;
	}

	public void setBnftPrdCd(String bnftPrdCd) {
		this.bnftPrdCd = bnftPrdCd;
	}

	public java.util.Date getBnftPrdCdAsofDt() {
		return bnftPrdCdAsofDt;
	}

	public void setBnftPrdCdAsofDt(java.util.Date bnftPrdCdAsofDt) {
		this.bnftPrdCdAsofDt = bnftPrdCdAsofDt;
	}

	public java.util.Date getBnftPrdAccumStrtDt() {
		return bnftPrdAccumStrtDt;
	}

	public void setBnftPrdAccumStrtDt(java.util.Date bnftPrdAccumStrtDt) {
		this.bnftPrdAccumStrtDt = bnftPrdAccumStrtDt;
	}

	public java.util.Date getBnftPrdAccumAsofDt() {
		return bnftPrdAccumAsofDt;
	}

	public void setBnftPrdAccumAsofDt(java.util.Date bnftPrdAccumAsofDt) {
		this.bnftPrdAccumAsofDt = bnftPrdAccumAsofDt;
	}

	public CntrctPlanProvNtwk getCntrctPlanProvNtwk() {
		return cntrctPlanProvNtwk;
	}

	public void setCntrctPlanProvNtwk(CntrctPlanProvNtwk cntrctPlanProvNtwk) {
		this.cntrctPlanProvNtwk = cntrctPlanProvNtwk;
	}

	public Date getPlnEffDt() {
		return plnEffDt;
	}

	public void setPlnEffDt(Date plnEffDt) {
		this.plnEffDt = plnEffDt;
	}

	@Override
	public String toString() {
		return "CntrctPlan [cntrctPlanId=" + cntrctPlanId + ", clmPrcsCd=" + clmPrcsCd + ", clmRteNbrCd=" + clmRteNbrCd
				+ ", cmpnySizeCtgryCd=" + cmpnySizeCtgryCd + ", cntrctPlanCd=" + cntrctPlanCd + ", cntrctPlanEfctvDt="
				+ cntrctPlanEfctvDt + ", cntrctPlanNm=" + cntrctPlanNm + ", cntrctPlanOrgnlEfctvDt="
				+ cntrctPlanOrgnlEfctvDt + ", cntrctPlanSttsCd=" + cntrctPlanSttsCd + ", cntrctPlanTrmntnDt="
				+ cntrctPlanTrmntnDt + ", cntrctPlanTrmntnRsnCd=" + cntrctPlanTrmntnRsnCd + ", cntrctPlanTypeCd="
				+ cntrctPlanTypeCd + ", cntrctProdTypeCd=" + cntrctProdTypeCd + ", crdtCvrgCd=" + crdtCvrgCd
				+ ", crdtCvrgEfctvDt=" + crdtCvrgEfctvDt + ", creatdByUserId=" + creatdByUserId + ", creatdDtm="
				+ creatdDtm + ", cvrgTypeCd=" + cvrgTypeCd + ", dlnqntGrpIndCd=" + dlnqntGrpIndCd + ", dntlCvrgCd="
				+ dntlCvrgCd + ", exchngMndtryEfctvDt=" + exchngMndtryEfctvDt + ", exchngMndtryEndDt="
				+ exchngMndtryEndDt + ", extraTrrtrlCdEfctvDt=" + extraTrrtrlCdEfctvDt + ", extraTrrtrlIndCd="
				+ extraTrrtrlIndCd + ", grpReinstmnEfctvDt=" + grpReinstmnEfctvDt + ", hipCd=" + hipCd
				+ ", hlthcrExchngTypeCd=" + hlthcrExchngTypeCd + ", lastUpdtdByUserId=" + lastUpdtdByUserId
				+ ", lastUpdtdDtm=" + lastUpdtdDtm + ", mdcdRtCd=" + mdcdRtCd + ", mdclCvrgCd=" + mdclCvrgCd
				+ ", mhSrvcAdmnstrnSllCd=" + mhSrvcAdmnstrnSllCd + ", mlnOptoutCd=" + mlnOptoutCd + ", premPaidToDt="
				+ premPaidToDt + ", prodCd=" + prodCd + ", reopnFrqncyCd=" + reopnFrqncyCd + ", rtEfctvDt=" + rtEfctvDt
				+ ", rtMthdCd=" + rtMthdCd + ", rtMthdCdEfctvDt=" + rtMthdCdEfctvDt + ", rtTypeCd=" + rtTypeCd
				+ ", slryRqrmntIndCd=" + slryRqrmntIndCd + ", srcTypeCd=" + srcTypeCd + ", mhsasllIndCd=" + mhsasllIndCd
				+ ", itsHmPrtcIndCd=" + itsHmPrtcIndCd + ", cntrctRsnCd=" + cntrctRsnCd + ", vrsnNbr=" + vrsnNbr
				+ ", ebfIndCode=" + ebfIndCode + ", eyemedPlanCd=" + eyemedPlanCd + ", eyemedBenifitLvl="
				+ eyemedBenifitLvl + ", bnftPrdCd=" + bnftPrdCd + ", bnftPrdCdAsofDt=" + bnftPrdCdAsofDt
				+ ", bnftPrdAccumStrtDt=" + bnftPrdAccumStrtDt + ", bnftPrdAccumAsofDt=" + bnftPrdAccumAsofDt
				+ ", dentalCostShareIndicator=" + dentalCostShareIndicator + ", coPay=" + coPay + ", coInsurance="
				+ coInsurance + ", deductible=" + deductible + ", plnEffDt=" + plnEffDt + ", grpName=" + grpName
				+ ", cntrct=" + cntrct + ", cntrctPlanRt=" + cntrctPlanRt + ", cntrctPlanProvNtwk=" + cntrctPlanProvNtwk
				+ ", cntrctPlanSpclties=" + cntrctPlanSpclties + ", grpMnthlyCntrbtns=" + grpMnthlyCntrbtns + ", grpHc="
				+ grpHc + ", hsf=" + hsf + "]";
	}

}