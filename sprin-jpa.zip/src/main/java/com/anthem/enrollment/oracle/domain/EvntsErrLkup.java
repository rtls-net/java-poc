package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the EVNTS_ERR_LKUP database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="EVNTS_ERR_LKUP")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EvntsErrLkup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EVNTS_ERR_CDE")
	private String evntsErrCde;

	@CreatedBy
	@Column(name="CREATED_BY_USR")
	private String createdByUsr;

	@CreatedDate
	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DTM")
	private Date createdDtm;

	@Column(name="EVNTS_ERR_DESC")
	private String evntsErrDesc;

	@LastModifiedBy
	@Column(name="UPDATED_BY_USR")
	private String updatedByUsr;

	@LastModifiedDate
	@Temporal(TemporalType.DATE)
	@Column(name="UPDATED_DTM")
	private Date updatedDtm;

	public EvntsErrLkup() {
	}

	public String getEvntsErrCde() {
		return this.evntsErrCde;
	}

	public void setEvntsErrCde(String evntsErrCde) {
		this.evntsErrCde = evntsErrCde;
	}

	public String getCreatedByUsr() {
		return this.createdByUsr;
	}

	public void setCreatedByUsr(String createdByUsr) {
		this.createdByUsr = createdByUsr;
	}

	public Date getCreatedDtm() {
		return this.createdDtm;
	}

	public void setCreatedDtm(Date createdDtm) {
		this.createdDtm = createdDtm;
	}

	public String getEvntsErrDesc() {
		return this.evntsErrDesc;
	}

	public void setEvntsErrDesc(String evntsErrDesc) {
		this.evntsErrDesc = evntsErrDesc;
	}

	public String getUpdatedByUsr() {
		return this.updatedByUsr;
	}

	public void setUpdatedByUsr(String updatedByUsr) {
		this.updatedByUsr = updatedByUsr;
	}

	public Date getUpdatedDtm() {
		return this.updatedDtm;
	}

	public void setUpdatedDtm(Date updatedDtm) {
		this.updatedDtm = updatedDtm;
	}

}