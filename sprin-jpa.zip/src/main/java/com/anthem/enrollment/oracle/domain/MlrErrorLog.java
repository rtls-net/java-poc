package com.anthem.enrollment.oracle.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonInclude;



@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="MLR_ERROR_LOG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MlrErrorLog implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MLR_ERROR_ID")
	private long mlrErrorId;
	
	@Column(name="WGS_CASE_ID")
	private String wgsCaseId;
	
	@Column(name="WGS_BILL_SUFFIX")
	private String wgsBillSuffix;
	
	@Column(name="ERROR_STATUS ")
	private String errorStatus;
	
    @Lob
	@Column(name="ERROR_DESC")
	private String errorDesc;
	
	
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;


	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;
	
	@Column(name="GRP_ID")
	private long grpId;

	public long getMlrErrorId() {
		return mlrErrorId;
	}

	public void setMlrErrorId(long mlrErrorId) {
		this.mlrErrorId = mlrErrorId;
	}

	public String getWgsCaseId() {
		return wgsCaseId;
	}

	public void setWgsCaseId(String wgsCaseId) {
		this.wgsCaseId = wgsCaseId;
	}

	public String getWgsBillSuffix() {
		return wgsBillSuffix;
	}

	public void setWgsBillSuffix(String wgsBillSuffix) {
		this.wgsBillSuffix = wgsBillSuffix;
	}

	public String getErrorStatus() {
		return errorStatus;
	}

	public void setErrorStatus(String errorStatus) {
		this.errorStatus = errorStatus;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getCreatdByUserId() {
		return creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public String getLastUpdtdByUserId() {
		return lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public long getGrpId() {
		return grpId;
	}

	public void setGrpId(long grpId) {
		this.grpId = grpId;
	}
	

	
	
	
}
