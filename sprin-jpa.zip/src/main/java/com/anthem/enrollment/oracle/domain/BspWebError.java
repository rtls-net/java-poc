package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


/**
 * The persistent class for the BSP_WEB_ERROR database table.
 * @author Deloitte
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="BSP_WEB_ERROR")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BspWebError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="BILL_ENT_NUM")
	private String billEntNum;

	@Column(name="CASE_NUM")
	private String caseNum;

	@Column(name="CLASS_NAME")
	private String className;

	@Column(name="ENTITY_TYP_ID")
	private String entityTypId;

	@Column(name="ENTITY_TYPE_CODE")
	private String entityTypeCode;

	@Column(name="ERROR_CODE")
	private String errorCode;

	@Column(name="ERROR_MESSAGE")
	private String errorMessage;

	@Lob
	@Column(name="ERROR_STACK_TRACE")
	private String errorStackTrace;

	@Column(name="ERROR_TIME")
	private Timestamp errorTime;

	@Column(name="ERROR_TYPE")
	private String errorType;

	@Column(name="ERROR_WEB_ID")
	@Id
	private long errorWebId;

	@Column(name="GRP_NUM")
	private String grpNum;

	@Column(name="METHOD_NAME")
	private String methodName;

	@Column(name="USER_ID")
	private String userId;

	public BspWebError() {
	}

	public String getBillEntNum() {
		return this.billEntNum;
	}

	public void setBillEntNum(String billEntNum) {
		this.billEntNum = billEntNum;
	}

	public String getCaseNum() {
		return this.caseNum;
	}

	public void setCaseNum(String caseNum) {
		this.caseNum = caseNum;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getEntityTypId() {
		return this.entityTypId;
	}

	public void setEntityTypId(String entityTypId) {
		this.entityTypId = entityTypId;
	}

	public String getEntityTypeCode() {
		return this.entityTypeCode;
	}

	public void setEntityTypeCode(String entityTypeCode) {
		this.entityTypeCode = entityTypeCode;
	}

	public String getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return this.errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorStackTrace() {
		return this.errorStackTrace;
	}

	public void setErrorStackTrace(String errorStackTrace) {
		this.errorStackTrace = errorStackTrace;
	}

	public Timestamp getErrorTime() {
		return this.errorTime;
	}

	public void setErrorTime(Timestamp errorTime) {
		this.errorTime = errorTime;
	}

	public String getErrorType() {
		return this.errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public long getErrorWebId() {
		return this.errorWebId;
	}

	public void setErrorWebId(long errorWebId) {
		this.errorWebId = errorWebId;
	}

	public String getGrpNum() {
		return this.grpNum;
	}

	public void setGrpNum(String grpNum) {
		this.grpNum = grpNum;
	}

	public String getMethodName() {
		return this.methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}