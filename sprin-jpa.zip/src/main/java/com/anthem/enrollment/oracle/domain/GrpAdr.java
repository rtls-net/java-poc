package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * The persistent class for the GRP_ADRS database table.
 * 
 */
@Entity
@DynamicUpdate
@EntityListeners(AuditingEntityListener.class)
@Table(name="GRP_ADRS")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrpAdr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="GRP_ADRS_ID")
	private Long grpAdrsId;

	@Column(name="ADRS_TYPE_CD")
	private String adrsTypeCd;

	@CreatedBy
	@Column(name="CREATD_BY_USER_ID")
	private String creatdByUserId;

	@CreatedDate
	@Column(name="CREATD_DTM")
	private Date creatdDtm;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_ADRS_EFCTV_DT")
	private Date grpAdrsEfctvDt;

	@Temporal(TemporalType.DATE)
	@Column(name="GRP_ADRS_TRMNTN_DT")
	private Date grpAdrsTrmntnDt;

	@LastModifiedBy
	@Column(name="LAST_UPDTD_BY_USER_ID")
	private String lastUpdtdByUserId;

	@LastModifiedDate
	@Column(name="LAST_UPDTD_DTM")
	private Date lastUpdtdDtm;

	@Version
	@Column(name="VRSN_NBR")
	private Long vrsnNbr = 0L;

	//bi-directional many-to-one association to Adr
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name="ADRS_ID")
	private Adrs adrs;

	//bi-directional many-to-one association to Grp
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GRP_ID")
	private Grp grp;

	public GrpAdr() {
	    //Default implementation ignored.
	}

	public Long getGrpAdrsId() {
		return this.grpAdrsId;
	}

	public void setGrpAdrsId(Long grpAdrsId) {
		this.grpAdrsId = grpAdrsId;
	}

	public String getAdrsTypeCd() {
		return this.adrsTypeCd;
	}

	public void setAdrsTypeCd(String adrsTypeCd) {
		this.adrsTypeCd = adrsTypeCd;
	}

	public String getCreatdByUserId() {
		return this.creatdByUserId;
	}

	public void setCreatdByUserId(String creatdByUserId) {
		this.creatdByUserId = creatdByUserId;
	}

	public Date getCreatdDtm() {
		return this.creatdDtm;
	}

	public void setCreatdDtm(Date creatdDtm) {
		this.creatdDtm = creatdDtm;
	}

	public Date getGrpAdrsEfctvDt() {
		return this.grpAdrsEfctvDt;
	}

	public void setGrpAdrsEfctvDt(Date grpAdrsEfctvDt) {
		this.grpAdrsEfctvDt = grpAdrsEfctvDt;
	}

	public Date getGrpAdrsTrmntnDt() {
		return this.grpAdrsTrmntnDt;
	}

	public void setGrpAdrsTrmntnDt(Date grpAdrsTrmntnDt) {
		this.grpAdrsTrmntnDt = grpAdrsTrmntnDt;
	}

	public String getLastUpdtdByUserId() {
		return this.lastUpdtdByUserId;
	}

	public void setLastUpdtdByUserId(String lastUpdtdByUserId) {
		this.lastUpdtdByUserId = lastUpdtdByUserId;
	}

	public Date getLastUpdtdDtm() {
		return this.lastUpdtdDtm;
	}

	public void setLastUpdtdDtm(Date lastUpdtdDtm) {
		this.lastUpdtdDtm = lastUpdtdDtm;
	}

	public Long getVrsnNbr() {
		return this.vrsnNbr;
	}

	public void setVrsnNbr(Long vrsnNbr) {
		this.vrsnNbr = vrsnNbr;
	}

	public Adrs getAdrs() {
		return this.adrs;
	}

	public void setAdrs(Adrs adrs) {
		this.adrs = adrs;
	}

	public Grp getGrp() {
		return this.grp;
	}

	public void setGrp(Grp grp) {
		this.grp = grp;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		return "GrpAdr [grpAdrsId=" + grpAdrsId + ", adrsTypeCd=" + adrsTypeCd + ", grpAdrsEfctvDt=" + (grpAdrsEfctvDt!=null?formatter.format(grpAdrsEfctvDt):null)
				+ ", grpAdrsTrmntnDt=" + (grpAdrsTrmntnDt!=null?formatter.format(grpAdrsTrmntnDt):null) + ", lastUpdtdByUserId=" + lastUpdtdByUserId
				+ ", lastUpdtdDtm=" + (lastUpdtdDtm!=null?formatter.format(lastUpdtdDtm):null) + ", adrs="+adrs+", vrsnNbr=" + vrsnNbr + "]";
	}
	
	

}