package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the MGRTN_LOG database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="MGRTN_LOG")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MgrtnLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOG_ID")
	private long logId;

	@Column(name="GSM_MIGRATION_END_TIME")
	private Timestamp gsmMigrationEndTime;

	@Column(name="GSM_MIGRATION_START_TIME")
	private Timestamp gsmMigrationStartTime;

	@Column(name="JSON_PRCS_END_TIME")
	private Timestamp jsonPrcsEndTime;

	@Column(name="JSON_PRCS_START_TIME")
	private Timestamp jsonPrcsStartTime;

	@Column(name="JSON_PRCS_STAT_IND")
	private String jsonPrcsStatInd;

	@Column(name="JSON_PRCS_TXT")
	private String jsonPrcsTxt;

	@Column(name="LAST_FLAG_SW")
	private String lastFlagSw;

	@Column(name="SOURCE_TYPE_CD")
	private String sourceTypeCd;

	@Column(name="SRVC_PRCS_STAT_IND")
	private String srvcPrcsStatInd;

	@Temporal(TemporalType.DATE)
	@Column(name="WGS_APRV_DATE")
	private Date wgsAprvDate;

	@Column(name="WGS_CASE_NAME")
	private String wgsCaseName;

	@Column(name="WGS_CASE_NBR")
	private String wgsCaseNbr;

	@Column(name="WGS_LEGAL_ENT")
	private String wgsLegalEnt;

	@Temporal(TemporalType.DATE)
	@Column(name="WGS_RQST_DATE")
	private Date wgsRqstDate;

	//bi-directional one-to-one association to MgrtnLogLoad
	@OneToOne(mappedBy="mgrtnLog", fetch=FetchType.LAZY)
	private MgrtnLogLoad mgrtnLogLoad;

	//bi-directional one-to-one association to MgrtnLogRspnce
	@OneToOne(mappedBy="mgrtnLog", fetch=FetchType.LAZY)
	private MgrtnLogRspnce mgrtnLogRspnce;

	public MgrtnLog() {
	}

	public long getLogId() {
		return this.logId;
	}

	public void setLogId(long logId) {
		this.logId = logId;
	}

	public Timestamp getGsmMigrationEndTime() {
		return this.gsmMigrationEndTime;
	}

	public void setGsmMigrationEndTime(Timestamp gsmMigrationEndTime) {
		this.gsmMigrationEndTime = gsmMigrationEndTime;
	}

	public Timestamp getGsmMigrationStartTime() {
		return this.gsmMigrationStartTime;
	}

	public void setGsmMigrationStartTime(Timestamp gsmMigrationStartTime) {
		this.gsmMigrationStartTime = gsmMigrationStartTime;
	}

	public Timestamp getJsonPrcsEndTime() {
		return this.jsonPrcsEndTime;
	}

	public void setJsonPrcsEndTime(Timestamp jsonPrcsEndTime) {
		this.jsonPrcsEndTime = jsonPrcsEndTime;
	}

	public Timestamp getJsonPrcsStartTime() {
		return this.jsonPrcsStartTime;
	}

	public void setJsonPrcsStartTime(Timestamp jsonPrcsStartTime) {
		this.jsonPrcsStartTime = jsonPrcsStartTime;
	}

	public String getJsonPrcsStatInd() {
		return this.jsonPrcsStatInd;
	}

	public void setJsonPrcsStatInd(String jsonPrcsStatInd) {
		this.jsonPrcsStatInd = jsonPrcsStatInd;
	}

	public String getJsonPrcsTxt() {
		return this.jsonPrcsTxt;
	}

	public void setJsonPrcsTxt(String jsonPrcsTxt) {
		this.jsonPrcsTxt = jsonPrcsTxt;
	}

	public String getLastFlagSw() {
		return this.lastFlagSw;
	}

	public void setLastFlagSw(String lastFlagSw) {
		this.lastFlagSw = lastFlagSw;
	}

	public String getSourceTypeCd() {
		return this.sourceTypeCd;
	}

	public void setSourceTypeCd(String sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getSrvcPrcsStatInd() {
		return this.srvcPrcsStatInd;
	}

	public void setSrvcPrcsStatInd(String srvcPrcsStatInd) {
		this.srvcPrcsStatInd = srvcPrcsStatInd;
	}

	public Date getWgsAprvDate() {
		return this.wgsAprvDate;
	}

	public void setWgsAprvDate(Date wgsAprvDate) {
		this.wgsAprvDate = wgsAprvDate;
	}

	public String getWgsCaseName() {
		return this.wgsCaseName;
	}

	public void setWgsCaseName(String wgsCaseName) {
		this.wgsCaseName = wgsCaseName;
	}

	public String getWgsCaseNbr() {
		return this.wgsCaseNbr;
	}

	public void setWgsCaseNbr(String wgsCaseNbr) {
		this.wgsCaseNbr = wgsCaseNbr;
	}

	public String getWgsLegalEnt() {
		return this.wgsLegalEnt;
	}

	public void setWgsLegalEnt(String wgsLegalEnt) {
		this.wgsLegalEnt = wgsLegalEnt;
	}

	public Date getWgsRqstDate() {
		return this.wgsRqstDate;
	}

	public void setWgsRqstDate(Date wgsRqstDate) {
		this.wgsRqstDate = wgsRqstDate;
	}

	public MgrtnLogLoad getMgrtnLogLoad() {
		return this.mgrtnLogLoad;
	}

	public void setMgrtnLogLoad(MgrtnLogLoad mgrtnLogLoad) {
		this.mgrtnLogLoad = mgrtnLogLoad;
	}

	public MgrtnLogRspnce getMgrtnLogRspnce() {
		return this.mgrtnLogRspnce;
	}

	public void setMgrtnLogRspnce(MgrtnLogRspnce mgrtnLogRspnce) {
		this.mgrtnLogRspnce = mgrtnLogRspnce;
	}

}