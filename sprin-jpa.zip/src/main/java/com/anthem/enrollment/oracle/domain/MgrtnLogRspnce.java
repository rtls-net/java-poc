package com.anthem.enrollment.oracle.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;


/**
 * The persistent class for the MGRTN_LOG_RSPNCE database table.
 * 
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="MGRTN_LOG_RSPNCE")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MgrtnLogRspnce implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOG_ID")
	private long logId;

	@Column(name="RESP_EXCP_TEXT")
	private String respExcpText;

	@Lob
	@Column(name="RESPONSE_TEXT")
	private String responseText;

	//bi-directional one-to-one association to MgrtnLog
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LOG_ID")
	private MgrtnLog mgrtnLog;

	public MgrtnLogRspnce() {
	}

	public long getLogId() {
		return this.logId;
	}

	public void setLogId(long logId) {
		this.logId = logId;
	}

	public String getRespExcpText() {
		return this.respExcpText;
	}

	public void setRespExcpText(String respExcpText) {
		this.respExcpText = respExcpText;
	}

	public String getResponseText() {
		return this.responseText;
	}

	public void setResponseText(String responseText) {
		this.responseText = responseText;
	}

	public MgrtnLog getMgrtnLog() {
		return this.mgrtnLog;
	}

	public void setMgrtnLog(MgrtnLog mgrtnLog) {
		this.mgrtnLog = mgrtnLog;
	}

}